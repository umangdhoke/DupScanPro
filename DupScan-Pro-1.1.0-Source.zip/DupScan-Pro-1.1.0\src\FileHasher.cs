using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace DupScan
{
    public static class FileHasher
    {
        private const int QuickChunk = 65536;
        private const int FullBuffer = 1024 * 1024;

        public static string QuickHash(string path, long size, CancellationToken token)
        {
            token.ThrowIfCancellationRequested();

            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = OpenRead(path))
            {
                byte[] sizeBytes = BitConverter.GetBytes(size);
                sha.TransformBlock(sizeBytes, 0, sizeBytes.Length, null, 0);

                if (size <= (long)QuickChunk * 2L)
                {
                    byte[] all = ReadChunk(stream, (int)Math.Min(size, (long)QuickChunk * 2L));
                    if (all.Length > 0) sha.TransformBlock(all, 0, all.Length, null, 0);
                }
                else
                {
                    byte[] first = ReadChunk(stream, QuickChunk);
                    if (first.Length > 0) sha.TransformBlock(first, 0, first.Length, null, 0);

                    if (stream.CanSeek)
                    {
                        stream.Seek(-QuickChunk, SeekOrigin.End);
                        byte[] last = ReadChunk(stream, QuickChunk);
                        if (last.Length > 0) sha.TransformBlock(last, 0, last.Length, null, 0);
                    }
                }

                token.ThrowIfCancellationRequested();
                sha.TransformFinalBlock(new byte[0], 0, 0);
                return ToHex(sha.Hash);
            }
        }

        public static string FullHash(string path, CancellationToken token, Action<long> progress)
        {
            token.ThrowIfCancellationRequested();

            using (SHA256 sha = SHA256.Create())
            using (FileStream stream = OpenRead(path))
            {
                byte[] buffer = new byte[FullBuffer];
                long total = 0;
                int read;
                while ((read = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    token.ThrowIfCancellationRequested();
                    if (read > 0)
                    {
                        sha.TransformBlock(buffer, 0, read, null, 0);
                        total += read;
                        if (progress != null) progress(total);
                    }
                }

                sha.TransformFinalBlock(new byte[0], 0, 0);
                return ToHex(sha.Hash);
            }
        }

        public static string HashBytes(byte[] data)
        {
            using (SHA256 sha = SHA256.Create())
            {
                return ToHex(sha.ComputeHash(data));
            }
        }

        private static FileStream OpenRead(string path)
        {
            return new FileStream(
                PathUtil.ToExtendedPath(path),
                FileMode.Open,
                FileAccess.Read,
                FileShare.ReadWrite | FileShare.Delete,
                FullBuffer,
                FileOptions.SequentialScan);
        }

        private static byte[] ReadChunk(FileStream stream, int count)
        {
            if (count <= 0) return new byte[0];
            byte[] buffer = new byte[count];
            int offset = 0;
            while (offset < count)
            {
                int read = stream.Read(buffer, offset, count - offset);
                if (read <= 0) break;
                offset += read;
            }

            if (offset == count) return buffer;
            byte[] trimmed = new byte[offset];
            Buffer.BlockCopy(buffer, 0, trimmed, 0, offset);
            return trimmed;
        }

        public static string ToHex(byte[] bytes)
        {
            if (bytes == null) return string.Empty;
            StringBuilder sb = new StringBuilder(bytes.Length * 2);
            for (int i = 0; i < bytes.Length; i++)
            {
                sb.Append(bytes[i].ToString("x2"));
            }
            return sb.ToString();
        }
    }
}
