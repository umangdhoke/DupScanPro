using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace DupScan
{
    public static class ReportExporter
    {
        public static void ExportCsv(ScanResult result, string path)
        {
            using (StreamWriter writer = new StreamWriter(path, false, new UTF8Encoding(true)))
            {
                writer.WriteLine("Group,Delete,FileName,SizeBytes,Size,Modified,FullPath,SHA256,Note");
                for (int i = 0; i < result.Groups.Count; i++)
                {
                    DuplicateGroup group = result.Groups[i];
                    for (int j = 0; j < group.Files.Count; j++)
                    {
                        DuplicateFile file = group.Files[j];
                        writer.Write(group.Id.ToString(CultureInfo.InvariantCulture));
                        writer.Write(",");
                        writer.Write(file.SelectedForDeletion ? "YES" : "NO");
                        writer.Write(",");
                        writer.Write(Csv(file.File.Name));
                        writer.Write(",");
                        writer.Write(file.File.Size.ToString(CultureInfo.InvariantCulture));
                        writer.Write(",");
                        writer.Write(Csv(file.File.SizeText));
                        writer.Write(",");
                        writer.Write(Csv(file.File.ModifiedText));
                        writer.Write(",");
                        writer.Write(Csv(file.File.Path));
                        writer.Write(",");
                        writer.Write(Csv(file.File.FullHash));
                        writer.Write(",");
                        writer.Write(Csv(file.File.HardLinkCount > 1 ? "Hard link (" + file.File.HardLinkCount + ")" : string.Empty));
                        writer.WriteLine();
                    }
                }
            }
        }

        public static void ExportHtml(ScanResult result, string path)
        {
            StringBuilder html = new StringBuilder(1024 * 64);
            int selectedCount = 0;
            long selectedBytes = 0;
            for (int i = 0; i < result.Groups.Count; i++)
            {
                DuplicateGroup group = result.Groups[i];
                for (int j = 0; j < group.Files.Count; j++)
                {
                    if (group.Files[j].SelectedForDeletion)
                    {
                        selectedCount++;
                        selectedBytes += group.Files[j].File.Size;
                    }
                }
            }

            html.AppendLine("<!DOCTYPE html>");
            html.AppendLine("<html lang=\"en\"><head><meta charset=\"utf-8\">");
            html.AppendLine("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">");
            html.AppendLine("<title>DupScan Pro duplicate file report</title>");
            html.AppendLine("<style>");
            html.AppendLine(":root{--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--accent:#2563eb;--danger:#dc2626;--ok:#059669;--bg:#f4f7fb}");
            html.AppendLine("*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.45 'Segoe UI',system-ui,sans-serif}");
            html.AppendLine(".wrap{max-width:1280px;margin:0 auto;padding:28px 24px 48px}");
            html.AppendLine("header{background:linear-gradient(110deg,#0f172a,#1e3a8a);color:#fff;border-radius:18px;padding:26px 30px;margin-bottom:20px}");
            html.AppendLine("header h1{margin:0 0 4px;font-size:26px;letter-spacing:-.4px}header p{margin:0;color:#c7d2fe}");
            html.AppendLine(".cards{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:18px 0}");
            html.AppendLine(".card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px 18px}");
            html.AppendLine(".card .k{color:var(--muted);font-size:12px;text-transform:uppercase;letter-spacing:.6px}.card .v{font-size:24px;font-weight:700;margin-top:6px}");
            html.AppendLine(".meta{color:var(--muted);font-size:12px;margin:8px 0 18px;word-break:break-word}");
            html.AppendLine("table{width:100%;border-collapse:collapse;background:#fff;border:1px solid var(--line);border-radius:14px;overflow:hidden}");
            html.AppendLine("thead th{background:#f8fafc;color:var(--muted);font-size:11px;text-transform:uppercase;letter-spacing:.5px;text-align:left;padding:11px 12px;border-bottom:1px solid var(--line)}");
            html.AppendLine("tbody td{padding:10px 12px;border-bottom:1px solid #eef2f7;vertical-align:top;font-size:13px}");
            html.AppendLine("tbody tr:hover{background:#f8fbff}.g{font-weight:700;color:var(--accent);white-space:nowrap}");
            html.AppendLine(".keep{color:var(--ok);font-weight:700}.del{color:var(--danger);font-weight:700}.path{word-break:break-all;color:#334155}");
            html.AppendLine(".hash{font:11px ui-monospace,Consolas,monospace;color:#94a3b8;word-break:break-all}.num{text-align:right;white-space:nowrap}");
            html.AppendLine("footer{color:var(--muted);font-size:12px;margin-top:18px}.issues{margin-top:18px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:16px 18px}");
            html.AppendLine("@media(max-width:800px){.cards{grid-template-columns:1fr 1fr}table{display:block;overflow-x:auto}}");
            html.AppendLine("</style></head><body><div class=\"wrap\">");
            html.AppendLine("<header><h1>DupScan Pro report</h1><p>Duplicate files found by exact content, not just by name.</p></header>");

            html.AppendLine("<div class=\"cards\">");
            AppendCard(html, "Duplicate groups", result.Groups.Count.ToString("N0", CultureInfo.CurrentCulture));
            AppendCard(html, "Redundant copies", result.TotalDuplicateFiles.ToString("N0", CultureInfo.CurrentCulture));
            AppendCard(html, "Reclaimable", FormatUtil.FormatBytes(result.ReclaimableBytes));
            AppendCard(html, "Files scanned", result.FilesScanned.ToString("N0", CultureInfo.CurrentCulture));
            html.AppendLine("</div>");

            html.AppendLine("<div class=\"meta\">Scanned " + result.CompletedAt.ToString("dd MMM yyyy, HH:mm", CultureInfo.CurrentCulture) +
                " in " + FormatUtil.FormatDuration(result.Duration) + " &middot; " +
                result.Roots.Count + " " + FormatUtil.Plural(result.Roots.Count, "location", "locations") +
                " &middot; " + FormatUtil.FormatCount(result.TotalBytesScanned) + " bytes examined &middot; " +
                result.IssueCount + " skipped " + FormatUtil.Plural(result.IssueCount, "item", "items") + "</div>");
            html.AppendLine("<div class=\"meta\"><strong>Locations:</strong> " + Html(string.Join(" &middot; ", result.Roots.ToArray())) + "</div>");

            if (selectedCount > 0)
            {
                html.AppendLine("<div class=\"meta\"><strong>" + selectedCount.ToString("N0", CultureInfo.CurrentCulture) +
                    " files marked for deletion</strong> (" + FormatUtil.FormatBytes(selectedBytes) + ").</div>");
            }

            html.AppendLine("<table><thead><tr><th>Group</th><th>Action</th><th>File</th><th class=\"num\">Size</th><th>Modified</th><th>Full path</th><th>SHA-256</th></tr></thead><tbody>");
            for (int i = 0; i < result.Groups.Count; i++)
            {
                DuplicateGroup group = result.Groups[i];
                for (int j = 0; j < group.Files.Count; j++)
                {
                    DuplicateFile file = group.Files[j];
                    html.Append("<tr><td class=\"g\">G").Append(group.Id).Append("</td><td class=\"")
                        .Append(file.SelectedForDeletion ? "del" : "keep").Append("\">")
                        .Append(file.SelectedForDeletion ? "DELETE" : "KEEP").Append("</td><td>")
                        .Append(Html(file.File.Name)).Append("</td><td class=\"num\">")
                        .Append(Html(file.File.SizeText)).Append("</td><td>")
                        .Append(Html(file.File.ModifiedText)).Append("</td><td class=\"path\">")
                        .Append(Html(file.File.Folder)).Append("</td><td class=\"hash\">")
                        .Append(Html(file.File.FullHash)).Append("</td></tr>");
                    html.AppendLine();
                }
            }
            html.AppendLine("</tbody></table>");

            if (result.Issues.Count > 0)
            {
                html.AppendLine("<div class=\"issues\"><strong>Skipped items</strong>");
                html.AppendLine("<p class=\"meta\">Some files or folders could not be read. Run DupScan Pro as administrator if you need to include them.</p><table><thead><tr><th>Path</th><th>Reason</th></tr></thead><tbody>");
                int limit = Math.Min(result.Issues.Count, 200);
                for (int i = 0; i < limit; i++)
                {
                    ScanIssue issue = result.Issues[i];
                    html.Append("<tr><td class=\"path\">").Append(Html(issue.Path)).Append("</td><td>")
                        .Append(Html(issue.Message)).Append("</td></tr>");
                    html.AppendLine();
                }
                html.AppendLine("</tbody></table></div>");
            }

            html.AppendLine("<footer>Generated by DupScan Pro 1.1 &middot; " + DateTime.Now.ToString("dd MMM yyyy, HH:mm", CultureInfo.CurrentCulture) + "</footer>");
            html.AppendLine("</div></body></html>");

            File.WriteAllText(path, html.ToString(), new UTF8Encoding(true));
        }

        private static void AppendCard(StringBuilder html, string title, string value)
        {
            html.Append("<div class=\"card\"><div class=\"k\">").Append(Html(title)).Append("</div><div class=\"v\">")
                .Append(Html(value)).Append("</div></div>");
            html.AppendLine();
        }

        private static string Html(string text)
        {
            if (string.IsNullOrEmpty(text)) return string.Empty;
            return text.Replace("&", "&amp;").Replace("<", "&lt;").Replace(">", "&gt;")
                .Replace("\"", "&quot;").Replace("'", "&#39;");
        }

        private static string Csv(string value)
        {
            if (value == null) return string.Empty;
            bool quote = value.IndexOf(',') >= 0 || value.IndexOf('"') >= 0 ||
                         value.IndexOf('\r') >= 0 || value.IndexOf('\n') >= 0;
            string text = value.Replace("\"", "\"\"");
            return quote ? "\"" + text + "\"" : text;
        }
    }
}
