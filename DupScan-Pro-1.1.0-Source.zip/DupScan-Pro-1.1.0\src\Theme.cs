using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DupScan
{
    public static class Theme
    {
        public static readonly Color Background = Color.FromArgb(244, 247, 251);
        public static readonly Color Surface = Color.White;
        public static readonly Color SurfaceAlt = Color.FromArgb(248, 250, 252);
        public static readonly Color Sidebar = Color.FromArgb(250, 251, 253);
        public static readonly Color HeaderStart = Color.FromArgb(15, 23, 42);
        public static readonly Color HeaderEnd = Color.FromArgb(30, 58, 138);
        public static readonly Color Accent = Color.FromArgb(37, 99, 235);
        public static readonly Color AccentHover = Color.FromArgb(29, 78, 216);
        public static readonly Color AccentSoft = Color.FromArgb(219, 234, 254);
        public static readonly Color AccentFaint = Color.FromArgb(239, 246, 255);
        public static readonly Color Text = Color.FromArgb(15, 23, 42);
        public static readonly Color Muted = Color.FromArgb(100, 116, 139);
        public static readonly Color Faint = Color.FromArgb(148, 163, 184);
        public static readonly Color Border = Color.FromArgb(226, 232, 240);
        public static readonly Color BorderStrong = Color.FromArgb(203, 213, 225);
        public static readonly Color Danger = Color.FromArgb(220, 38, 38);
        public static readonly Color DangerHover = Color.FromArgb(185, 28, 28);
        public static readonly Color DangerSoft = Color.FromArgb(254, 226, 226);
        public static readonly Color Success = Color.FromArgb(5, 150, 105);
        public static readonly Color SuccessSoft = Color.FromArgb(209, 250, 229);
        public static readonly Color Warning = Color.FromArgb(217, 119, 6);
        public static readonly Color WarningSoft = Color.FromArgb(254, 243, 199);
        public static readonly Color RowAlt = Color.FromArgb(248, 250, 252);
        public static readonly Color Selection = Color.FromArgb(219, 234, 254);
        public static readonly Color GridLine = Color.FromArgb(238, 242, 247);

        public static readonly Font BaseFont = new Font("Segoe UI", 9.5f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font SmallFont = new Font("Segoe UI", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font TinyFont = new Font("Segoe UI", 8f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font BoldFont = new Font("Segoe UI", 9.5f, FontStyle.Bold, GraphicsUnit.Point);
        public static readonly Font SemiboldFont = new Font("Segoe UI Semibold", 9.5f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font H1Font = new Font("Segoe UI", 24f, FontStyle.Bold, GraphicsUnit.Point);
        public static readonly Font H2Font = new Font("Segoe UI", 13.5f, FontStyle.Bold, GraphicsUnit.Point);
        public static readonly Font H3Font = new Font("Segoe UI Semibold", 10.5f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font ValueFont = new Font("Segoe UI", 20f, FontStyle.Bold, GraphicsUnit.Point);
        public static readonly Font ButtonFont = new Font("Segoe UI Semibold", 9.5f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font MonoFont = new Font("Consolas", 8.5f, FontStyle.Regular, GraphicsUnit.Point);
        public static readonly Font SymbolFont = new Font("Segoe UI Symbol", 12f, FontStyle.Regular, GraphicsUnit.Point);

        public static GraphicsPath RoundRect(RectangleF bounds, float radius)
        {
            GraphicsPath path = new GraphicsPath();
            if (radius <= 0)
            {
                path.AddRectangle(bounds);
                return path;
            }

            float diameter = radius * 2f;
            if (diameter > bounds.Width) diameter = bounds.Width;
            if (diameter > bounds.Height) diameter = bounds.Height;

            RectangleF arc = new RectangleF(bounds.X, bounds.Y, diameter, diameter);
            path.AddArc(arc, 180, 90);
            arc.X = bounds.Right - diameter;
            path.AddArc(arc, 270, 90);
            arc.Y = bounds.Bottom - diameter;
            path.AddArc(arc, 0, 90);
            arc.X = bounds.X;
            path.AddArc(arc, 90, 90);
            path.CloseFigure();
            return path;
        }

        public static void FillRoundRect(Graphics graphics, RectangleF bounds, float radius, Color color)
        {
            using (GraphicsPath path = RoundRect(bounds, radius))
            using (SolidBrush brush = new SolidBrush(color))
            {
                graphics.FillPath(brush, path);
            }
        }

        public static void DrawRoundRect(Graphics graphics, RectangleF bounds, float radius, Color color, float width)
        {
            using (GraphicsPath path = RoundRect(bounds, radius))
            using (Pen pen = new Pen(color, width))
            {
                graphics.DrawPath(pen, path);
            }
        }

        public static void EnableSmoothing(Graphics graphics)
        {
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
            graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;
        }

        public static Color Blend(Color a, Color b, double amount)
        {
            amount = Math.Max(0, Math.Min(1, amount));
            return Color.FromArgb(
                (int)(a.A + (b.A - a.A) * amount),
                (int)(a.R + (b.R - a.R) * amount),
                (int)(a.G + (b.G - a.G) * amount),
                (int)(a.B + (b.B - a.B) * amount));
        }

        public static Label MakeLabel(string text, Font font, Color color)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = font;
            label.ForeColor = color;
            label.BackColor = Color.Transparent;
            label.AutoSize = true;
            return label;
        }
    }
}
