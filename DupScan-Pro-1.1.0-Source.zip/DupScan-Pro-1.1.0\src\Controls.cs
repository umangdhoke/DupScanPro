using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace DupScan
{
    public enum FlatButtonStyle
    {
        Primary,
        Secondary,
        Ghost,
        Danger,
        Success
    }

    public sealed class FlatButton : Button
    {
        private bool _hover;
        private bool _pressed;
        private FlatButtonStyle _style = FlatButtonStyle.Secondary;
        private int _cornerRadius = 8;

        public FlatButtonStyle Style
        {
            get { return _style; }
            set { _style = value; Invalidate(); }
        }

        public int CornerRadius
        {
            get { return _cornerRadius; }
            set { _cornerRadius = value; Invalidate(); }
        }

        public FlatButton()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 0;
            UseVisualStyleBackColor = false;
            BackColor = Color.Transparent;
            Font = Theme.ButtonFont;
            Cursor = Cursors.Hand;
            Height = 38;
            TabStop = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            RectangleF bounds = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Color back;
            Color fore;
            Color border;

            if (!Enabled)
            {
                back = Color.FromArgb(241, 245, 249);
                fore = Theme.Faint;
                border = Theme.Border;
                if (Style == FlatButtonStyle.Ghost) back = Color.Transparent;
            }
            else if (Style == FlatButtonStyle.Primary)
            {
                back = _pressed ? Theme.AccentHover : (_hover ? Theme.AccentHover : Theme.Accent);
                fore = Color.White;
                border = back;
            }
            else if (Style == FlatButtonStyle.Danger)
            {
                back = _pressed ? Theme.DangerHover : (_hover ? Theme.DangerHover : Theme.Danger);
                fore = Color.White;
                border = back;
            }
            else if (Style == FlatButtonStyle.Success)
            {
                back = _pressed ? Color.FromArgb(4, 120, 87) : (_hover ? Color.FromArgb(4, 120, 87) : Theme.Success);
                fore = Color.White;
                border = back;
            }
            else if (Style == FlatButtonStyle.Ghost)
            {
                back = _hover ? Theme.AccentSoft : Color.Transparent;
                fore = Theme.Accent;
                border = Color.Transparent;
            }
            else
            {
                back = _hover ? Theme.SurfaceAlt : Theme.Surface;
                fore = Theme.Text;
                border = _hover ? Theme.BorderStrong : Theme.Border;
            }

            if (back.A > 0)
            {
                Theme.FillRoundRect(e.Graphics, bounds, _cornerRadius, back);
            }
            if (border.A > 0)
            {
                Theme.DrawRoundRect(e.Graphics, bounds, _cornerRadius, border, 1f);
            }

            Rectangle textBounds = Rectangle.Inflate(ClientRectangle, -6, -2);
            TextRenderer.DrawText(e.Graphics, Text, Font, textBounds, fore,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter |
                TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);

            if (Focused && ShowFocusCues)
            {
                Rectangle focus = Rectangle.Inflate(ClientRectangle, -4, -4);
                ControlPaint.DrawFocusRectangle(e.Graphics, focus, fore, Color.Transparent);
            }
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            _hover = true;
            Invalidate();
            base.OnMouseEnter(e);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            _hover = false;
            _pressed = false;
            Invalidate();
            base.OnMouseLeave(e);
        }

        protected override void OnMouseDown(MouseEventArgs mevent)
        {
            _pressed = true;
            Invalidate();
            base.OnMouseDown(mevent);
        }

        protected override void OnMouseUp(MouseEventArgs mevent)
        {
            _pressed = false;
            Invalidate();
            base.OnMouseUp(mevent);
        }

        protected override void OnEnabledChanged(EventArgs e)
        {
            Invalidate();
            base.OnEnabledChanged(e);
        }
    }

    public class CardPanel : Panel
    {
        private int _cornerRadius = 14;
        private Color _borderColor = Theme.Border;
        private bool _drawBorder = true;

        public int CornerRadius
        {
            get { return _cornerRadius; }
            set { _cornerRadius = value; UpdateRegion(); Invalidate(); }
        }

        public Color BorderColor
        {
            get { return _borderColor; }
            set { _borderColor = value; Invalidate(); }
        }

        public bool DrawBorder
        {
            get { return _drawBorder; }
            set { _drawBorder = value; Invalidate(); }
        }

        public CardPanel()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Padding = new Padding(16);
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            UpdateRegion();
        }

        private void UpdateRegion()
        {
            if (Width <= 0 || Height <= 0) return;
            using (GraphicsPath path = Theme.RoundRect(new RectangleF(0, 0, Width, Height), _cornerRadius))
            {
                Region = new Region(path);
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
            // Painting is handled in OnPaint so the rounded corners stay clean.
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            RectangleF bounds = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            using (GraphicsPath path = Theme.RoundRect(bounds, _cornerRadius))
            {
                using (SolidBrush brush = new SolidBrush(BackColor))
                {
                    e.Graphics.FillPath(brush, path);
                }
                if (_drawBorder)
                {
                    using (Pen pen = new Pen(_borderColor, 1f))
                    {
                        e.Graphics.DrawPath(pen, path);
                    }
                }
            }
        }
    }

    public sealed class GradientHeader : Panel
    {
        public GradientHeader()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.HeaderStart;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            using (LinearGradientBrush brush = new LinearGradientBrush(
                ClientRectangle, Theme.HeaderStart, Theme.HeaderEnd, 18f))
            {
                e.Graphics.FillRectangle(brush, ClientRectangle);
            }

            using (Pen ring = new Pen(Color.FromArgb(26, 255, 255, 255), 1f))
            {
                e.Graphics.DrawEllipse(ring, Width - 220, -130, 330, 330);
                e.Graphics.DrawEllipse(ring, Width - 150, -40, 220, 220);
                e.Graphics.DrawEllipse(ring, Width - 80, 10, 130, 130);
            }

            using (SolidBrush glow = new SolidBrush(Color.FromArgb(18, 56, 189, 248)))
            {
                e.Graphics.FillEllipse(glow, Width - 250, 20, 140, 140);
            }
        }
    }

    public sealed class LogoMark : Control
    {
        private Color _colorA = Color.FromArgb(59, 130, 246);
        private Color _colorB = Color.FromArgb(29, 78, 216);

        public Color ColorA
        {
            get { return _colorA; }
            set { _colorA = value; Invalidate(); }
        }

        public Color ColorB
        {
            get { return _colorB; }
            set { _colorB = value; Invalidate(); }
        }

        public LogoMark()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Size = new Size(52, 52);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            float scale = Math.Min(Width, Height) / 52f;
            e.Graphics.ScaleTransform(scale, scale);

            RectangleF badge = new RectangleF(0.5f, 0.5f, 51f, 51f);
            using (GraphicsPath path = Theme.RoundRect(badge, 14f))
            using (LinearGradientBrush brush = new LinearGradientBrush(
                new RectangleF(0, 0, 52, 52), _colorA, _colorB, 45f))
            {
                e.Graphics.FillPath(brush, path);
            }

            using (SolidBrush white = new SolidBrush(Color.FromArgb(238, 255, 255, 255)))
            using (SolidBrush accent = new SolidBrush(Color.FromArgb(180, 30, 64, 175)))
            {
                using (GraphicsPath backPage = Theme.RoundRect(new RectangleF(12, 9, 22, 27), 3f))
                {
                    e.Graphics.FillPath(white, backPage);
                }
                using (GraphicsPath frontPage = Theme.RoundRect(new RectangleF(20, 15, 21, 26), 3f))
                {
                    e.Graphics.FillPath(white, frontPage);
                }

                e.Graphics.FillRectangle(accent, 24, 21, 13, 2);
                e.Graphics.FillRectangle(accent, 24, 26, 13, 2);
                e.Graphics.FillRectangle(accent, 24, 31, 9, 2);
            }

            using (Pen glass = new Pen(Color.White, 2.6f))
            {
                glass.StartCap = LineCap.Round;
                glass.EndCap = LineCap.Round;
                e.Graphics.DrawEllipse(glass, 29f, 29f, 12f, 12f);
                e.Graphics.DrawLine(glass, 39f, 39f, 45f, 45f);
            }

            e.Graphics.ResetTransform();
        }
    }

    public sealed class ProBadge : Control
    {
        public ProBadge()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Font = new Font("Segoe UI", 8f, FontStyle.Bold);
            Size = new Size(44, 22);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            RectangleF bounds = new RectangleF(0, 0, Width - 1, Height - 1);
            Theme.FillRoundRect(e.Graphics, bounds, Height / 2f, Color.FromArgb(245, 158, 11));
            TextRenderer.DrawText(e.Graphics, "PRO", Font, ClientRectangle,
                Color.FromArgb(30, 41, 59),
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
        }
    }

    public sealed class SummaryCard : Control
    {
        private string _caption = string.Empty;
        private string _value = "0";
        private string _hint = string.Empty;
        private Color _accent = Theme.Accent;

        public string Caption
        {
            get { return _caption; }
            set { _caption = value; Invalidate(); }
        }

        public string Value
        {
            get { return _value; }
            set { _value = value; Invalidate(); }
        }

        public string Hint
        {
            get { return _hint; }
            set { _hint = value; Invalidate(); }
        }

        public Color Accent
        {
            get { return _accent; }
            set { _accent = value; Invalidate(); }
        }

        public SummaryCard()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
            Height = 94;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            RectangleF bounds = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Theme.FillRoundRect(e.Graphics, bounds, 14f, Theme.Surface);
            Theme.DrawRoundRect(e.Graphics, bounds, 14f, Theme.Border, 1f);

            using (SolidBrush accentBrush = new SolidBrush(_accent))
            using (GraphicsPath bar = Theme.RoundRect(new RectangleF(0, 20, 4, Height - 40), 2f))
            {
                e.Graphics.FillPath(accentBrush, bar);
            }

            TextRenderer.DrawText(e.Graphics, _caption.ToUpperInvariant(), Theme.TinyFont,
                new Rectangle(18, 14, Width - 32, 16), Theme.Muted,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            TextRenderer.DrawText(e.Graphics, _value, Theme.ValueFont,
                new Rectangle(16, 30, Width - 30, 34), Theme.Text,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            TextRenderer.DrawText(e.Graphics, _hint, Theme.SmallFont,
                new Rectangle(18, Height - 26, Width - 30, 16), Theme.Muted,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
        }
    }

    public sealed class SearchBox : Panel
    {
        private readonly TextBox _input;
        private string _cue = "Search duplicates...";
        private bool _focused;

        public TextBox Input
        {
            get { return _input; }
        }

        public string Cue
        {
            get { return _cue; }
            set
            {
                _cue = value;
                if (_input.IsHandleCreated)
                {
                    NativeMethods.SendMessage(_input.Handle, NativeMethods.EM_SETCUEBANNER, (IntPtr)1, _cue);
                }
            }
        }

        public SearchBox()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            BackColor = Theme.Surface;
            Height = 36;

            _input = new TextBox();
            _input.BorderStyle = BorderStyle.None;
            _input.Font = Theme.BaseFont;
            _input.ForeColor = Theme.Text;
            _input.BackColor = Theme.Surface;
            _input.Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Right;
            _input.TextChanged += delegate
            {
                Invalidate();
                OnTextChanged(EventArgs.Empty);
            };
            _input.Enter += delegate { _focused = true; Invalidate(); };
            _input.Leave += delegate { _focused = false; Invalidate(); };
            _input.HandleCreated += delegate
            {
                NativeMethods.SendMessage(_input.Handle, NativeMethods.EM_SETCUEBANNER, (IntPtr)1, _cue);
            };
            Controls.Add(_input);

            UpdateInputBounds();
            UpdateRegion();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            if (_input.IsHandleCreated)
            {
                NativeMethods.SendMessage(_input.Handle, NativeMethods.EM_SETCUEBANNER, (IntPtr)1, _cue);
            }
        }

        protected override void OnResize(EventArgs eventargs)
        {
            base.OnResize(eventargs);
            UpdateInputBounds();
            UpdateRegion();
        }

        private void UpdateInputBounds()
        {
            if (_input == null) return;
            _input.SetBounds(34, 8, Math.Max(20, Width - 44), 22);
        }

        private void UpdateRegion()
        {
            if (Width <= 0 || Height <= 0) return;
            using (GraphicsPath path = Theme.RoundRect(new RectangleF(0, 0, Width, Height), 9f))
            {
                Region = new Region(path);
            }
        }

        protected override void OnPaintBackground(PaintEventArgs e)
        {
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            RectangleF bounds = new RectangleF(0.5f, 0.5f, Width - 1f, Height - 1f);
            Theme.FillRoundRect(e.Graphics, bounds, 9f, Theme.Surface);
            Theme.DrawRoundRect(e.Graphics, bounds, 9f, _focused ? Theme.Accent : Theme.BorderStrong, _focused ? 1.6f : 1f);

            using (Pen pen = new Pen(Theme.Faint, 1.5f))
            {
                pen.StartCap = LineCap.Round;
                pen.EndCap = LineCap.Round;
                e.Graphics.DrawEllipse(pen, 10f, 10f, 9f, 9f);
                e.Graphics.DrawLine(pen, 18f, 18f, 23f, 23f);
            }
        }

        public new bool Focus()
        {
            return _input.Focus();
        }
    }

    public sealed class PathListBox : ListBox
    {
        public PathListBox()
        {
            DrawMode = DrawMode.OwnerDrawFixed;
            ItemHeight = 30;
            BorderStyle = BorderStyle.None;
            BackColor = Theme.SurfaceAlt;
            Font = Theme.BaseFont;
            ForeColor = Theme.Text;
            IntegralHeight = false;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            if (Items.Count == 0)
            {
                TextRenderer.DrawText(e.Graphics, "No folders or drives added yet", Theme.SmallFont,
                    new Rectangle(10, 8, Width - 20, 24), Theme.Faint,
                    TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            }
        }

        protected override void OnDrawItem(DrawItemEventArgs e)
        {
            if (e.Index < 0 || e.Index >= Items.Count) return;

            bool selected = (e.State & DrawItemState.Selected) == DrawItemState.Selected;
            Color back = selected ? Theme.AccentSoft : Theme.SurfaceAlt;
            using (SolidBrush brush = new SolidBrush(back))
            {
                e.Graphics.FillRectangle(brush, e.Bounds);
            }

            Rectangle iconRect = new Rectangle(e.Bounds.X + 8, e.Bounds.Y + 8, 15, 12);
            using (SolidBrush folder = new SolidBrush(selected ? Theme.Accent : Color.FromArgb(245, 158, 11)))
            {
                e.Graphics.FillRectangle(folder, iconRect.X, iconRect.Y + 2, iconRect.Width, iconRect.Height - 2);
                e.Graphics.FillRectangle(folder, iconRect.X + 1, iconRect.Y, 7, 4);
            }

            string text = Convert.ToString(Items[e.Index]);
            Rectangle textRect = new Rectangle(e.Bounds.X + 30, e.Bounds.Y,
                Math.Max(10, e.Bounds.Width - 38), e.Bounds.Height);
            TextRenderer.DrawText(e.Graphics, text, Font, textRect,
                selected ? Theme.Text : Theme.Text,
                TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis |
                TextFormatFlags.NoPrefix);
        }
    }

    public sealed class BufferedDataGridView : DataGridView
    {
        public BufferedDataGridView()
        {
            DoubleBuffered = true;
        }
    }

    public sealed class EmptyState : Control
    {
        private string _title = "No scan yet";
        private string _subtitle = "Add folders or a drive on the left, then start a scan.";
        private string _footnote = "DupScan Pro compares file content, not just names.";

        public string TitleText
        {
            get { return _title; }
            set { _title = value; Invalidate(); }
        }

        public string SubtitleText
        {
            get { return _subtitle; }
            set { _subtitle = value; Invalidate(); }
        }

        public string FootnoteText
        {
            get { return _footnote; }
            set { _footnote = value; Invalidate(); }
        }

        public EmptyState()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw |
                     ControlStyles.SupportsTransparentBackColor, true);
            BackColor = Color.Transparent;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            int centerX = Width / 2;
            int centerY = Math.Max(170, Height / 2 - 20);

            using (SolidBrush halo = new SolidBrush(Theme.AccentFaint))
            {
                e.Graphics.FillEllipse(halo, centerX - 58, centerY - 135, 116, 116);
            }
            using (Pen ring = new Pen(Theme.AccentSoft, 1.5f))
            {
                e.Graphics.DrawEllipse(ring, centerX - 58, centerY - 135, 116, 116);
            }
            using (Pen search = new Pen(Theme.Accent, 4f))
            {
                search.StartCap = LineCap.Round;
                search.EndCap = LineCap.Round;
                e.Graphics.DrawEllipse(search, centerX - 28, centerY - 105, 42, 42);
                e.Graphics.DrawLine(search, centerX + 6, centerY - 70, centerX + 30, centerY - 46);
            }

            Rectangle titleRect = new Rectangle(24, centerY + 2, Width - 48, 30);
            TextRenderer.DrawText(e.Graphics, _title, Theme.H2Font, titleRect, Theme.Text,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);

            Rectangle subtitleRect = new Rectangle(Math.Max(24, centerX - 250), centerY + 38, Math.Min(500, Width - 48), 44);
            TextRenderer.DrawText(e.Graphics, _subtitle, Theme.BaseFont, subtitleRect, Theme.Muted,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.Top | TextFormatFlags.WordBreak);

            if (!string.IsNullOrEmpty(_footnote))
            {
                Rectangle footRect = new Rectangle(24, centerY + 90, Width - 48, 22);
                TextRenderer.DrawText(e.Graphics, _footnote, Theme.SmallFont, footRect, Theme.Faint,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis);
            }
        }
    }

    public sealed class Divider : Control
    {
        private Color _lineColor = Theme.Border;

        public Color LineColor
        {
            get { return _lineColor; }
            set { _lineColor = value; Invalidate(); }
        }

        public Divider()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = 1;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using (Pen pen = new Pen(_lineColor, 1f))
            {
                e.Graphics.DrawLine(pen, 0, 0, Width, 0);
            }
        }
    }

    public sealed class ProgressTrack : Control
    {
        private int _value;
        private bool _marquee;
        private int _marqueeOffset;
        private readonly Timer _timer;

        public int Value
        {
            get { return _value; }
            set
            {
                int next = Math.Max(0, Math.Min(100, value));
                if (_value != next)
                {
                    _value = next;
                    Invalidate();
                }
            }
        }

        public bool Marquee
        {
            get { return _marquee; }
            set
            {
                if (_marquee != value)
                {
                    _marquee = value;
                    if (_marquee) _timer.Start(); else _timer.Stop();
                    Invalidate();
                }
            }
        }

        public ProgressTrack()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint |
                     ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
            Height = 8;
            _timer = new Timer();
            _timer.Interval = 35;
            _timer.Tick += delegate
            {
                _marqueeOffset = (_marqueeOffset + 4) % Math.Max(1, Width + 80);
                Invalidate();
            };
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Theme.EnableSmoothing(e.Graphics);
            RectangleF track = new RectangleF(0, 0, Width, Height);
            Theme.FillRoundRect(e.Graphics, track, Height / 2f, Color.FromArgb(226, 232, 240));

            if (_marquee)
            {
                float width = Math.Max(70f, Width * 0.28f);
                float x = (float)((_marqueeOffset % Math.Max(1, Width + (int)width)) - width);
                RectangleF bar = new RectangleF(x, 0, width, Height);
                using (GraphicsPath path = Theme.RoundRect(bar, Height / 2f))
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    new RectangleF(x - 1, 0, width + 2, Height), Color.FromArgb(147, 197, 253), Theme.Accent, 0f))
                {
                    e.Graphics.FillPath(brush, path);
                }
            }
            else
            {
                if (_value <= 0) return;
                float width = Width * (_value / 100f);
                if (width < Height) width = Height;
                RectangleF bar = new RectangleF(0, 0, Math.Min(Width, width), Height);
                using (GraphicsPath path = Theme.RoundRect(bar, Height / 2f))
                using (LinearGradientBrush brush = new LinearGradientBrush(
                    new RectangleF(0, 0, Math.Max(1, bar.Width), Height), Color.FromArgb(96, 165, 250), Theme.Accent, 0f))
                {
                    e.Graphics.FillPath(brush, path);
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _timer.Stop();
                _timer.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
