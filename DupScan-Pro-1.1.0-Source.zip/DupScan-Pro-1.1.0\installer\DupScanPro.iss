; DupScan Pro 1.1 installer
; Build with: installer\tools\InnoSetup6\app\ISCC.exe installer\DupScanPro.iss

#define MyAppName "DupScan Pro"
#define MyAppVersion "1.1.0"
#define MyAppPublisher "DupScan Pro"
#define MyAppExeName "DupScan.exe"
#define MyAppId "{{8E6D4A2B-6F1C-4A73-9B2E-7D5A1C9F3E41}"

[Setup]
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=commandline
OutputDir=..\dist
OutputBaseFilename=DupScanPro-Setup-{#MyAppVersion}
SetupIconFile=..\assets\app.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
WizardImageFile=wizard-large.bmp
WizardSmallImageFile=wizard-small.bmp
InfoBeforeFile=WhatsNew.txt
WizardImageStretch=no
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
MinVersion=10.0
CloseApplications=yes
RestartApplications=no
SetupLogging=yes
VersionInfoCompany={#MyAppPublisher}
VersionInfoDescription={#MyAppName} Setup
VersionInfoProductName={#MyAppName}
VersionInfoProductVersion={#MyAppVersion}
VersionInfoVersion={#MyAppVersion}.0
VersionInfoCopyright=Copyright (C) 2026 DupScan Pro

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: checkedonce

[Files]
Source: "..\build\DupScan.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\UserGuide.txt"; DestDir: "{app}"; Flags: ignoreversion isreadme
; Bundled .NET Framework 4.8 offline installer. It is only extracted and run
; when the target machine does not already have .NET Framework 4.8.
Source: "deps\NDP48-x86-x64-AllOS-ENU.exe"; DestDir: "{tmp}"; Flags: dontcopy

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"
Name: "{group}\User Guide"; Filename: "{app}\UserGuide.txt"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent
Filename: "{app}\UserGuide.txt"; Description: "Open the DupScan Pro user guide"; Flags: shellexec nowait postinstall skipifsilent unchecked

[UninstallDelete]
Type: filesandordirs; Name: "{app}"

[Code]
var
  NeedDotNet: Boolean;

function GetDotNetRelease: Cardinal;
begin
  if not RegQueryDWordValue(HKLM64, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', Result) then
  begin
    if not RegQueryDWordValue(HKLM, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', Result) then
      Result := 0;
  end;
end;

function InitializeSetup: Boolean;
begin
  NeedDotNet := GetDotNetRelease < 528040;
  Result := True;
end;

procedure InitializeWizard;
begin
  if NeedDotNet then
  begin
    WizardForm.WelcomeLabel2.Caption :=
      WizardForm.WelcomeLabel2.Caption + #13#10#13#10 +
      'Microsoft .NET Framework 4.8 is included in this setup and will be installed automatically if needed.';
    WizardForm.WelcomeLabel2.Height := WizardForm.WelcomeLabel2.Height + 44;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  ResultCode: Integer;
begin
  Result := '';
  if not NeedDotNet then exit;

  WizardForm.StatusLabel.Caption := 'Installing Microsoft .NET Framework 4.8 (this may take a few minutes)...';
  ExtractTemporaryFile('NDP48-x86-x64-AllOS-ENU.exe');

  if not Exec(ExpandConstant('{tmp}\NDP48-x86-x64-AllOS-ENU.exe'),
      '/passive /norestart', '', SW_SHOW, ewWaitUntilTerminated, ResultCode) then
  begin
    Result := 'Setup could not start the bundled Microsoft .NET Framework 4.8 installer.';
    exit;
  end;

  if (ResultCode = 3010) or (ResultCode = 1641) then
    NeedsRestart := True;

  if (ResultCode <> 0) and (ResultCode <> 3010) and (ResultCode <> 1641) then
  begin
    Result := 'Microsoft .NET Framework 4.8 installation failed (code ' + IntToStr(ResultCode) + ').';
    exit;
  end;

  if GetDotNetRelease < 528040 then
  begin
    Result := 'Microsoft .NET Framework 4.8 is not available yet. Restart Windows and run setup again.';
    exit;
  end;

  NeedDotNet := False;
end;
