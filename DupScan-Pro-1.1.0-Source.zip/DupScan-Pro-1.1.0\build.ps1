param(
    [switch]$SkipIcon
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcDir = Join-Path $root "src"
$assetDir = Join-Path $root "assets"
$outDir = Join-Path $root "build"
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"

if (-not (Test-Path $csc)) {
    $csc = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe"
}
if (-not (Test-Path $csc)) {
    throw "The built-in .NET Framework C# compiler (csc.exe) was not found."
}

if (-not $SkipIcon -or -not (Test-Path (Join-Path $assetDir "app.ico"))) {
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "tools\MakeIcon.ps1") | Out-Null
}

New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$sources = Get-ChildItem -Path $srcDir -Filter "*.cs" | Sort-Object Name | ForEach-Object { $_.FullName }
$output = Join-Path $outDir "DupScan.exe"

Write-Host "Compiling DupScan.exe ..."
& $csc /nologo /target:winexe /platform:anycpu /optimize+ /langversion:5 /utf8output `
    "/out:$output" `
    "/win32icon:$(Join-Path $assetDir 'app.ico')" `
    "/win32manifest:$(Join-Path $srcDir 'app.manifest')" `
    "/resource:$(Join-Path $assetDir 'donate-qr.png'),DupScan.donate-qr.png" `
    /reference:System.dll `
    /reference:System.Core.dll `
    /reference:System.Drawing.dll `
    /reference:System.Windows.Forms.dll `
    /main:DupScan.Program `
    $sources

if ($LASTEXITCODE -ne 0) {
    throw "Compilation failed with exit code $LASTEXITCODE."
}

$file = Get-Item $output
Write-Host ("Built: " + $file.FullName + "  (" + [math]::Round($file.Length / 1KB, 1) + " KB)")
