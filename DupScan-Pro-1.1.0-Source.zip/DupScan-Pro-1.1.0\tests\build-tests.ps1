$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$srcDir = Join-Path $root "src"
$outDir = Join-Path $root "build"
$csc = Join-Path $env:WINDIR "Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if (-not (Test-Path $csc)) {
    $csc = Join-Path $env:WINDIR "Microsoft.NET\Framework\v4.0.30319\csc.exe"
}

New-Item -ItemType Directory -Force -Path $outDir | Out-Null

$core = @(
    "Models.cs",
    "Util.cs",
    "NativeMethods.cs",
    "FileHasher.cs",
    "DuplicateScanner.cs",
    "DuplicateDeleter.cs",
    "ReportExporter.cs",
    "SettingsStore.cs"
) | ForEach-Object { Join-Path $srcDir $_ }

$sources = @($core) + @(Join-Path $PSScriptRoot "EngineTests.cs")
$output = Join-Path $outDir "EngineTests.exe"

& $csc /nologo /target:exe /platform:anycpu /optimize+ /langversion:5 /utf8output `
    "/out:$output" `
    /reference:System.dll `
    /reference:System.Core.dll `
    /reference:System.Drawing.dll `
    /main:DupScan.Tests.EngineTests `
    $sources

if ($LASTEXITCODE -ne 0) {
    throw "Test compilation failed with exit code $LASTEXITCODE."
}

Write-Host ("Built: " + $output)
& $output
exit $LASTEXITCODE
