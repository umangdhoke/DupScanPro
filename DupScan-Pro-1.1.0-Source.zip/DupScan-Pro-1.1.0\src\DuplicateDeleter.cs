using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace DupScan
{
    public static class DuplicateDeleter
    {
        public static bool ValidateSelection(ScanResult result, out string error)
        {
            error = null;
            if (result == null || result.Groups == null)
            {
                error = "There is no scan result to work with.";
                return false;
            }

            int selected = 0;
            StringBuilder problems = new StringBuilder();

            for (int i = 0; i < result.Groups.Count; i++)
            {
                DuplicateGroup group = result.Groups[i];
                int groupSelected = 0;
                for (int j = 0; j < group.Files.Count; j++)
                {
                    DuplicateFile file = group.Files[j];
                    if (!file.SelectedForDeletion) continue;
                    groupSelected++;
                    selected++;

                    if (PathUtil.IsProtectedSystemPath(file.File.Path))
                    {
                        AppendProblem(problems, "Protected Windows/Program Files location: " + file.File.Path);
                    }
                }

                if (groupSelected > 0 && groupSelected >= group.Files.Count)
                {
                    AppendProblem(problems, "Every copy in group " + group.Id + " is selected. Keep at least one copy.");
                }
            }

            if (selected == 0)
            {
                error = "Select at least one duplicate file to delete.";
                return false;
            }

            if (problems.Length > 0)
            {
                error = problems.ToString();
                return false;
            }

            return true;
        }

        public static DeleteOutcome DeleteSelected(ScanResult result, DeleteMode mode, bool verify,
            IProgress<DeleteProgress> progress, CancellationToken token)
        {
            string validationError;
            if (!ValidateSelection(result, out validationError))
            {
                throw new InvalidOperationException(validationError);
            }

            DeleteOutcome outcome = new DeleteOutcome();
            List<FileRecord> selected = new List<FileRecord>();
            for (int i = 0; i < result.Groups.Count; i++)
            {
                DuplicateGroup group = result.Groups[i];
                for (int j = 0; j < group.Files.Count; j++)
                {
                    if (group.Files[j].SelectedForDeletion) selected.Add(group.Files[j].File);
                }
            }

            int total = selected.Count;
            int current = 0;

            for (int i = 0; i < selected.Count; i++)
            {
                if (token.IsCancellationRequested)
                {
                    outcome.WasCancelled = true;
                    break;
                }

                FileRecord file = selected[i];
                current++;

                DeleteProgress verifyProgress = new DeleteProgress();
                verifyProgress.Current = current - 1;
                verifyProgress.Total = total;
                verifyProgress.CurrentPath = file.Path;
                verifyProgress.Message = verify ? "Checking file before deleting..." : "Deleting...";
                if (progress != null) progress.Report(verifyProgress);

                string failure;
                if (!CheckFileStillMatches(file, verify, token, out failure))
                {
                    AddFailure(outcome, file, failure);
                    Log(file, mode, "SKIPPED", failure);
                    continue;
                }

                try
                {
                    if (mode == DeleteMode.RecycleBin)
                    {
                        if (!DriveUtil.IsFixedDrive(file.Path))
                        {
                            AddFailure(outcome, file, "Recycle Bin is only available for local fixed drives. Use permanent delete for this file.");
                            Log(file, mode, "FAILED", "Recycle Bin unavailable for drive type");
                            continue;
                        }

                        int code = NativeMethods.MoveToRecycleBin(file.Path);
                        if (code != 0 || File.Exists(file.Path))
                        {
                            string reason = code == 0
                                ? "The file still exists after the Recycle Bin operation."
                                : "Recycle Bin error 0x" + code.ToString("X", CultureInfo.InvariantCulture) + ".";
                            AddFailure(outcome, file, reason + " The Recycle Bin may be disabled or full.");
                            Log(file, mode, "FAILED", reason);
                            continue;
                        }

                        DeletedItem item = new DeletedItem();
                        item.File = file;
                        item.Recycled = true;
                        outcome.Succeeded.Add(item);
                        outcome.BytesRecycled += file.Size;
                        Log(file, mode, "RECYCLED", "Moved to Recycle Bin");
                    }
                    else
                    {
                        FileAttributes attributes = File.GetAttributes(file.Path);
                        if ((attributes & FileAttributes.ReadOnly) != 0)
                        {
                            File.SetAttributes(file.Path, attributes & ~FileAttributes.ReadOnly);
                        }
                        File.Delete(file.Path);
                        if (File.Exists(file.Path))
                        {
                            AddFailure(outcome, file, "The file still exists after deletion.");
                            Log(file, mode, "FAILED", "File still exists after delete");
                            continue;
                        }

                        DeletedItem item = new DeletedItem();
                        item.File = file;
                        item.Recycled = false;
                        outcome.Succeeded.Add(item);
                        outcome.BytesFreed += file.Size;
                        Log(file, mode, "DELETED", "Permanently deleted");
                    }
                }
                catch (OperationCanceledException)
                {
                    outcome.WasCancelled = true;
                    break;
                }
                catch (Exception ex)
                {
                    AddFailure(outcome, file, ex.Message);
                    Log(file, mode, "FAILED", ex.Message);
                }

                DeleteProgress doneProgress = new DeleteProgress();
                doneProgress.Current = current;
                doneProgress.Total = total;
                doneProgress.CurrentPath = file.Path;
                doneProgress.Message = mode == DeleteMode.RecycleBin ? "Moving to Recycle Bin..." : "Deleting permanently...";
                if (progress != null) progress.Report(doneProgress);
            }

            outcome.LogPath = AppPaths.DeletionLogFile;
            return outcome;
        }

        private static bool CheckFileStillMatches(FileRecord file, bool verify, CancellationToken token, out string error)
        {
            error = null;

            try
            {
                FileInfo info = new FileInfo(PathUtil.ToExtendedPath(file.Path));
                if (!info.Exists)
                {
                    error = "File no longer exists.";
                    return false;
                }

                if ((info.Attributes & FileAttributes.Directory) != 0)
                {
                    error = "Path is a folder, not a file.";
                    return false;
                }

                if (info.Length != file.Size)
                {
                    error = "File size changed since the scan.";
                    return false;
                }

                if (info.LastWriteTimeUtc != file.ModifiedUtc)
                {
                    error = "File was modified since the scan.";
                    return false;
                }

                string identity;
                uint links;
                if (NativeMethods.TryGetFileIdentity(file.Path, out identity, out links))
                {
                    if (links > 1)
                    {
                        error = "File now has multiple hard links; deleting this path would not free space.";
                        return false;
                    }
                    if (!string.IsNullOrEmpty(file.Identity) && !string.Equals(identity, file.Identity, StringComparison.Ordinal))
                    {
                        error = "The file was replaced since the scan.";
                        return false;
                    }
                }

                if (verify)
                {
                    token.ThrowIfCancellationRequested();
                    string hash = FileHasher.FullHash(file.Path, token, null);
                    if (!string.Equals(hash, file.FullHash, StringComparison.Ordinal))
                    {
                        error = "File content no longer matches the scanned duplicate.";
                        return false;
                    }
                }

                return true;
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                error = "Could not verify file: " + ex.Message;
                return false;
            }
        }

        private static void AddFailure(DeleteOutcome outcome, FileRecord file, string reason)
        {
            FailedDelete failed = new FailedDelete();
            failed.File = file;
            failed.Reason = reason;
            outcome.Failed.Add(failed);
        }

        private static void AppendProblem(StringBuilder sb, string message)
        {
            if (sb.Length > 0) sb.AppendLine();
            sb.Append("- ").Append(message);
        }

        private static void Log(FileRecord file, DeleteMode mode, string result, string reason)
        {
            try
            {
                bool writeHeader = !File.Exists(AppPaths.DeletionLogFile);
                using (StreamWriter writer = new StreamWriter(AppPaths.DeletionLogFile, true, new UTF8Encoding(true)))
                {
                    if (writeHeader)
                    {
                        writer.WriteLine("Timestamp,Action,Result,SizeBytes,Path,SHA256,Reason");
                    }

                    writer.Write(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture));
                    writer.Write(",");
                    writer.Write(mode == DeleteMode.RecycleBin ? "RecycleBin" : "Permanent");
                    writer.Write(",");
                    writer.Write(Csv(result));
                    writer.Write(",");
                    writer.Write(file.Size.ToString(CultureInfo.InvariantCulture));
                    writer.Write(",");
                    writer.Write(Csv(file.Path));
                    writer.Write(",");
                    writer.Write(Csv(file.FullHash));
                    writer.Write(",");
                    writer.Write(Csv(reason));
                    writer.WriteLine();
                }
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "Deletion log write failed");
            }
        }

        private static string Csv(string value)
        {
            if (value == null) return string.Empty;
            bool quote = value.IndexOf(',') >= 0 || value.IndexOf('"') >= 0 ||
                         value.IndexOf('\r') >= 0 || value.IndexOf('\n') >= 0;
            string text = value.Replace("\"", "\"\"");
            return quote ? "\"" + text + "\"" : text;
        }
    }
}
