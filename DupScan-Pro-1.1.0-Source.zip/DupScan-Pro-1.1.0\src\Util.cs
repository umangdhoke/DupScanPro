using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;

namespace DupScan
{
    public static class FormatUtil
    {
        private static readonly string[] Units = new string[] { "B", "KB", "MB", "GB", "TB", "PB" };

        public static string FormatBytes(long bytes)
        {
            if (bytes < 0) return "0 B";
            if (bytes < 1024) return bytes.ToString(CultureInfo.InvariantCulture) + " B";

            double value = bytes;
            int unit = 0;
            while (value >= 1024 && unit < Units.Length - 1)
            {
                value /= 1024.0;
                unit++;
            }

            if (value >= 100)
                return value.ToString("0", CultureInfo.InvariantCulture) + " " + Units[unit];
            if (value >= 10)
                return value.ToString("0.0", CultureInfo.InvariantCulture) + " " + Units[unit];
            return value.ToString("0.00", CultureInfo.InvariantCulture) + " " + Units[unit];
        }

        public static string FormatCount(int value)
        {
            return value.ToString("N0", CultureInfo.CurrentCulture);
        }

        public static string FormatCount(long value)
        {
            return value.ToString("N0", CultureInfo.CurrentCulture);
        }

        public static string ShortenPath(string path, int maxLength)
        {
            if (string.IsNullOrEmpty(path) || path.Length <= maxLength || maxLength < 12)
                return path;

            int side = (maxLength - 3) / 2;
            return path.Substring(0, side) + "..." + path.Substring(path.Length - side);
        }

        public static string Plural(int count, string singular, string plural)
        {
            return count == 1 ? singular : plural;
        }

        public static string FormatDuration(TimeSpan span)
        {
            if (span.TotalHours >= 1)
                return ((int)span.TotalHours).ToString(CultureInfo.InvariantCulture) + "h " +
                       span.Minutes.ToString("00", CultureInfo.InvariantCulture) + "m";
            if (span.TotalMinutes >= 1)
                return ((int)span.TotalMinutes).ToString(CultureInfo.InvariantCulture) + "m " +
                       span.Seconds.ToString("00", CultureInfo.InvariantCulture) + "s";
            return Math.Max(0, (int)span.TotalSeconds).ToString(CultureInfo.InvariantCulture) + "s";
        }
    }

    public static class PathUtil
    {
        public static string Normalize(string path)
        {
            if (string.IsNullOrEmpty(path)) return string.Empty;
            string full = path.Trim().Trim('"');
            try
            {
                full = Path.GetFullPath(full);
            }
            catch
            {
                return path.Trim();
            }

            if (full.Length > 3)
                full = full.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);

            return full;
        }

        public static string ToExtendedPath(string path)
        {
            if (string.IsNullOrEmpty(path)) return path;
            if (path.StartsWith(@"\\?\", StringComparison.Ordinal)) return path;
            if (path.Length < 240) return path;

            if (path.StartsWith(@"\\", StringComparison.Ordinal))
                return @"\\?\UNC\" + path.Substring(2);
            return @"\\?\" + path;
        }

        public static bool IsSubPathOf(string candidate, string parent)
        {
            if (string.IsNullOrEmpty(candidate) || string.IsNullOrEmpty(parent)) return false;
            string c = Normalize(candidate);
            string p = Normalize(parent);
            if (string.Equals(c, p, StringComparison.OrdinalIgnoreCase)) return false;
            if (!c.StartsWith(p, StringComparison.OrdinalIgnoreCase)) return false;
            if (p.EndsWith(@"\", StringComparison.Ordinal)) return true;
            return c.Length > p.Length && c[p.Length] == Path.DirectorySeparatorChar;
        }

        public static bool IsProtectedSystemPath(string path)
        {
            string full = Normalize(path);
            if (string.IsNullOrEmpty(full)) return false;

            string[] protectedRoots = new string[]
            {
                Environment.GetFolderPath(Environment.SpecialFolder.Windows),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData)
            };

            for (int i = 0; i < protectedRoots.Length; i++)
            {
                string root = Normalize(protectedRoots[i]);
                if (string.IsNullOrEmpty(root)) continue;
                if (string.Equals(full, root, StringComparison.OrdinalIgnoreCase)) return true;
                if (IsSubPathOf(full, root)) return true;
            }

            return false;
        }

        public static bool IsSamePath(string a, string b)
        {
            return string.Equals(Normalize(a), Normalize(b), StringComparison.OrdinalIgnoreCase);
        }

        public static string GetDirectoryNameSafe(string path)
        {
            try { return Path.GetDirectoryName(path) ?? string.Empty; }
            catch { return string.Empty; }
        }

        public static string GetFileNameSafe(string path)
        {
            try { return Path.GetFileName(path) ?? path; }
            catch { return path; }
        }
    }

    public static class AppPaths
    {
        public static string DataFolder
        {
            get
            {
                string folder = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "DupScan");
                try { Directory.CreateDirectory(folder); } catch { }
                return folder;
            }
        }

        public static string SettingsFile
        {
            get { return Path.Combine(DataFolder, "settings.ini"); }
        }

        public static string LogFolder
        {
            get
            {
                string folder = Path.Combine(DataFolder, "Logs");
                try { Directory.CreateDirectory(folder); } catch { }
                return folder;
            }
        }

        public static string DeletionLogFile
        {
            get
            {
                return Path.Combine(LogFolder,
                    "deletions-" + DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) + ".csv");
            }
        }

        public static string CrashLogFile
        {
            get { return Path.Combine(LogFolder, "crash.log"); }
        }
    }

    public static class AppLog
    {
        private static readonly object Sync = new object();

        public static void Crash(Exception ex, string context)
        {
            try
            {
                lock (Sync)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendLine("============================================================");
                    sb.AppendLine(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  " + context);
                    sb.AppendLine(ex == null ? "(null exception)" : ex.ToString());
                    File.AppendAllText(AppPaths.CrashLogFile, sb.ToString(), Encoding.UTF8);
                }
            }
            catch { }
        }

        public static void Info(string message)
        {
            try
            {
                lock (Sync)
                {
                    File.AppendAllText(AppPaths.CrashLogFile,
                        DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) + "  INFO  " + message + Environment.NewLine,
                        Encoding.UTF8);
                }
            }
            catch { }
        }
    }

    public static class ShellUtil
    {
        public static void OpenFile(string path)
        {
            try
            {
                Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "OpenFile: " + path);
            }
        }

        public static void OpenFolder(string path)
        {
            try
            {
                if (string.IsNullOrEmpty(path) || !Directory.Exists(path))
                {
                    path = PathUtil.GetDirectoryNameSafe(path);
                }
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + path + "\"") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "OpenFolder: " + path);
            }
        }

        public static void SelectInExplorer(string path)
        {
            try
            {
                Process.Start(new ProcessStartInfo("explorer.exe", "/select,\"" + path + "\"") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "SelectInExplorer: " + path);
            }
        }

        public static void OpenRecycleBin()
        {
            try
            {
                Process.Start(new ProcessStartInfo("shell:RecycleBinFolder") { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "OpenRecycleBin");
            }
        }
    }

    public static class DriveUtil
    {
        public static List<DriveInfo> GetReadyDrives()
        {
            List<DriveInfo> result = new List<DriveInfo>();
            try
            {
                DriveInfo[] drives = DriveInfo.GetDrives();
                for (int i = 0; i < drives.Length; i++)
                {
                    try
                    {
                        if (drives[i].IsReady &&
                            (drives[i].DriveType == DriveType.Fixed ||
                             drives[i].DriveType == DriveType.Removable ||
                             drives[i].DriveType == DriveType.Network))
                        {
                            result.Add(drives[i]);
                        }
                    }
                    catch { }
                }
            }
            catch { }
            return result;
        }

        public static bool IsFixedDrive(string path)
        {
            try
            {
                string root = Path.GetPathRoot(Path.GetFullPath(path));
                if (string.IsNullOrEmpty(root)) return false;
                DriveInfo drive = new DriveInfo(root);
                return drive.DriveType == DriveType.Fixed;
            }
            catch
            {
                return false;
            }
        }
    }
}
