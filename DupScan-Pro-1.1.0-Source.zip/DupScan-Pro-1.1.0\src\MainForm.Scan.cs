using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DupScan
{
    public sealed partial class MainForm
    {
        private async void StartScan()
        {
            if (_isScanning) return;

            if (_roots.Count == 0)
            {
                MessageBox.Show(this,
                    "Add at least one folder or drive on the left before scanning.",
                    "Nothing to scan", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string missing = FirstMissingRoot();
            if (missing != null)
            {
                MessageBox.Show(this,
                    "This scan location is no longer available:\r\n\r\n" + missing +
                    "\r\n\r\nReconnect the drive or remove it from the list.",
                    "Location unavailable", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveSettingsFromUi();
            ScanOptions options = BuildOptions();

            _isScanning = true;
            _closeWhenDone = false;
            _scanCts = new CancellationTokenSource();
            _scanProgress = new Progress<ScanProgress>(OnScanProgress);
            ResetForScan();
            SetInputsEnabled(false);
            _scanButton.Text = "Scanning...";
            _scanButton.Enabled = false;
            _cancelButton.Visible = true;
            _cancelButton.Enabled = true;
            _cancelButton.Text = "Cancel scan";
            _progressTrack.Marquee = true;
            _progressTrack.Value = 0;
            _scanStatus.Text = "Starting scan...";
            _currentPath.Text = string.Empty;
            SetStatus("Scanning...");

            try
            {
                ScanResult result = await Task.Run(delegate
                {
                    DuplicateScanner scanner = new DuplicateScanner(_scanProgress);
                    return scanner.Scan(options, _scanCts.Token);
                });

                _result = result;
                PopulateResults(result);
                _progressTrack.Marquee = false;
                _progressTrack.Value = 100;
                _scanStatus.Text = result.Groups.Count == 0 ? "No duplicates found." : "Scan complete.";
                _currentPath.Text = FormatUtil.FormatDuration(result.Duration) + "  ·  " +
                    FormatUtil.FormatCount(result.FilesScanned) + " files  ·  " +
                    FormatUtil.FormatCount(result.IssueCount) + " skipped";
                SetStatus("Scan complete in " + FormatUtil.FormatDuration(result.Duration) + "  ·  " +
                    FormatUtil.FormatCount(result.Groups.Count) + " duplicate " +
                    FormatUtil.Plural(result.Groups.Count, "group", "groups") + "  ·  " +
                    FormatUtil.FormatBytes(result.ReclaimableBytes) + " reclaimable" +
                    (result.SkippedHardLinks > 0 ? "  ·  " + result.SkippedHardLinks + " hard links ignored" : string.Empty));
            }
            catch (OperationCanceledException)
            {
                OnScanCancelled();
            }
            catch (AggregateException ex)
            {
                if (ContainsCancellation(ex)) OnScanCancelled();
                else OnScanFailed(ex);
            }
            catch (Exception ex)
            {
                OnScanFailed(ex);
            }
            finally
            {
                _isScanning = false;
                SetInputsEnabled(true);
                _cancelButton.Visible = false;
                _cancelButton.Enabled = false;
                _progressTrack.Marquee = false;
                if (_result != null && _result.Groups.Count > 0) _progressTrack.Value = 100;
                _scanButton.Enabled = true;
                _scanButton.Text = _result != null ? "Scan again" : "Start scan";
                if (_scanCts != null)
                {
                    _scanCts.Dispose();
                    _scanCts = null;
                }
                if (_closeWhenDone)
                {
                    _closeWhenDone = false;
                    BeginInvoke(new Action(Close));
                }
            }
        }

        private void CancelScan()
        {
            if (!_isScanning || _scanCts == null) return;
            if (_scanCts.IsCancellationRequested) return;
            _scanCts.Cancel();
            _cancelButton.Enabled = false;
            _cancelButton.Text = "Cancelling...";
            _scanStatus.Text = "Stopping the scan...";
            SetStatus("Cancelling scan...");
        }

        private void OnScanProgress(ScanProgress progress)
        {
            if (progress == null || IsDisposed) return;

            if (progress.IsIndeterminate)
            {
                _progressTrack.Marquee = true;
            }
            else
            {
                _progressTrack.Marquee = false;
                _progressTrack.Value = progress.Percent;
            }

            _scanStatus.Text = progress.Message;
            _currentPath.Text = string.IsNullOrEmpty(progress.CurrentPath)
                ? string.Empty
                : FormatUtil.ShortenPath(progress.CurrentPath, 78);

            _cardScanned.Value = FormatUtil.FormatCount(progress.FilesFound);
            _cardScanned.Hint = "across " + _roots.Count + " " + FormatUtil.Plural(_roots.Count, "location", "locations");
            if (progress.BytesFound > 0)
            {
                _cardScanned.Hint = FormatUtil.FormatBytes(progress.BytesFound) + " examined";
            }

            if (progress.Phase == ScanPhase.QuickHashing || progress.Phase == ScanPhase.FullHashing)
            {
                _scanStatus.Text = progress.Message + "  ·  " + progress.Percent + "%";
            }

            SetStatus("Scanning  ·  " + FormatUtil.FormatCount(progress.FilesFound) + " files found  ·  " + progress.Message);
        }

        private void OnScanCancelled()
        {
            _result = null;
            _grid.Visible = false;
            _emptyState.Visible = true;
            _emptyState.TitleText = "Scan cancelled";
            _emptyState.SubtitleText = "No files were changed. Adjust your options or locations and start again.";
            _emptyState.FootnoteText = "Tip: a whole-drive scan can take several minutes.";
            _scanStatus.Text = "Scan cancelled.";
            _currentPath.Text = string.Empty;
            _progressTrack.Value = 0;
            _autoSelectButton.Enabled = false;
            _exportButton.Enabled = false;
            _selectDuplicatesButton.Enabled = false;
            _deleteButton.Enabled = false;
            _clearSelectionButton.Enabled = false;
            _selectionLabel.Text = "Select duplicates to remove";
            _selectionLabel.ForeColor = Theme.Muted;
            _resultsSubtitle.Text = "Scan cancelled";
            SetStatus("Scan cancelled. Nothing was changed.");
        }

        private void OnScanFailed(Exception ex)
        {
            AppLog.Crash(ex, "Scan failed");
            _result = null;
            _grid.Visible = false;
            _emptyState.Visible = true;
            _emptyState.TitleText = "Scan could not finish";
            _emptyState.SubtitleText = ex.Message;
            _emptyState.FootnoteText = "Details were written to the DupScan Pro log folder.";
            _scanStatus.Text = "Scan failed.";
            _currentPath.Text = string.Empty;
            _progressTrack.Marquee = false;
            _progressTrack.Value = 0;
            _autoSelectButton.Enabled = false;
            _exportButton.Enabled = false;
            _selectDuplicatesButton.Enabled = false;
            _deleteButton.Enabled = false;
            _clearSelectionButton.Enabled = false;
            _resultsSubtitle.Text = "Scan failed";
            SetStatus("Scan failed: " + ex.Message);
            MessageBox.Show(this, "The scan could not finish.\r\n\r\n" + ex.Message,
                "Scan failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private ScanOptions BuildOptions()
        {
            ScanOptions options = new ScanOptions();
            options.Roots = new List<string>(_roots);
            options.SkipSystemFolders = _chkSkipSystem.Checked;
            options.IncludeHiddenSystem = _chkHidden.Checked;
            options.IncludeEmptyFiles = _chkEmpty.Checked;
            options.VerifyBeforeDelete = _chkVerify.Checked;
            options.MinFileSize = (long)_numMinSize.Value * 1024L;
            options.DetectHardLinks = true;
            options.IgnoreReparsePoints = true;
            options.HashThreads = Math.Max(2, Math.Min(8, Environment.ProcessorCount));
            return options;
        }

        private void ResetForScan()
        {
            _result = null;
            _rowByFile.Clear();
            _grid.Rows.Clear();
            _grid.Visible = false;
            _emptyState.Visible = true;
            _emptyState.TitleText = "Scanning your files";
            _emptyState.SubtitleText = "Walking every subfolder, grouping files by size, then confirming exact content with SHA-256.";
            _emptyState.FootnoteText = "You can cancel at any time. Nothing is deleted during a scan.";
            _search.Input.Clear();
            _resultsSubtitle.Text = "Scan in progress";
            _selectionLabel.Text = "Select duplicates to remove";
            _selectionLabel.ForeColor = Theme.Muted;
            _deleteButton.Enabled = false;
            _clearSelectionButton.Enabled = false;
            _autoSelectButton.Enabled = false;
            _exportButton.Enabled = false;
            _issuesLink.Visible = false;

            _cardGroups.Value = "0";
            _cardGroups.Hint = "sets of identical files";
            _cardFiles.Value = "0";
            _cardFiles.Hint = "extra copies";
            _cardReclaim.Value = "0 B";
            _cardReclaim.Hint = "if duplicates are removed";
            _cardScanned.Value = "0";
            _cardScanned.Hint = "across " + _roots.Count + " " + FormatUtil.Plural(_roots.Count, "location", "locations");
        }

        private void SetInputsEnabled(bool enabled)
        {
            _rootList.Enabled = enabled;
            _addFolderButton.Enabled = enabled;
            _addDriveButton.Enabled = enabled;
            _removeRootButton.Enabled = enabled && _rootList.SelectedIndex >= 0;
            _chkSkipSystem.Enabled = enabled;
            _chkHidden.Enabled = enabled;
            _chkEmpty.Enabled = enabled;
            _chkVerify.Enabled = enabled;
            _numMinSize.Enabled = enabled;
            _scanButton.Enabled = enabled;
            _search.Input.Enabled = enabled;
            _autoSelectButton.Enabled = enabled && _result != null && _result.Groups.Count > 0;
            _selectDuplicatesButton.Enabled = enabled && _result != null && _result.Groups.Count > 0;
            _exportButton.Enabled = enabled && _result != null;
        }

        private string FirstMissingRoot()
        {
            for (int i = 0; i < _roots.Count; i++)
            {
                if (!System.IO.Directory.Exists(_roots[i]) && !System.IO.File.Exists(_roots[i]))
                    return _roots[i];
            }
            return null;
        }

        private void SaveSettingsFromUi()
        {
            _settings.Roots = new List<string>(_roots);
            _settings.SkipSystemFolders = _chkSkipSystem.Checked;
            _settings.IncludeHiddenSystem = _chkHidden.Checked;
            _settings.IncludeEmptyFiles = _chkEmpty.Checked;
            _settings.VerifyBeforeDelete = _chkVerify.Checked;
            _settings.MinFileSize = (long)_numMinSize.Value * 1024L;
            SettingsStore.Save(_settings);
        }

        private static bool ContainsCancellation(AggregateException ex)
        {
            if (ex == null) return false;
            for (int i = 0; i < ex.InnerExceptions.Count; i++)
            {
                if (ex.InnerExceptions[i] is OperationCanceledException) return true;
                AggregateException nested = ex.InnerExceptions[i] as AggregateException;
                if (nested != null && ContainsCancellation(nested)) return true;
            }
            return false;
        }
    }
}
