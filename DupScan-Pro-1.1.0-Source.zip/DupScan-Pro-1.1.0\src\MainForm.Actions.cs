using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace DupScan
{
    public sealed partial class MainForm
    {
        private void AddFolder()
        {
            if (_isScanning) return;

            using (FolderBrowserDialog dialog = new FolderBrowserDialog())
            {
                dialog.Description = "Choose a folder to scan. All subfolders are included.";
                dialog.ShowNewFolderButton = true;
                dialog.SelectedPath = _roots.Count > 0
                    ? _roots[_roots.Count - 1]
                    : Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    AddRoot(dialog.SelectedPath, true);
                }
            }
        }

        private void AddDrive()
        {
            if (_isScanning) return;

            using (DrivePickerDialog dialog = new DrivePickerDialog())
            {
                if (dialog.ShowDialog(this) == DialogResult.OK)
                {
                    for (int i = 0; i < dialog.SelectedDrives.Count; i++)
                    {
                        AddRoot(dialog.SelectedDrives[i], true);
                    }
                }
            }
        }

        private void AddRoot(string path, bool persist)
        {
            string normalized = PathUtil.Normalize(path);
            if (string.IsNullOrEmpty(normalized)) return;

            if (!Directory.Exists(normalized))
            {
                if (persist && File.Exists(normalized))
                {
                    MessageBox.Show(this, "Choose a folder or a drive, not an individual file.",
                        "Folder required", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else if (persist)
                {
                    MessageBox.Show(this, "That folder is not available:\r\n\r\n" + normalized,
                        "Folder not found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                return;
            }

            for (int i = 0; i < _roots.Count; i++)
            {
                if (PathUtil.IsSamePath(_roots[i], normalized))
                {
                    _rootList.SelectedIndex = i;
                    if (persist) SetStatus("That location is already in the list.");
                    return;
                }
            }

            for (int i = 0; i < _roots.Count; i++)
            {
                if (PathUtil.IsSubPathOf(normalized, _roots[i]))
                {
                    _rootList.SelectedIndex = i;
                    if (persist)
                    {
                        MessageBox.Show(this,
                            "This folder is already covered by a location in the list:\r\n\r\n" + _roots[i] +
                            "\r\n\r\nRemove that location first if you want to scan only this folder.",
                            "Already included", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    return;
                }
            }

            // If the new root is a parent of existing entries, collapse them into it.
            for (int i = _roots.Count - 1; i >= 0; i--)
            {
                if (PathUtil.IsSubPathOf(_roots[i], normalized))
                {
                    _roots.RemoveAt(i);
                    _rootList.Items.RemoveAt(i);
                }
            }

            _roots.Add(normalized);
            _rootList.Items.Add(FormatUtil.ShortenPath(normalized, 34));
            _rootList.SelectedIndex = _roots.Count - 1;
            UpdateRootButtons();

            if (persist)
            {
                SaveSettingsFromUi();
                SetStatus("Added scan location: " + normalized);
            }
        }

        private void RemoveSelectedRoot()
        {
            if (_isScanning) return;
            int index = _rootList.SelectedIndex;
            if (index < 0 || index >= _roots.Count)
            {
                SetStatus("Select a location to remove.");
                return;
            }

            string removed = _roots[index];
            _roots.RemoveAt(index);
            _rootList.Items.RemoveAt(index);
            if (_roots.Count > 0) _rootList.SelectedIndex = Math.Min(index, _roots.Count - 1);
            UpdateRootButtons();
            SaveSettingsFromUi();
            SetStatus("Removed scan location: " + removed);
        }

        private void OpenSelectedRoot()
        {
            int index = _rootList.SelectedIndex;
            if (index < 0 || index >= _roots.Count) return;
            ShellUtil.OpenFolder(_roots[index]);
        }

        private void BuildAutoSelectMenu()
        {
            _autoMenu = new ContextMenuStrip();
            _autoMenu.Font = Theme.BaseFont;
            _autoMenu.ShowImageMargin = false;
            _autoMenu.BackColor = Theme.Surface;

            AddAutoItem("Keep newest copy in each group", KeepRule.Newest);
            AddAutoItem("Keep oldest copy in each group", KeepRule.Oldest);
            AddAutoItem("Keep shortest path in each group", KeepRule.ShortestPath);
            AddAutoItem("Keep first path alphabetically", KeepRule.FirstAlphabetical);
            _autoMenu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem clear = new ToolStripMenuItem("Clear all selections");
            clear.Click += delegate { ClearSelection(); };
            _autoMenu.Items.Add(clear);
        }

        private void AddAutoItem(string text, KeepRule rule)
        {
            ToolStripMenuItem item = new ToolStripMenuItem(text);
            item.Click += delegate { ApplyKeepRule(rule); };
            _autoMenu.Items.Add(item);
        }

        private void ShowAutoSelectMenu()
        {
            if (_result == null || _result.Groups.Count == 0) return;
            _autoMenu.Show(_autoSelectButton, new Point(0, _autoSelectButton.Height + 2));
        }

        private void BuildGridMenu()
        {
            _gridMenu = new ContextMenuStrip();
            _gridMenu.Font = Theme.BaseFont;
            _gridMenu.ShowImageMargin = false;
            _gridMenu.BackColor = Theme.Surface;

            ToolStripMenuItem keepOnly = new ToolStripMenuItem("Keep this copy, remove the others");
            keepOnly.Click += delegate { KeepOnlyContextFile(); };
            _gridMenu.Items.Add(keepOnly);

            ToolStripMenuItem remove = new ToolStripMenuItem("Mark this copy for removal");
            remove.Click += delegate
            {
                if (_contextRow != null && _contextFile != null)
                    SetDeletionState(_contextRow, _contextFile, true, true);
            };
            _gridMenu.Items.Add(remove);

            ToolStripMenuItem keep = new ToolStripMenuItem("Keep this copy");
            keep.Click += delegate
            {
                if (_contextRow != null && _contextFile != null)
                    SetDeletionState(_contextRow, _contextFile, false, true);
            };
            _gridMenu.Items.Add(keep);

            _gridMenu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem open = new ToolStripMenuItem("Open file");
            open.Click += delegate
            {
                if (_contextFile != null) ShellUtil.OpenFile(_contextFile.File.Path);
            };
            _gridMenu.Items.Add(open);

            ToolStripMenuItem explorer = new ToolStripMenuItem("Show in Explorer");
            explorer.Click += delegate
            {
                if (_contextFile != null) ShellUtil.SelectInExplorer(_contextFile.File.Path);
            };
            _gridMenu.Items.Add(explorer);

            ToolStripMenuItem copyPath = new ToolStripMenuItem("Copy full path");
            copyPath.Click += delegate
            {
                if (_contextFile == null) return;
                try { Clipboard.SetText(_contextFile.File.Path); SetStatus("Path copied."); }
                catch { }
            };
            _gridMenu.Items.Add(copyPath);

            _gridMenu.Opening += delegate(object sender, System.ComponentModel.CancelEventArgs e)
            {
                if (_grid.CurrentRow != null)
                {
                    _contextRow = _grid.CurrentRow;
                    _contextFile = _contextRow.Tag as DuplicateFile;
                }
                if (_contextFile == null)
                {
                    e.Cancel = true;
                    return;
                }
                keepOnly.Text = "Keep this copy, remove the others";
                remove.Text = "Mark this copy for removal";
                keep.Text = "Keep this copy";
            };
        }

        private void KeepOnlyContextFile()
        {
            if (_result == null || _contextFile == null) return;

            _grid.SuspendLayout();
            for (int g = 0; g < _result.Groups.Count; g++)
            {
                DuplicateGroup group = _result.Groups[g];
                bool contains = false;
                for (int i = 0; i < group.Files.Count; i++)
                {
                    if (ReferenceEquals(group.Files[i], _contextFile)) { contains = true; break; }
                }
                if (!contains) continue;

                for (int i = 0; i < group.Files.Count; i++)
                {
                    DuplicateFile file = group.Files[i];
                    DataGridViewRow row;
                    if (_rowByFile.TryGetValue(file.File, out row))
                    {
                        SetDeletionState(row, file, !ReferenceEquals(file, _contextFile), false);
                    }
                }
                break;
            }
            _grid.ResumeLayout();
            UpdateSelectionSummary();
            SetStatus("Keeping the selected copy; the other copies in its group are marked for removal.");
        }

        private void DeleteSelected()
        {
            if (_result == null || _isScanning) return;

            string error;
            if (!DuplicateDeleter.ValidateSelection(_result, out error))
            {
                MessageBox.Show(this, error, "Check the selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<DuplicateFile> selected = new List<DuplicateFile>();
            int groupsWithSelection = 0;
            for (int g = 0; g < _result.Groups.Count; g++)
            {
                DuplicateGroup group = _result.Groups[g];
                int inGroup = 0;
                for (int f = 0; f < group.Files.Count; f++)
                {
                    if (group.Files[f].SelectedForDeletion)
                    {
                        selected.Add(group.Files[f]);
                        inGroup++;
                    }
                }
                if (inGroup > 0) groupsWithSelection++;
            }

            DeleteMode mode;
            bool verify;
            using (DeleteConfirmDialog confirm = new DeleteConfirmDialog(selected, groupsWithSelection, _chkVerify.Checked))
            {
                if (confirm.ShowDialog(this) != DialogResult.OK) return;
                mode = confirm.Mode;
                verify = confirm.Verify;
            }

            DeleteOutcome outcome = null;
            using (DeletionProgressDialog progress = new DeletionProgressDialog(_result, mode, verify))
            {
                progress.ShowDialog(this);
                if (progress.Error != null)
                {
                    MessageBox.Show(this,
                        "The cleanup could not finish.\r\n\r\n" + progress.Error.Message,
                        "Cleanup error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                outcome = progress.Outcome;
            }

            if (outcome == null)
            {
                SetStatus("Cleanup cancelled. Nothing was removed.");
                return;
            }

            HashSet<FileRecord> removed = new HashSet<FileRecord>();
            for (int i = 0; i < outcome.Succeeded.Count; i++)
            {
                removed.Add(outcome.Succeeded[i].File);
            }

            if (removed.Count > 0)
            {
                for (int g = _result.Groups.Count - 1; g >= 0; g--)
                {
                    DuplicateGroup group = _result.Groups[g];
                    for (int f = group.Files.Count - 1; f >= 0; f--)
                    {
                        if (removed.Contains(group.Files[f].File))
                            group.Files.RemoveAt(f);
                    }
                    if (group.Files.Count < 2)
                        _result.Groups.RemoveAt(g);
                }

                for (int i = 0; i < _result.Groups.Count; i++) _result.Groups[i].Id = i + 1;
                _result.Recalculate();
            }

            _settings.VerifyBeforeDelete = verify;
            SettingsStore.Save(_settings);
            PopulateResults(_result);

            if (outcome.Succeeded.Count > 0)
            {
                SetStatus("Removed " + outcome.Succeeded.Count + " " +
                    FormatUtil.Plural(outcome.Succeeded.Count, "file", "files") + "  ·  " +
                    FormatUtil.FormatBytes(outcome.BytesRecycled + outcome.BytesFreed) +
                    (outcome.BytesRecycled > 0 ? " moved to Recycle Bin" : " freed"));
            }
            else if (outcome.Failed.Count > 0)
            {
                SetStatus("No files were removed. Review the reasons in the result window.");
            }
            else
            {
                SetStatus("Cleanup cancelled. Nothing was removed.");
            }

            using (DeleteResultDialog resultDialog = new DeleteResultDialog(outcome))
            {
                resultDialog.ShowDialog(this);
            }

            if (outcome.Succeeded.Count > 0)
            {
                ShowDonationReminders();
            }
        }

        private void ShowDonationReminders()
        {
            // Deliberately shown twice after a completed cleanup. The first
            // "Maybe later" is not enough to skip the second reminder.
            for (int reminder = 1; reminder <= 2; reminder++)
            {
                using (DonationDialog dialog = new DonationDialog(reminder, 2))
                {
                    dialog.ShowDialog(this);
                    if (dialog.Donated) break;
                }
            }
        }

        private void ExportReport()
        {
            if (_result == null) return;

            string initial = _settings.LastExportFolder;
            if (string.IsNullOrEmpty(initial) || !Directory.Exists(initial))
                initial = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            using (SaveFileDialog dialog = new SaveFileDialog())
            {
                dialog.Title = "Export duplicate report";
                dialog.Filter = "HTML report (*.html)|*.html|CSV spreadsheet (*.csv)|*.csv";
                dialog.FilterIndex = 1;
                dialog.AddExtension = true;
                dialog.DefaultExt = "html";
                dialog.InitialDirectory = initial;
                dialog.FileName = "DupScanPro-report-" + DateTime.Now.ToString("yyyyMMdd-HHmm") + ".html";
                if (dialog.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    string extension = Path.GetExtension(dialog.FileName);
                    if (string.Equals(extension, ".csv", StringComparison.OrdinalIgnoreCase))
                        ReportExporter.ExportCsv(_result, dialog.FileName);
                    else
                        ReportExporter.ExportHtml(_result, dialog.FileName);

                    _settings.LastExportFolder = Path.GetDirectoryName(dialog.FileName);
                    SettingsStore.Save(_settings);
                    SetStatus("Report saved: " + dialog.FileName);

                    if (MessageBox.Show(this, "Report saved successfully.\r\n\r\n" + dialog.FileName +
                        "\r\n\r\nOpen it now?", "Report saved", MessageBoxButtons.YesNo,
                        MessageBoxIcon.Information) == DialogResult.Yes)
                    {
                        ShellUtil.OpenFile(dialog.FileName);
                    }
                }
                catch (Exception ex)
                {
                    AppLog.Crash(ex, "Export report failed");
                    MessageBox.Show(this, "The report could not be saved.\r\n\r\n" + ex.Message,
                        "Export failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ShowIssues()
        {
            if (_result == null || _result.IssueCount == 0) return;
            using (IssuesDialog dialog = new IssuesDialog(_result.Issues, _result.IssueCount))
            {
                dialog.ShowDialog(this);
            }
        }

        private void ShowAbout()
        {
            using (AboutDialog dialog = new AboutDialog())
            {
                dialog.ShowDialog(this);
            }
        }
    }
}
