using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace DupScan
{
    public sealed class DonationDialog : ThemedDialog
    {
        public bool Donated;
        public bool Cancelled = true;

        private readonly string _upiId = "9691701245@ptaxis";

        public DonationDialog(int reminderNumber, int totalReminders)
            : base("Support DupScan Pro", "DupScan Pro is free. If it helped, a coffee keeps it going.",
                new Size(640, 680))
        {
            AddContentLabel("A quick favour before you go  ·  Reminder " + reminderNumber + " of " + totalReminders,
                Theme.SmallFont, Theme.Faint, 0, 0, 596, 20);

            Label message = new Label();
            message.Text =
                "This software is free because I believe in open access, but it runs on caffeine, late nights, " +
                "and passion. If this tool saved you time or made your day easier, consider buying me a coffee " +
                "\u2014 even \u20B910 or \u20B999 goes a long way. It keeps the code flowing and the updates coming.";
            message.Font = Theme.BaseFont;
            message.ForeColor = Theme.Text;
            message.BackColor = Color.Transparent;
            message.AutoSize = false;
            message.SetBounds(0, 24, 596, 102);
            Content.Controls.Add(message);

            CardPanel qrCard = new CardPanel();
            qrCard.SetBounds(0, 138, 260, 260);
            qrCard.Padding = new Padding(8);
            qrCard.CornerRadius = 12;
            qrCard.BorderColor = Theme.Border;
            Content.Controls.Add(qrCard);

            PictureBox qr = new PictureBox();
            qr.Dock = DockStyle.Fill;
            qr.BackColor = Color.White;
            qr.SizeMode = PictureBoxSizeMode.Zoom;
            qr.Image = LoadQrImage();
            qrCard.Controls.Add(qr);

            AddContentLabel("SCAN WITH ANY UPI APP", Theme.TinyFont, Theme.Muted, 280, 142, 316, 18);
            AddContentLabel("Paytm  ·  Google Pay  ·  PhonePe", Theme.BaseFont, Theme.Text, 280, 162, 316, 22);
            AddContentLabel("UPI ID", Theme.TinyFont, Theme.Muted, 280, 202, 316, 18);

            TextBox upi = new TextBox();
            upi.Text = _upiId;
            upi.ReadOnly = true;
            upi.Font = new Font("Consolas", 11f, FontStyle.Bold);
            upi.ForeColor = Theme.Text;
            upi.BackColor = Theme.SurfaceAlt;
            upi.BorderStyle = BorderStyle.FixedSingle;
            upi.TextAlign = HorizontalAlignment.Center;
            upi.SetBounds(280, 222, 316, 30);
            Content.Controls.Add(upi);

            FlatButton copy = new FlatButton();
            copy.Text = "Copy UPI ID";
            copy.Style = FlatButtonStyle.Secondary;
            copy.Width = 132;
            copy.Height = 34;
            copy.Click += delegate
            {
                try
                {
                    Clipboard.SetText(_upiId);
                    copy.Text = "Copied!";
                }
                catch { }
            };

            AddContentLabel("ACCOUNT NAME", Theme.TinyFont, Theme.Muted, 280, 300, 316, 18);
            AddContentLabel("Umang Dhoke", Theme.H3Font, Theme.Text, 280, 318, 316, 24);
            AddContentLabel("Suggested: \u20B910, \u20B999, or any amount you like.", Theme.SmallFont,
                Theme.Muted, 280, 352, 316, 20);

            AddContentLabel("No payment is processed by DupScan Pro. The QR and UPI ID open in your own UPI app.",
                Theme.TinyFont, Theme.Faint, 0, 414, 596, 34);
            AddContentLabel("This support reminder appears twice after a completed cleanup. Thank you for considering it.",
                Theme.TinyFont, Theme.Faint, 0, 448, 596, 34);

            FlatButton donated = new FlatButton();
            donated.Text = "I donated";
            donated.Style = FlatButtonStyle.Success;
            donated.Width = 120;
            donated.Height = 38;
            donated.Click += delegate
            {
                Donated = true;
                Cancelled = false;
                DialogResult = DialogResult.OK;
                Close();
            };

            FlatButton later = new FlatButton();
            later.Text = "Maybe later";
            later.Style = FlatButtonStyle.Secondary;
            later.Width = 112;
            later.Height = 38;
            later.Click += delegate
            {
                Cancelled = true;
                DialogResult = DialogResult.Cancel;
                Close();
            };

            AddDialogButton(donated);
            AddDialogButton(copy);
            AddDialogButton(later);
            CancelButton = later;
        }

        private static Image LoadQrImage()
        {
            try
            {
                Assembly assembly = Assembly.GetExecutingAssembly();
                using (Stream stream = assembly.GetManifestResourceStream("DupScan.donate-qr.png"))
                {
                    if (stream == null) return null;
                    using (Image source = Image.FromStream(stream))
                    {
                        Bitmap copy = new Bitmap(source.Width, source.Height);
                        using (Graphics graphics = Graphics.FromImage(copy))
                        {
                            graphics.DrawImage(source, 0, 0, source.Width, source.Height);
                        }
                        return copy;
                    }
                }
            }
            catch
            {
                return null;
            }
        }
    }
}
