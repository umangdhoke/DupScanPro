param(
    [switch]$SkipAppBuild
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$iscc = Join-Path $root "installer\tools\InnoSetup6\app\ISCC.exe"
$app = Join-Path $root "build\DupScan.exe"
$dotnet = Join-Path $root "installer\deps\NDP48-x86-x64-AllOS-ENU.exe"

if (-not $SkipAppBuild) {
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $root "build.ps1")
    if ($LASTEXITCODE -ne 0) { throw "App build failed." }
}

if (-not (Test-Path $iscc)) {
    throw "Inno Setup compiler not found. Expected: $iscc"
}
if (-not (Test-Path $app)) {
    throw "App payload not found. Run build.ps1 first."
}
if (-not (Test-Path $dotnet)) {
    throw "Bundled .NET 4.8 installer not found. Expected: $dotnet"
}

New-Item -ItemType Directory -Force -Path (Join-Path $root "dist") | Out-Null

Write-Host "Compiling DupScan Pro setup ..."
& $iscc (Join-Path $root "installer\DupScanPro.iss")
if ($LASTEXITCODE -ne 0) {
    throw "Installer compilation failed with exit code $LASTEXITCODE."
}

$setup = Join-Path $root "dist\DupScanPro-Setup-1.1.0.exe"
if (-not (Test-Path $setup)) {
    throw "Setup output was not created: $setup"
}

$item = Get-Item $setup
Write-Host ("Built: " + $item.FullName + "  (" + [math]::Round($item.Length / 1MB, 1) + " MB)")
Write-Host ("SHA256: " + (Get-FileHash $setup -Algorithm SHA256).Hash)
