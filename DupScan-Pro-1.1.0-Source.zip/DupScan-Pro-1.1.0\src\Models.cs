using System;
using System.Collections.Generic;
using System.IO;

namespace DupScan
{
    public enum ScanPhase
    {
        Idle,
        Enumerating,
        QuickHashing,
        FullHashing,
        Grouping,
        Completed,
        Cancelled,
        Failed
    }

    public enum DeleteMode
    {
        RecycleBin,
        Permanent
    }

    public sealed class ScanOptions
    {
        public List<string> Roots = new List<string>();
        public bool SkipSystemFolders = true;
        public bool IncludeHiddenSystem = false;
        public bool IncludeEmptyFiles = false;
        public long MinFileSize = 1024;
        public bool DetectHardLinks = true;
        public bool VerifyBeforeDelete = true;
        public bool IgnoreReparsePoints = true;
        public int HashThreads = Math.Max(2, Math.Min(8, Environment.ProcessorCount));

        public ScanOptions Clone()
        {
            ScanOptions copy = new ScanOptions();
            copy.Roots = new List<string>(Roots);
            copy.SkipSystemFolders = SkipSystemFolders;
            copy.IncludeHiddenSystem = IncludeHiddenSystem;
            copy.IncludeEmptyFiles = IncludeEmptyFiles;
            copy.MinFileSize = MinFileSize;
            copy.DetectHardLinks = DetectHardLinks;
            copy.VerifyBeforeDelete = VerifyBeforeDelete;
            copy.IgnoreReparsePoints = IgnoreReparsePoints;
            copy.HashThreads = HashThreads;
            return copy;
        }
    }

    public sealed class FileRecord
    {
        public string Path;
        public string Root;
        public long Size;
        public DateTime ModifiedUtc;
        public DateTime CreatedUtc;
        public FileAttributes Attributes;
        public string QuickHash;
        public string FullHash;
        public string Identity;
        public uint HardLinkCount;
        public bool IsHardLink;

        public string Name
        {
            get { return System.IO.Path.GetFileName(Path); }
        }

        public string Folder
        {
            get
            {
                string folder = System.IO.Path.GetDirectoryName(Path);
                return folder == null ? string.Empty : folder;
            }
        }

        public string SizeText
        {
            get { return FormatUtil.FormatBytes(Size); }
        }

        public string ModifiedText
        {
            get { return ModifiedUtc.ToLocalTime().ToString("dd MMM yyyy, HH:mm"); }
        }
    }

    public sealed class DuplicateFile
    {
        public FileRecord File;
        public bool SelectedForDeletion;

        public string StatusText
        {
            get { return SelectedForDeletion ? "DELETE" : "KEEP"; }
        }
    }

    public sealed class DuplicateGroup
    {
        public int Id;
        public long Size;
        public string Hash;
        public List<DuplicateFile> Files = new List<DuplicateFile>();

        public long ReclaimableBytes
        {
            get { return Size * Math.Max(0, Files.Count - 1); }
        }

        public int SelectedCount
        {
            get
            {
                int count = 0;
                for (int i = 0; i < Files.Count; i++)
                {
                    if (Files[i].SelectedForDeletion) count++;
                }
                return count;
            }
        }

        public int KeepCount
        {
            get { return Files.Count - SelectedCount; }
        }

        public string Title
        {
            get { return Files.Count == 0 ? string.Empty : Files[0].File.Name; }
        }

        public string Folder
        {
            get { return Files.Count == 0 ? string.Empty : Files[0].File.Folder; }
        }
    }

    public sealed class ScanIssue
    {
        public string Path;
        public string Message;
        public bool IsDirectory;

        public ScanIssue(string path, string message, bool isDirectory)
        {
            Path = path;
            Message = message;
            IsDirectory = isDirectory;
        }
    }

    public sealed class ScanProgress
    {
        public ScanPhase Phase;
        public string Message;
        public long Current;
        public long Total;
        public int FilesFound;
        public int DuplicateFiles;
        public long BytesFound;
        public bool IsIndeterminate;
        public string CurrentPath;

        public int Percent
        {
            get
            {
                if (Total <= 0) return 0;
                long value = (Current * 100L) / Total;
                if (value < 0) return 0;
                if (value > 100) return 100;
                return (int)value;
            }
        }
    }

    public sealed class ScanResult
    {
        public List<DuplicateGroup> Groups = new List<DuplicateGroup>();
        public List<ScanIssue> Issues = new List<ScanIssue>();
        public List<string> Roots = new List<string>();
        public int IssueCount;
        public int FilesScanned;
        public int CandidateFiles;
        public int TotalDuplicateFiles;
        public long ReclaimableBytes;
        public long TotalDuplicateBytes;
        public long TotalBytesScanned;
        public int SkippedHardLinks;
        public int SkippedBySize;
        public DateTime CompletedAt = DateTime.Now;
        public TimeSpan Duration;
        public bool WasCancelled;

        public void Recalculate()
        {
            TotalDuplicateFiles = 0;
            ReclaimableBytes = 0;
            TotalDuplicateBytes = 0;
            for (int i = 0; i < Groups.Count; i++)
            {
                DuplicateGroup group = Groups[i];
                TotalDuplicateFiles += Math.Max(0, group.Files.Count - 1);
                ReclaimableBytes += group.ReclaimableBytes;
                TotalDuplicateBytes += group.Size * group.Files.Count;
            }
        }
    }

    public sealed class DeleteProgress
    {
        public int Current;
        public int Total;
        public string CurrentPath;
        public string Message;

        public int Percent
        {
            get
            {
                if (Total <= 0) return 0;
                int value = (Current * 100) / Total;
                if (value < 0) return 0;
                if (value > 100) return 100;
                return value;
            }
        }
    }

    public sealed class DeletedItem
    {
        public FileRecord File;
        public bool Recycled;
    }

    public sealed class FailedDelete
    {
        public FileRecord File;
        public string Reason;
    }

    public sealed class DeleteOutcome
    {
        public List<DeletedItem> Succeeded = new List<DeletedItem>();
        public List<FailedDelete> Failed = new List<FailedDelete>();
        public long BytesRecycled;
        public long BytesFreed;
        public bool WasCancelled;
        public string LogPath;

        public int TotalSucceeded
        {
            get { return Succeeded.Count; }
        }
    }
}
