param(
    [string]$OutDir = (Join-Path $PSScriptRoot "..\assets")
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

function New-RoundedPath([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $path = [System.Drawing.Drawing2D.GraphicsPath]::new()
    if ($r -le 0.5) {
        $path.AddRectangle([System.Drawing.RectangleF]::new($x, $y, $w, $h))
        return $path
    }
    $d = $r * 2.0
    $path.AddArc($x, $y, $d, $d, 180, 90)
    $path.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $path.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $path.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $path.CloseFigure()
    return $path
}

$sizes = [int[]]@(256, 128, 64, 48, 32, 16)
$images = [System.Collections.Generic.List[byte[]]]::new()

foreach ($size in $sizes) {
    $bmp = [System.Drawing.Bitmap]::new([int]$size, [int]$size, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $g.Clear([System.Drawing.Color]::Transparent)

    $s = [double]($size / 256.0)

    $badgeRect = [System.Drawing.RectangleF]::new([float](8 * $s), [float](8 * $s), [float](240 * $s), [float](240 * $s))
    $badge = New-RoundedPath ([float](8 * $s)) ([float](8 * $s)) ([float](240 * $s)) ([float](240 * $s)) ([float](54 * $s))
    $c1 = [System.Drawing.Color]::FromArgb(255, 59, 130, 246)
    $c2 = [System.Drawing.Color]::FromArgb(255, 29, 64, 175)
    $gradient = [System.Drawing.Drawing2D.LinearGradientBrush]::new($badgeRect, $c1, $c2, 45.0)
    $g.FillPath($gradient, $badge)

    $pageWhite = [System.Drawing.SolidBrush]::new([System.Drawing.Color]::FromArgb(238, 255, 255, 255))
    $backPage = New-RoundedPath ([float](58 * $s)) ([float](40 * $s)) ([float](108 * $s)) ([float](132 * $s)) ([float](12 * $s))
    $frontPage = New-RoundedPath ([float](96 * $s)) ([float](70 * $s)) ([float](104 * $s)) ([float](128 * $s)) ([float](12 * $s))
    $g.FillPath($pageWhite, $backPage)
    $g.FillPath($pageWhite, $frontPage)

    $linePen = [System.Drawing.Pen]::new([System.Drawing.Color]::FromArgb(170, 30, 64, 175), [float](8 * $s))
    $linePen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $linePen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $g.DrawLine($linePen, [float](116 * $s), [float](102 * $s), [float](180 * $s), [float](102 * $s))
    $g.DrawLine($linePen, [float](116 * $s), [float](126 * $s), [float](180 * $s), [float](126 * $s))
    $g.DrawLine($linePen, [float](116 * $s), [float](150 * $s), [float](156 * $s), [float](150 * $s))

    $glassPen = [System.Drawing.Pen]::new([System.Drawing.Color]::White, [float](13 * $s))
    $glassPen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $glassPen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
    $g.DrawEllipse($glassPen, [float](145 * $s), [float](143 * $s), [float](62 * $s), [float](62 * $s))
    $g.DrawLine($glassPen, [float](198 * $s), [float](196 * $s), [float](225 * $s), [float](223 * $s))

    $ms = [System.IO.MemoryStream]::new()
    $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $images.Add($ms.ToArray())

    if ($size -eq 256) {
        $bmp.Save((Join-Path $OutDir "app-256.png"), [System.Drawing.Imaging.ImageFormat]::Png)
    }

    $ms.Dispose()
    $glassPen.Dispose()
    $linePen.Dispose()
    $pageWhite.Dispose()
    $frontPage.Dispose()
    $backPage.Dispose()
    $gradient.Dispose()
    $badge.Dispose()
    $g.Dispose()
    $bmp.Dispose()
}

$icoPath = Join-Path $OutDir "app.ico"
$fs = [System.IO.File]::Create($icoPath)
$bw = [System.IO.BinaryWriter]::new($fs)
$bw.Write([UInt16]0)
$bw.Write([UInt16]1)
$bw.Write([UInt16]$sizes.Count)
$offset = 6 + (16 * $sizes.Count)

for ($i = 0; $i -lt $sizes.Count; $i++) {
    $size = $sizes[$i]
    $dim = if ($size -eq 256) { 0 } else { $size }
    $bw.Write([Byte]$dim)
    $bw.Write([Byte]$dim)
    $bw.Write([Byte]0)
    $bw.Write([Byte]0)
    $bw.Write([UInt16]1)
    $bw.Write([UInt16]32)
    $bw.Write([UInt32]$images[$i].Length)
    $bw.Write([UInt32]$offset)
    $offset += $images[$i].Length
}
for ($i = 0; $i -lt $images.Count; $i++) {
    $bw.Write($images[$i])
}
$bw.Flush()
$bw.Dispose()
$fs.Dispose()

Write-Output ("Icon written: " + $icoPath)
Get-Item $icoPath | Select-Object FullName, Length
