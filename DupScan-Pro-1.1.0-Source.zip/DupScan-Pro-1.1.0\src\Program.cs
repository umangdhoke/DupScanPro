using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace DupScan
{
    internal static class Program
    {
        [STAThread]
        private static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);

            Application.ThreadException += delegate(object sender, ThreadExceptionEventArgs e)
            {
                AppLog.Crash(e.Exception, "UI thread exception");
                MessageBox.Show(
                    "DupScan Pro hit an unexpected error.\r\n\r\n" + (e.Exception == null ? "Unknown error" : e.Exception.Message) +
                    "\r\n\r\nA crash log was written to:\r\n" + AppPaths.CrashLogFile,
                    "DupScan Pro error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            AppDomain.CurrentDomain.UnhandledException += delegate(object sender, UnhandledExceptionEventArgs e)
            {
                AppLog.Crash(e.ExceptionObject as Exception, "Unhandled exception");
            };

            List<string> roots = new List<string>();
            bool autoScan = false;
            bool donateDemo = false;
            for (int i = 0; i < args.Length; i++)
            {
                string arg = args[i];
                if (string.Equals(arg, "--autoscan", StringComparison.OrdinalIgnoreCase))
                {
                    autoScan = true;
                    continue;
                }
                if (string.Equals(arg, "--donate-demo", StringComparison.OrdinalIgnoreCase))
                {
                    donateDemo = true;
                    continue;
                }
                if (Directory.Exists(arg))
                {
                    roots.Add(arg);
                }
            }

            try
            {
                Application.Run(new MainForm(roots, autoScan, donateDemo));
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "Fatal startup error");
                MessageBox.Show(
                    "DupScan Pro could not start.\r\n\r\n" + ex.Message +
                    "\r\n\r\nDetails: " + AppPaths.CrashLogFile,
                    "DupScan Pro could not start", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
