using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace DupScan
{
    public sealed partial class MainForm : Form
    {
        private readonly List<string> _roots = new List<string>();
        private readonly AppSettings _settings;
        private readonly Dictionary<FileRecord, DataGridViewRow> _rowByFile =
            new Dictionary<FileRecord, DataGridViewRow>();

        private readonly bool _donateDemo;
        private ScanResult _result;
        private CancellationTokenSource _scanCts;
        private bool _isScanning;
        private bool _closeWhenDone;
        private Progress<ScanProgress> _scanProgress;
        private string _resultsBaseSubtitle = "No scan results yet";

        private PathListBox _rootList;
        private FlatButton _addFolderButton;
        private FlatButton _addDriveButton;
        private FlatButton _removeRootButton;
        private CheckBox _chkSkipSystem;
        private CheckBox _chkHidden;
        private CheckBox _chkEmpty;
        private CheckBox _chkVerify;
        private NumericUpDown _numMinSize;
        private Label _minSizeHint;
        private FlatButton _scanButton;
        private FlatButton _cancelButton;
        private FlatButton _selectDuplicatesButton;
        private ProgressTrack _progressTrack;
        private Label _scanStatus;
        private Label _currentPath;
        private SummaryCard _cardGroups;
        private SummaryCard _cardFiles;
        private SummaryCard _cardReclaim;
        private SummaryCard _cardScanned;
        private SearchBox _search;
        private FlatButton _autoSelectButton;
        private FlatButton _exportButton;
        private Label _resultsTitle;
        private Label _resultsSubtitle;
        private BufferedDataGridView _grid;
        private EmptyState _emptyState;
        private Label _selectionLabel;
        private FlatButton _deleteButton;
        private FlatButton _clearSelectionButton;
        private CardPanel _resultsCard;
        private Label _statusLabel;
        private LinkLabel _issuesLink;
        private LinkLabel _helpLink;
        private ToolTip _rootTip;
        private ContextMenuStrip _autoMenu;
        private ContextMenuStrip _gridMenu;
        private DuplicateFile _contextFile;
        private DataGridViewRow _contextRow;
        private ToolTip _gridTip;

        public MainForm()
            : this(null, false)
        {
        }

        public MainForm(IList<string> startupRoots, bool autoScan)
            : this(startupRoots, autoScan, false)
        {
        }

        public MainForm(IList<string> startupRoots, bool autoScan, bool donateDemo)
        {
            _donateDemo = donateDemo;
            _settings = SettingsStore.Load();

            Text = "DupScan Pro — Duplicate File Finder";
            BackColor = Theme.Background;
            Font = Theme.BaseFont;
            ForeColor = Theme.Text;
            StartPosition = FormStartPosition.Manual;
            Rectangle workArea = Screen.PrimaryScreen.WorkingArea;
            int desiredWidth = Math.Max(1000, _settings.WindowWidth);
            int desiredHeight = Math.Max(660, _settings.WindowHeight);
            ClientSize = new Size(
                Math.Min(desiredWidth, workArea.Width - 50),
                Math.Min(desiredHeight, workArea.Height - 70));
            MinimumSize = new Size(1000, 660);
            AutoScaleMode = AutoScaleMode.None;
            KeyPreview = true;
            AllowDrop = true;
            DoubleBuffered = true;

            try
            {
                Icon icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
                if (icon != null) Icon = icon;
            }
            catch { }

            _gridTip = new ToolTip();
            BuildShell();
            LoadSettingsIntoUi();

            if (startupRoots != null)
            {
                for (int i = 0; i < startupRoots.Count; i++)
                {
                    AddRoot(startupRoots[i], false);
                }
            }

            if (_settings.Maximized) WindowState = FormWindowState.Maximized;

            FormClosing += OnFormClosing;
            DragEnter += OnDragEnter;
            DragDrop += OnDragDrop;
            Shown += delegate
            {
                FitWindowToScreen();
                if (_donateDemo)
                {
                    BeginInvoke(new Action(delegate { ShowDonationReminders(); }));
                }
                else if (autoScan && _roots.Count > 0)
                {
                    StartScan();
                }
            };
        }

        private void BuildShell()
        {
            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Fill;
            root.ColumnCount = 1;
            root.RowCount = 3;
            root.BackColor = Theme.Background;
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 96));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            Controls.Add(root);

            GradientHeader header = BuildHeader();
            root.Controls.Add(header, 0, 0);

            Panel body = new Panel();
            body.Dock = DockStyle.Fill;
            body.Padding = new Padding(18, 16, 18, 8);
            body.BackColor = Theme.Background;
            root.Controls.Add(body, 0, 1);

            Panel status = BuildStatusBar();
            root.Controls.Add(status, 0, 2);

            BuildBody(body);
        }

        private GradientHeader BuildHeader()
        {
            GradientHeader header = new GradientHeader();
            header.Dock = DockStyle.Fill;

            LogoMark logo = new LogoMark();
            logo.SetBounds(20, 20, 56, 56);
            header.Controls.Add(logo);

            Label title = Theme.MakeLabel("DupScan", Theme.H1Font, Color.White);
            title.SetBounds(92, 10, 220, 46);
            header.Controls.Add(title);

            ProBadge pro = new ProBadge();
            pro.SetBounds(244, 24, 44, 22);
            header.Controls.Add(pro);

            Label subtitle = Theme.MakeLabel("Exact-content duplicate finder  ·  Pro edition  ·  review every copy before you remove it",
                new Font("Segoe UI", 9.5f), Color.FromArgb(199, 210, 254));
            subtitle.SetBounds(94, 56, 700, 22);
            header.Controls.Add(subtitle);

            Label version = Theme.MakeLabel("NATIVE WINDOWS  ·  v1.1", Theme.TinyFont, Color.FromArgb(148, 163, 184));
            version.AutoSize = false;
            version.TextAlign = ContentAlignment.MiddleRight;
            version.SetBounds(header.Width - 210, 18, 190, 20);
            version.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            header.Controls.Add(version);

            _helpLink = new LinkLabel();
            _helpLink.Text = "How it works";
            _helpLink.Font = Theme.SmallFont;
            _helpLink.LinkColor = Color.FromArgb(219, 234, 254);
            _helpLink.ActiveLinkColor = Color.White;
            _helpLink.VisitedLinkColor = Color.FromArgb(219, 234, 254);
            _helpLink.BackColor = Color.Transparent;
            _helpLink.LinkBehavior = LinkBehavior.HoverUnderline;
            _helpLink.AutoSize = true;
            _helpLink.SetBounds(header.Width - 120, 48, 110, 20);
            _helpLink.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _helpLink.LinkClicked += delegate { ShowAbout(); };
            header.Controls.Add(_helpLink);

            header.Resize += delegate
            {
                version.Left = header.Width - 210;
                _helpLink.Left = header.Width - 122;
            };
            return header;
        }

        private void BuildBody(Panel body)
        {
            TableLayoutPanel columns = new TableLayoutPanel();
            columns.Dock = DockStyle.Fill;
            columns.ColumnCount = 2;
            columns.RowCount = 1;
            columns.BackColor = Theme.Background;
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 330));
            columns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            body.Controls.Add(columns);

            Panel sidebar = new Panel();
            sidebar.Dock = DockStyle.Fill;
            sidebar.Padding = new Padding(0, 0, 14, 0);
            sidebar.BackColor = Theme.Background;
            columns.Controls.Add(sidebar, 0, 0);

            Panel content = new Panel();
            content.Dock = DockStyle.Fill;
            content.BackColor = Theme.Background;
            columns.Controls.Add(content, 1, 0);

            BuildSidebar(sidebar);
            BuildContent(content);
        }

        private void BuildSidebar(Panel sidebar)
        {
            TableLayoutPanel sideLayout = new TableLayoutPanel();
            sideLayout.Dock = DockStyle.Fill;
            sideLayout.ColumnCount = 1;
            sideLayout.RowCount = 2;
            sideLayout.BackColor = Theme.Background;
            sideLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            sideLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 205));
            sidebar.Controls.Add(sideLayout);

            Panel scanDock = new Panel();
            scanDock.Dock = DockStyle.Fill;
            scanDock.Padding = new Padding(0, 12, 0, 0);
            scanDock.BackColor = Theme.Background;

            CardPanel scanCard = new CardPanel();
            scanCard.Dock = DockStyle.Fill;
            scanCard.Padding = new Padding(16, 12, 16, 12);
            scanDock.Controls.Add(scanCard);
            sideLayout.Controls.Add(scanDock, 0, 1);

            Panel scroll = new Panel();
            scroll.Dock = DockStyle.Fill;
            scroll.AutoScroll = true;
            scroll.BackColor = Theme.Background;
            sideLayout.Controls.Add(scroll, 0, 0);

            TableLayoutPanel stack = new TableLayoutPanel();
            stack.Dock = DockStyle.Top;
            stack.ColumnCount = 1;
            stack.RowCount = 2;
            stack.AutoSize = true;
            stack.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            stack.BackColor = Theme.Background;
            stack.Margin = new Padding(0);
            stack.Padding = new Padding(0);
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 258));
            stack.RowStyles.Add(new RowStyle(SizeType.Absolute, 286));
            scroll.Controls.Add(stack);

            CardPanel locations = BuildLocationsCard();
            locations.Margin = new Padding(0, 0, 0, 14);
            stack.Controls.Add(locations, 0, 0);

            CardPanel options = BuildOptionsCard();
            options.Margin = new Padding(0, 0, 0, 14);
            stack.Controls.Add(options, 0, 1);

            scroll.Resize += delegate
            {
                int width = scroll.ClientSize.Width - (scroll.VerticalScroll.Visible ? 18 : 0);
                stack.Width = Math.Max(280, width);
            };

            BuildScanCard(scanCard);
        }

        private CardPanel BuildLocationsCard()
        {
            CardPanel card = new CardPanel();
            card.Dock = DockStyle.Fill;
            card.Padding = new Padding(14, 12, 14, 12);

            Label title = Theme.MakeLabel("1   Scan locations", Theme.H3Font, Theme.Text);
            title.SetBounds(0, 0, 280, 22);
            card.Controls.Add(title);

            Label sub = Theme.MakeLabel("Add a folder, or a whole drive", Theme.SmallFont, Theme.Muted);
            sub.SetBounds(0, 22, 280, 18);
            card.Controls.Add(sub);

            _rootList = new PathListBox();
            _rootList.SetBounds(0, 46, 288, 90);
            _rootList.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _rootList.SelectedIndexChanged += delegate { UpdateRootButtons(); };
            _rootList.DoubleClick += delegate { OpenSelectedRoot(); };
            _rootList.KeyDown += delegate(object sender, KeyEventArgs e)
            {
                if (e.KeyCode == Keys.Delete) { RemoveSelectedRoot(); e.Handled = true; }
            };
            card.Controls.Add(_rootList);

            _addFolderButton = new FlatButton();
            _addFolderButton.Text = "Add folder";
            _addFolderButton.Style = FlatButtonStyle.Primary;
            _addFolderButton.SetBounds(0, 144, 140, 32);
            _addFolderButton.Click += delegate { AddFolder(); };
            card.Controls.Add(_addFolderButton);

            _addDriveButton = new FlatButton();
            _addDriveButton.Text = "Add drive";
            _addDriveButton.Style = FlatButtonStyle.Secondary;
            _addDriveButton.SetBounds(146, 144, 140, 32);
            _addDriveButton.Click += delegate { AddDrive(); };
            card.Controls.Add(_addDriveButton);

            _removeRootButton = new FlatButton();
            _removeRootButton.Text = "Remove selected location";
            _removeRootButton.Style = FlatButtonStyle.Secondary;
            _removeRootButton.SetBounds(0, 180, 286, 30);
            _removeRootButton.Click += delegate { RemoveSelectedRoot(); };
            card.Controls.Add(_removeRootButton);

            Label hint = Theme.MakeLabel("Tip: add C:\\ for the whole drive. Drop folders here.",
                Theme.TinyFont, Theme.Faint);
            hint.SetBounds(0, 214, 288, 18);
            card.Controls.Add(hint);

            _rootTip = new ToolTip();
            _rootList.MouseMove += delegate(object sender, MouseEventArgs e)
            {
                int index = _rootList.IndexFromPoint(e.Location);
                if (index >= 0 && index < _roots.Count)
                {
                    string text = _roots[index];
                    if (_rootTip.GetToolTip(_rootList) != text) _rootTip.SetToolTip(_rootList, text);
                }
            };
            return card;
        }

        private CardPanel BuildOptionsCard()
        {
            CardPanel card = new CardPanel();
            card.Dock = DockStyle.Fill;
            card.Padding = new Padding(14, 12, 14, 12);

            Label title = Theme.MakeLabel("2   Scan options", Theme.H3Font, Theme.Text);
            title.SetBounds(0, 0, 280, 22);
            card.Controls.Add(title);

            Label sub = Theme.MakeLabel("Sensible defaults, fully adjustable", Theme.SmallFont, Theme.Muted);
            sub.SetBounds(0, 22, 280, 18);
            card.Controls.Add(sub);

            _chkSkipSystem = MakeCheckBox("Skip Windows and Program Files", 0, 48, 288);
            card.Controls.Add(_chkSkipSystem);

            _chkHidden = MakeCheckBox("Include hidden and system files", 0, 74, 288);
            card.Controls.Add(_chkHidden);

            _chkEmpty = MakeCheckBox("Include empty (0-byte) files", 0, 100, 288);
            card.Controls.Add(_chkEmpty);

            _chkVerify = MakeCheckBox("Verify content again before deleting", 0, 126, 288);
            card.Controls.Add(_chkVerify);

            Label minLabel = Theme.MakeLabel("Minimum file size", Theme.BaseFont, Theme.Text);
            minLabel.SetBounds(0, 162, 138, 22);
            card.Controls.Add(minLabel);

            _numMinSize = new NumericUpDown();
            _numMinSize.Minimum = 0;
            _numMinSize.Maximum = 1048576;
            _numMinSize.Increment = 1;
            _numMinSize.Value = 1;
            _numMinSize.ThousandsSeparator = true;
            _numMinSize.Font = Theme.BaseFont;
            _numMinSize.BorderStyle = BorderStyle.FixedSingle;
            _numMinSize.TextAlign = HorizontalAlignment.Right;
            _numMinSize.SetBounds(140, 158, 82, 25);
            _numMinSize.ValueChanged += delegate { UpdateMinSizeHint(); };
            card.Controls.Add(_numMinSize);

            Label kb = Theme.MakeLabel("KB", Theme.SmallFont, Theme.Muted);
            kb.SetBounds(228, 162, 30, 20);
            card.Controls.Add(kb);

            _minSizeHint = Theme.MakeLabel(string.Empty, Theme.TinyFont, Theme.Faint);
            _minSizeHint.SetBounds(0, 188, 288, 18);
            card.Controls.Add(_minSizeHint);

            Label hard = Theme.MakeLabel("Hard links are detected automatically and never counted as reclaimable space.",
                Theme.TinyFont, Theme.Faint);
            hard.AutoSize = false;
            hard.SetBounds(0, 214, 288, 34);
            card.Controls.Add(hard);

            _chkSkipSystem.CheckedChanged += delegate { UpdateMinSizeHint(); };
            UpdateMinSizeHint();
            return card;
        }

        private void BuildScanCard(CardPanel card)
        {
            Label title = Theme.MakeLabel("3   Start scanning", Theme.H3Font, Theme.Text);
            title.SetBounds(0, 0, 280, 22);
            card.Controls.Add(title);

            _scanButton = new FlatButton();
            _scanButton.Text = "Start scan";
            _scanButton.Style = FlatButtonStyle.Primary;
            _scanButton.Font = new Font("Segoe UI Semibold", 10.5f);
            _scanButton.SetBounds(0, 28, 288, 44);
            _scanButton.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _scanButton.Click += delegate { StartScan(); };
            card.Controls.Add(_scanButton);

            _cancelButton = new FlatButton();
            _cancelButton.Text = "Cancel scan";
            _cancelButton.Style = FlatButtonStyle.Secondary;
            _cancelButton.SetBounds(0, 78, 288, 30);
            _cancelButton.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _cancelButton.Visible = false;
            _cancelButton.Click += delegate { CancelScan(); };
            card.Controls.Add(_cancelButton);

            _progressTrack = new ProgressTrack();
            _progressTrack.SetBounds(0, 114, 288, 8);
            _progressTrack.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            card.Controls.Add(_progressTrack);

            _scanStatus = Theme.MakeLabel("Ready to scan.", Theme.SmallFont, Theme.Muted);
            _scanStatus.SetBounds(0, 128, 288, 18);
            _scanStatus.AutoEllipsis = true;
            _scanStatus.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            card.Controls.Add(_scanStatus);

            _currentPath = Theme.MakeLabel("Add a folder or drive to begin.", Theme.TinyFont, Theme.Faint);
            _currentPath.SetBounds(0, 146, 288, 18);
            _currentPath.AutoEllipsis = true;
            _currentPath.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            card.Controls.Add(_currentPath);
        }

        private CheckBox MakeCheckBox(string text, int x, int y, int width)
        {
            CheckBox box = new CheckBox();
            box.Text = text;
            box.Font = Theme.BaseFont;
            box.ForeColor = Theme.Text;
            box.BackColor = Color.Transparent;
            box.AutoSize = false;
            box.FlatStyle = FlatStyle.Flat;
            box.SetBounds(x, y, width, 23);
            return box;
        }

        private void BuildContent(Panel content)
        {
            TableLayoutPanel layout = new TableLayoutPanel();
            layout.Dock = DockStyle.Fill;
            layout.ColumnCount = 1;
            layout.RowCount = 2;
            layout.BackColor = Theme.Background;
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 106));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            content.Controls.Add(layout);

            Panel summaryPanel = new Panel();
            summaryPanel.Dock = DockStyle.Fill;
            summaryPanel.BackColor = Theme.Background;
            summaryPanel.Padding = new Padding(0, 0, 0, 14);
            layout.Controls.Add(summaryPanel, 0, 0);

            TableLayoutPanel summaryRow = new TableLayoutPanel();
            summaryRow.Dock = DockStyle.Fill;
            summaryRow.ColumnCount = 4;
            summaryRow.RowCount = 1;
            summaryRow.BackColor = Theme.Background;
            summaryRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            summaryRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            summaryRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            summaryRow.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            summaryPanel.Controls.Add(summaryRow);

            _cardGroups = new SummaryCard();
            _cardGroups.Caption = "Duplicate groups";
            _cardGroups.Value = "0";
            _cardGroups.Hint = "sets of identical files";
            _cardGroups.Accent = Theme.Accent;
            _cardGroups.Dock = DockStyle.Fill;
            _cardGroups.Margin = new Padding(0, 0, 10, 0);
            summaryRow.Controls.Add(_cardGroups, 0, 0);

            _cardFiles = new SummaryCard();
            _cardFiles.Caption = "Redundant copies";
            _cardFiles.Value = "0";
            _cardFiles.Hint = "extra copies";
            _cardFiles.Accent = Theme.Warning;
            _cardFiles.Dock = DockStyle.Fill;
            _cardFiles.Margin = new Padding(0, 0, 10, 0);
            summaryRow.Controls.Add(_cardFiles, 1, 0);

            _cardReclaim = new SummaryCard();
            _cardReclaim.Caption = "Reclaimable";
            _cardReclaim.Value = "0 B";
            _cardReclaim.Hint = "if duplicates are removed";
            _cardReclaim.Accent = Theme.Success;
            _cardReclaim.Dock = DockStyle.Fill;
            _cardReclaim.Margin = new Padding(0, 0, 10, 0);
            summaryRow.Controls.Add(_cardReclaim, 2, 0);

            _cardScanned = new SummaryCard();
            _cardScanned.Caption = "Files scanned";
            _cardScanned.Value = "0";
            _cardScanned.Hint = "across 0 locations";
            _cardScanned.Accent = Color.FromArgb(124, 58, 237);
            _cardScanned.Dock = DockStyle.Fill;
            _cardScanned.Margin = new Padding(0);
            summaryRow.Controls.Add(_cardScanned, 3, 0);

            _resultsCard = new CardPanel();
            _resultsCard.Dock = DockStyle.Fill;
            _resultsCard.Padding = new Padding(0);
            _resultsCard.CornerRadius = 14;
            layout.Controls.Add(_resultsCard, 0, 1);

            TableLayoutPanel resultsLayout = new TableLayoutPanel();
            resultsLayout.Dock = DockStyle.Fill;
            resultsLayout.ColumnCount = 1;
            resultsLayout.RowCount = 3;
            resultsLayout.BackColor = Theme.Surface;
            resultsLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
            resultsLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            resultsLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
            _resultsCard.Controls.Add(resultsLayout);

            Panel gridHost = new Panel();
            gridHost.Dock = DockStyle.Fill;
            gridHost.BackColor = Theme.Surface;

            Panel header = BuildResultsHeader();
            resultsLayout.Controls.Add(header, 0, 0);
            resultsLayout.Controls.Add(gridHost, 0, 1);
            Panel footer = BuildResultsFooter();
            resultsLayout.Controls.Add(footer, 0, 2);

            BuildResultsGrid(gridHost);

            _emptyState = new EmptyState();
            _emptyState.Dock = DockStyle.Fill;
            _emptyState.BackColor = Theme.Surface;
            gridHost.Controls.Add(_emptyState);
            _emptyState.BringToFront();
        }

        private Panel BuildResultsHeader()
        {
            Panel header = new Panel();
            header.Dock = DockStyle.Fill;
            header.BackColor = Theme.Surface;

            _resultsTitle = Theme.MakeLabel("Duplicate files", Theme.H3Font, Theme.Text);
            _resultsTitle.AutoSize = false;
            _resultsTitle.AutoEllipsis = true;
            _resultsTitle.SetBounds(16, 9, 240, 24);
            header.Controls.Add(_resultsTitle);

            _resultsSubtitle = Theme.MakeLabel("No scan results yet", Theme.SmallFont, Theme.Muted);
            _resultsSubtitle.AutoSize = false;
            _resultsSubtitle.AutoEllipsis = true;
            _resultsSubtitle.SetBounds(17, 31, 340, 18);
            header.Controls.Add(_resultsSubtitle);

            FlowLayoutPanel tools = new FlowLayoutPanel();
            tools.AutoSize = true;
            tools.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            tools.FlowDirection = FlowDirection.RightToLeft;
            tools.WrapContents = false;
            tools.BackColor = Color.Transparent;
            tools.Location = new Point(header.Width - 20, 10);
            tools.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            _search = new SearchBox();
            _search.Width = 240;
            _search.Height = 36;
            _search.Cue = "Search file name or folder...";
            _search.Margin = new Padding(8, 0, 0, 0);
            _search.Input.TextChanged += delegate { ApplyFilter(); };
            tools.Controls.Add(_search);

            _autoSelectButton = new FlatButton();
            _autoSelectButton.Text = "Keep rules ▾";
            _autoSelectButton.Style = FlatButtonStyle.Secondary;
            _autoSelectButton.Width = 130;
            _autoSelectButton.Height = 36;
            _autoSelectButton.Margin = new Padding(8, 0, 0, 0);
            _autoSelectButton.Click += delegate { ShowAutoSelectMenu(); };
            tools.Controls.Add(_autoSelectButton);

            _exportButton = new FlatButton();
            _exportButton.Text = "Export report";
            _exportButton.Style = FlatButtonStyle.Secondary;
            _exportButton.Width = 130;
            _exportButton.Height = 36;
            _exportButton.Margin = new Padding(8, 0, 0, 0);
            _exportButton.Click += delegate { ExportReport(); };
            tools.Controls.Add(_exportButton);

            header.Controls.Add(tools);
            header.Resize += delegate
            {
                if (header.Width < 820)
                {
                    _resultsTitle.Width = 178;
                    _resultsSubtitle.Width = 190;
                    _search.Width = 150;
                    _autoSelectButton.Text = "Rules";
                    _autoSelectButton.Width = 76;
                    _exportButton.Width = 110;
                }
                else
                {
                    _resultsTitle.Width = 240;
                    _resultsSubtitle.Width = 340;
                    _search.Width = 240;
                    _autoSelectButton.Text = "Keep rules ▾";
                    _autoSelectButton.Width = 130;
                    _exportButton.Width = 130;
                }
                tools.PerformLayout();
                tools.Left = header.Width - tools.Width - 14;
            };

            Panel line = new Panel();
            line.Dock = DockStyle.Bottom;
            line.Height = 1;
            line.BackColor = Theme.Border;
            header.Controls.Add(line);

            BuildAutoSelectMenu();
            return header;
        }

        private void BuildResultsGrid(Panel host)
        {
            _grid = new BufferedDataGridView();
            _grid.Dock = DockStyle.Fill;
            _grid.BackgroundColor = Theme.Surface;
            _grid.BorderStyle = BorderStyle.None;
            _grid.GridColor = Theme.GridLine;
            _grid.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            _grid.RowHeadersVisible = false;
            _grid.AllowUserToAddRows = false;
            _grid.AllowUserToDeleteRows = false;
            _grid.AllowUserToResizeRows = false;
            _grid.AllowUserToOrderColumns = false;
            _grid.MultiSelect = false;
            _grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            _grid.ReadOnly = true;
            _grid.EditMode = DataGridViewEditMode.EditProgrammatically;
            _grid.AutoGenerateColumns = false;
            _grid.ColumnHeadersHeight = 38;
            _grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            _grid.RowTemplate.Height = 34;
            _grid.EnableHeadersVisualStyles = false;
            _grid.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            _grid.ShowCellToolTips = true;
            _grid.Visible = false;

            _grid.ColumnHeadersDefaultCellStyle.BackColor = Theme.SurfaceAlt;
            _grid.ColumnHeadersDefaultCellStyle.ForeColor = Theme.Muted;
            _grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI Semibold", 8f);
            _grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(4, 0, 4, 0);
            _grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            _grid.DefaultCellStyle.BackColor = Theme.Surface;
            _grid.DefaultCellStyle.ForeColor = Theme.Text;
            _grid.DefaultCellStyle.Font = Theme.BaseFont;
            _grid.DefaultCellStyle.SelectionBackColor = Theme.Selection;
            _grid.DefaultCellStyle.SelectionForeColor = Theme.Text;
            _grid.DefaultCellStyle.Padding = new Padding(5, 0, 5, 0);
            _grid.AlternatingRowsDefaultCellStyle.BackColor = Theme.Surface;
            _grid.RowTemplate.DefaultCellStyle.BackColor = Theme.Surface;

            DataGridViewTextBoxColumn remove = new DataGridViewTextBoxColumn();
            remove.Name = "Remove";
            remove.HeaderText = "REMOVE";
            remove.Width = 72;
            remove.ReadOnly = true;
            remove.SortMode = DataGridViewColumnSortMode.NotSortable;
            remove.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            _grid.Columns.Add(remove);

            DataGridViewTextBoxColumn group = new DataGridViewTextBoxColumn();
            group.Name = "Group";
            group.HeaderText = "GROUP";
            group.Width = 68;
            group.ReadOnly = true;
            group.SortMode = DataGridViewColumnSortMode.NotSortable;
            group.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            _grid.Columns.Add(group);

            DataGridViewTextBoxColumn name = new DataGridViewTextBoxColumn();
            name.Name = "FileName";
            name.HeaderText = "FILE NAME";
            name.Width = 220;
            name.ReadOnly = true;
            name.SortMode = DataGridViewColumnSortMode.NotSortable;
            _grid.Columns.Add(name);

            DataGridViewTextBoxColumn size = new DataGridViewTextBoxColumn();
            size.Name = "Size";
            size.HeaderText = "SIZE";
            size.Width = 82;
            size.ReadOnly = true;
            size.SortMode = DataGridViewColumnSortMode.NotSortable;
            size.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            _grid.Columns.Add(size);

            DataGridViewTextBoxColumn modified = new DataGridViewTextBoxColumn();
            modified.Name = "Modified";
            modified.HeaderText = "MODIFIED";
            modified.Width = 152;
            modified.ReadOnly = true;
            modified.SortMode = DataGridViewColumnSortMode.NotSortable;
            _grid.Columns.Add(modified);

            DataGridViewTextBoxColumn location = new DataGridViewTextBoxColumn();
            location.Name = "Location";
            location.HeaderText = "LOCATION";
            location.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            location.MinimumWidth = 200;
            location.ReadOnly = true;
            location.SortMode = DataGridViewColumnSortMode.NotSortable;
            _grid.Columns.Add(location);

            DataGridViewTextBoxColumn status = new DataGridViewTextBoxColumn();
            status.Name = "Status";
            status.HeaderText = "ACTION";
            status.Width = 88;
            status.ReadOnly = true;
            status.SortMode = DataGridViewColumnSortMode.NotSortable;
            status.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            _grid.Columns.Add(status);

            _grid.CellClick += OnGridCellClick;
            _grid.CellDoubleClick += OnGridCellDoubleClick;
            _grid.CellMouseDown += OnGridCellMouseDown;
            _grid.CellToolTipTextNeeded += OnGridToolTip;
            _grid.KeyDown += OnGridKeyDown;

            BuildGridMenu();
            _grid.ContextMenuStrip = _gridMenu;

            host.Controls.Add(_grid);
        }

        private Panel BuildResultsFooter()
        {
            Panel footer = new Panel();
            footer.Dock = DockStyle.Fill;
            footer.BackColor = Theme.Surface;

            Panel line = new Panel();
            line.Dock = DockStyle.Top;
            line.Height = 1;
            line.BackColor = Theme.Border;
            footer.Controls.Add(line);

            _selectionLabel = Theme.MakeLabel("Select duplicates to remove", Theme.SmallFont, Theme.Muted);
            _selectionLabel.SetBounds(16, 20, 360, 22);
            _selectionLabel.AutoEllipsis = true;
            footer.Controls.Add(_selectionLabel);

            FlowLayoutPanel actions = new FlowLayoutPanel();
            actions.AutoSize = true;
            actions.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            actions.FlowDirection = FlowDirection.RightToLeft;
            actions.WrapContents = false;
            actions.BackColor = Color.Transparent;
            actions.Location = new Point(footer.Width - 20, 12);
            actions.Anchor = AnchorStyles.Top | AnchorStyles.Right;

            _deleteButton = new FlatButton();
            _deleteButton.Text = "Remove selected";
            _deleteButton.Style = FlatButtonStyle.Danger;
            _deleteButton.Width = 178;
            _deleteButton.Height = 38;
            _deleteButton.Enabled = false;
            _deleteButton.Click += delegate { DeleteSelected(); };
            actions.Controls.Add(_deleteButton);

            _clearSelectionButton = new FlatButton();
            _clearSelectionButton.Text = "Clear";
            _clearSelectionButton.Style = FlatButtonStyle.Secondary;
            _clearSelectionButton.Width = 86;
            _clearSelectionButton.Height = 38;
            _clearSelectionButton.Enabled = false;
            _clearSelectionButton.Click += delegate { ClearSelection(); };
            actions.Controls.Add(_clearSelectionButton);

            _selectDuplicatesButton = new FlatButton();
            _selectDuplicatesButton.Text = "Auto-select";
            _selectDuplicatesButton.Style = FlatButtonStyle.Secondary;
            _selectDuplicatesButton.Width = 120;
            _selectDuplicatesButton.Height = 38;
            _selectDuplicatesButton.Enabled = false;
            _selectDuplicatesButton.Click += delegate { ApplyKeepRule(KeepRule.Newest); };
            _gridTip.SetToolTip(_selectDuplicatesButton,
                "Mark the older copies for removal, keeping the newest copy in each group. Review before deleting.");
            actions.Controls.Add(_selectDuplicatesButton);

            footer.Controls.Add(actions);
            footer.Resize += delegate
            {
                actions.Left = footer.Width - actions.Width - 14;
                _selectionLabel.Width = Math.Max(120, actions.Left - 30);
            };
            return footer;
        }

        private Panel BuildStatusBar()
        {
            Panel status = new Panel();
            status.Dock = DockStyle.Fill;
            status.BackColor = Theme.Surface;
            status.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (Pen pen = new Pen(Theme.Border, 1f))
                {
                    e.Graphics.DrawLine(pen, 0, 0, status.Width, 0);
                }
            };

            _statusLabel = Theme.MakeLabel("Ready", Theme.TinyFont, Theme.Muted);
            _statusLabel.SetBounds(18, 6, 520, 18);
            _statusLabel.AutoEllipsis = true;
            status.Controls.Add(_statusLabel);

            _issuesLink = new LinkLabel();
            _issuesLink.Text = string.Empty;
            _issuesLink.Font = Theme.TinyFont;
            _issuesLink.LinkColor = Theme.Warning;
            _issuesLink.ActiveLinkColor = Theme.Danger;
            _issuesLink.BackColor = Color.Transparent;
            _issuesLink.AutoSize = true;
            _issuesLink.Visible = false;
            _issuesLink.SetBounds(status.Width - 430, 6, 190, 18);
            _issuesLink.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            _issuesLink.LinkClicked += delegate { ShowIssues(); };
            status.Controls.Add(_issuesLink);

            Label right = Theme.MakeLabel("SHA-256  ·  hard-link aware", Theme.TinyFont, Theme.Faint);
            right.AutoSize = false;
            right.TextAlign = ContentAlignment.MiddleRight;
            right.SetBounds(status.Width - 215, 6, 200, 18);
            right.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            status.Controls.Add(right);

            status.Resize += delegate
            {
                right.Left = status.Width - 215;
                _issuesLink.Left = status.Width - (right.Width + 235);
            };
            return status;
        }

        private void LoadSettingsIntoUi()
        {
            _chkSkipSystem.Checked = _settings.SkipSystemFolders;
            _chkHidden.Checked = _settings.IncludeHiddenSystem;
            _chkEmpty.Checked = _settings.IncludeEmptyFiles;
            _chkVerify.Checked = _settings.VerifyBeforeDelete;

            long kb = _settings.MinFileSize / 1024;
            if (kb < 0) kb = 0;
            if (kb > (long)_numMinSize.Maximum) kb = (long)_numMinSize.Maximum;
            _numMinSize.Value = kb;

            for (int i = 0; i < _settings.Roots.Count; i++)
            {
                AddRoot(_settings.Roots[i], false);
            }

            _rootList.SelectedIndex = _roots.Count > 0 ? 0 : -1;
            UpdateRootButtons();
            UpdateMinSizeHint();
        }

        private void UpdateMinSizeHint()
        {
            if (_numMinSize.Value <= 0)
                _minSizeHint.Text = "0 KB: compare every non-empty file.";
            else
                _minSizeHint.Text = "Skip files smaller than " + _numMinSize.Value.ToString("N0") + " KB.";
        }

        private void UpdateRootButtons()
        {
            bool has = _rootList != null && _rootList.SelectedIndex >= 0;
            if (_removeRootButton != null) _removeRootButton.Enabled = has && !_isScanning;
            if (_addFolderButton != null) _addFolderButton.Enabled = !_isScanning;
            if (_addDriveButton != null) _addDriveButton.Enabled = !_isScanning;
        }

        private void SetStatus(string text)
        {
            if (_statusLabel != null && !_statusLabel.IsDisposed)
                _statusLabel.Text = text;
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.F5)
            {
                if (!_isScanning) StartScan();
                return true;
            }
            if (keyData == (Keys.Control | Keys.O))
            {
                if (!_isScanning) AddFolder();
                return true;
            }
            if (keyData == (Keys.Control | Keys.E))
            {
                if (_result != null) ExportReport();
                return true;
            }
            if (keyData == (Keys.Control | Keys.F))
            {
                _search.Focus();
                return true;
            }
            if (keyData == Keys.Escape)
            {
                if (_isScanning) CancelScan();
                else if (_search.Input.Text.Length > 0) _search.Input.Clear();
                return true;
            }
            if (keyData == Keys.Delete && _grid != null && _grid.Focused && !_isScanning && _result != null)
            {
                DeleteSelected();
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void FitWindowToScreen()
        {
            Rectangle work = Screen.FromControl(this).WorkingArea;
            int maxWidth = Math.Max(900, work.Width - 40);
            int maxHeight = Math.Max(620, work.Height - 60);
            int width = Math.Min(Width, maxWidth);
            int height = Math.Min(Height, maxHeight);
            if (width < MinimumSize.Width) width = Math.Min(MinimumSize.Width, maxWidth);
            if (height < MinimumSize.Height) height = Math.Min(MinimumSize.Height, maxHeight);
            Size = new Size(width, height);
            Left = work.Left + (work.Width - Width) / 2;
            Top = work.Top + (work.Height - Height) / 2;
        }

        private void OnFormClosing(object sender, FormClosingEventArgs e)
        {
            if (_isScanning && !_closeWhenDone)
            {
                DialogResult answer = MessageBox.Show(this,
                    "A scan is running. Cancel it and close DupScan Pro?",
                    "Scan in progress", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (answer != DialogResult.Yes)
                {
                    e.Cancel = true;
                    return;
                }
                _closeWhenDone = true;
                CancelScan();
                e.Cancel = true;
                return;
            }

            if (WindowState == FormWindowState.Normal)
            {
                _settings.WindowWidth = ClientSize.Width;
                _settings.WindowHeight = ClientSize.Height;
            }
            _settings.Maximized = WindowState == FormWindowState.Maximized;
            _settings.Roots = new List<string>(_roots);
            SettingsStore.Save(_settings);
        }

        private void OnDragEnter(object sender, DragEventArgs e)
        {
            if (_isScanning || e.Data == null || !e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.None;
                return;
            }
            string[] paths = e.Data.GetData(DataFormats.FileDrop) as string[];
            e.Effect = paths != null && paths.Length > 0 ? DragDropEffects.Copy : DragDropEffects.None;
        }

        private void OnDragDrop(object sender, DragEventArgs e)
        {
            if (_isScanning || e.Data == null) return;
            string[] paths = e.Data.GetData(DataFormats.FileDrop) as string[];
            if (paths == null) return;
            for (int i = 0; i < paths.Length; i++)
            {
                if (Directory.Exists(paths[i])) AddRoot(paths[i], true);
            }
        }
    }
}
