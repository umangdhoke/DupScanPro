using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace DupScan
{
    /// <summary>
    /// Recursively scans folders, groups files by size, then by quick fingerprint,
    /// then by full SHA-256 content hash. Hard links are detected and excluded
    /// because deleting a hard-link path does not reclaim disk space.
    /// </summary>
    public sealed class DuplicateScanner
    {
        private readonly IProgress<ScanProgress> _progress;
        private readonly object _progressLock = new object();
        private readonly object _issueLock = new object();
        private readonly Stopwatch _clock = new Stopwatch();
        private readonly List<ScanIssue> _issues = new List<ScanIssue>();
        private readonly HashSet<string> _systemFolderNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "Windows", "Windows.old", "Program Files", "Program Files (x86)", "ProgramData",
            "$Recycle.Bin", "System Volume Information", "Recovery", "MSOCache",
            "$WinREAgent", "Config.Msi", "PerfLogs", "$SysReset", "Boot", "EFI"
        };

        private ScanOptions _options;
        private CancellationToken _token;
        private long _lastReportMs = -1000;
        private int _filesFound;
        private long _bytesFound;
        private int _issueCount;
        private string _currentPath = string.Empty;

        public DuplicateScanner(IProgress<ScanProgress> progress)
        {
            _progress = progress;
        }

        public ScanResult Scan(ScanOptions options, CancellationToken token)
        {
            if (options == null) throw new ArgumentNullException("options");

            _options = options.Clone();
            _token = token;
            _filesFound = 0;
            _bytesFound = 0;
            _issueCount = 0;
            _issues.Clear();
            _clock.Restart();
            _lastReportMs = -1000;

            ScanResult result = new ScanResult();
            result.Roots = NormalizeRoots(options.Roots, result);
            if (result.Roots.Count == 0)
            {
                result.WasCancelled = false;
                result.CompletedAt = DateTime.Now;
                result.Duration = _clock.Elapsed;
                throw new InvalidOperationException("Add at least one existing folder or drive to scan.");
            }

            Report(ScanPhase.Enumerating, "Finding files...", 0, 0, true, string.Empty, true);

            Dictionary<long, List<FileRecord>> bySize = new Dictionary<long, List<FileRecord>>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            for (int i = 0; i < result.Roots.Count; i++)
            {
                token.ThrowIfCancellationRequested();
                string root = result.Roots[i];
                if (File.Exists(root))
                {
                    AddFile(new FileInfo(root), root, bySize, seen, false);
                }
                else if (Directory.Exists(root))
                {
                    WalkDirectory(root, root, bySize, seen, result);
                }
                else
                {
                    AddIssue(root, "Folder not found", true);
                }
            }

            result.FilesScanned = _filesFound;
            result.TotalBytesScanned = _bytesFound;
            result.Issues = new List<ScanIssue>(_issues);
            result.IssueCount = _issueCount;

            Report(ScanPhase.Enumerating, "Found " + FormatUtil.FormatCount(_filesFound) + " files. Comparing sizes...",
                _filesFound, 0, true, string.Empty, true);

            List<FileRecord> candidates = new List<FileRecord>();
            int uniqueBySize = 0;
            foreach (List<FileRecord> group in bySize.Values)
            {
                if (group.Count >= 2) candidates.AddRange(group);
                else uniqueBySize++;
            }

            result.CandidateFiles = candidates.Count;
            result.SkippedBySize = uniqueBySize;

            if (candidates.Count < 2)
            {
                Finish(result, true);
                return result;
            }

            token.ThrowIfCancellationRequested();

            // Phase 2: a cheap fingerprint (size + first/last 64 KB) removes almost
            // all same-size-but-different files before the expensive full hash.
            int quickTotal = candidates.Count;
            int quickDone = 0;
            int noteCount = Math.Max(1, quickTotal / 200);
            ParallelOptions quickOptions = new ParallelOptions();
            quickOptions.CancellationToken = token;
            quickOptions.MaxDegreeOfParallelism = Math.Max(1, _options.HashThreads);

            Report(ScanPhase.QuickHashing, "Fingerprinting " + FormatUtil.FormatCount(quickTotal) + " same-size files...",
                0, quickTotal, false, string.Empty, true);

            Parallel.ForEach(candidates, quickOptions, delegate(FileRecord file)
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    Interlocked.Exchange(ref _currentPath, file.Path);
                    file.QuickHash = FileHasher.QuickHash(file.Path, file.Size, token);
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    file.QuickHash = null;
                    AddIssue(file.Path, "Could not read file: " + ex.Message, false);
                }

                int done = Interlocked.Increment(ref quickDone);
                if (done % noteCount == 0 || done == quickTotal)
                {
                    Report(ScanPhase.QuickHashing,
                        "Fingerprinting files... " + FormatUtil.FormatCount(done) + " / " + FormatUtil.FormatCount(quickTotal),
                        done, quickTotal, false, file.Path, done == quickTotal);
                }
            });

            token.ThrowIfCancellationRequested();

            Dictionary<string, List<FileRecord>> quickGroups = new Dictionary<string, List<FileRecord>>(StringComparer.Ordinal);
            for (int i = 0; i < candidates.Count; i++)
            {
                FileRecord file = candidates[i];
                if (string.IsNullOrEmpty(file.QuickHash)) continue;
                string key = file.Size.ToString() + "|" + file.QuickHash;
                List<FileRecord> list;
                if (!quickGroups.TryGetValue(key, out list))
                {
                    list = new List<FileRecord>();
                    quickGroups.Add(key, list);
                }
                list.Add(file);
            }

            List<FileRecord> fullCandidates = new List<FileRecord>();
            foreach (List<FileRecord> group in quickGroups.Values)
            {
                if (group.Count >= 2) fullCandidates.AddRange(group);
            }

            if (fullCandidates.Count < 2)
            {
                Finish(result, true);
                return result;
            }

            // Phase 3: full content SHA-256 on the remaining candidates only.
            int fullTotal = fullCandidates.Count;
            int fullDone = 0;
            int fullNote = Math.Max(1, fullTotal / 200);
            ParallelOptions fullOptions = new ParallelOptions();
            fullOptions.CancellationToken = token;
            fullOptions.MaxDegreeOfParallelism = Math.Max(1, _options.HashThreads);

            Report(ScanPhase.FullHashing, "Checking content of " + FormatUtil.FormatCount(fullTotal) + " likely duplicates...",
                0, fullTotal, false, string.Empty, true);

            Parallel.ForEach(fullCandidates, fullOptions, delegate(FileRecord file)
            {
                token.ThrowIfCancellationRequested();
                try
                {
                    Interlocked.Exchange(ref _currentPath, file.Path);
                    file.FullHash = FileHasher.FullHash(file.Path, token, null);
                }
                catch (OperationCanceledException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    file.FullHash = null;
                    AddIssue(file.Path, "Could not hash file: " + ex.Message, false);
                }

                int done = Interlocked.Increment(ref fullDone);
                if (done % fullNote == 0 || done == fullTotal)
                {
                    Report(ScanPhase.FullHashing,
                        "Verifying content... " + FormatUtil.FormatCount(done) + " / " + FormatUtil.FormatCount(fullTotal),
                        done, fullTotal, false, file.Path, done == fullTotal);
                }
            });

            token.ThrowIfCancellationRequested();

            Report(ScanPhase.Grouping, "Preparing duplicate report...", 0, 0, true, string.Empty, true);

            Dictionary<string, List<FileRecord>> hashGroups = new Dictionary<string, List<FileRecord>>(StringComparer.Ordinal);
            for (int i = 0; i < fullCandidates.Count; i++)
            {
                FileRecord file = fullCandidates[i];
                if (string.IsNullOrEmpty(file.FullHash)) continue;
                string key = file.Size.ToString() + "|" + file.FullHash;
                List<FileRecord> list;
                if (!hashGroups.TryGetValue(key, out list))
                {
                    list = new List<FileRecord>();
                    hashGroups.Add(key, list);
                }
                list.Add(file);
            }

            List<DuplicateGroup> groups = new List<DuplicateGroup>();
            foreach (KeyValuePair<string, List<FileRecord>> pair in hashGroups)
            {
                List<FileRecord> groupFiles = pair.Value;
                if (groupFiles.Count < 2) continue;

                List<FileRecord> usable;
                if (_options.DetectHardLinks)
                {
                    usable = RemoveHardLinks(groupFiles, result);
                }
                else
                {
                    usable = groupFiles;
                }

                if (usable.Count < 2) continue;

                usable.Sort(delegate(FileRecord a, FileRecord b)
                {
                    int cmp = b.ModifiedUtc.CompareTo(a.ModifiedUtc);
                    if (cmp != 0) return cmp;
                    return string.Compare(a.Path, b.Path, StringComparison.OrdinalIgnoreCase);
                });

                DuplicateGroup group = new DuplicateGroup();
                group.Size = usable[0].Size;
                group.Hash = usable[0].FullHash;
                for (int i = 0; i < usable.Count; i++)
                {
                    DuplicateFile duplicateFile = new DuplicateFile();
                    duplicateFile.File = usable[i];
                    duplicateFile.SelectedForDeletion = false;
                    group.Files.Add(duplicateFile);
                }
                groups.Add(group);
            }

            groups.Sort(delegate(DuplicateGroup a, DuplicateGroup b)
            {
                int cmp = b.ReclaimableBytes.CompareTo(a.ReclaimableBytes);
                if (cmp != 0) return cmp;
                return string.Compare(a.Title, b.Title, StringComparison.OrdinalIgnoreCase);
            });

            for (int i = 0; i < groups.Count; i++)
            {
                groups[i].Id = i + 1;
            }

            result.Groups = groups;
            Finish(result, false);
            return result;
        }

        private void WalkDirectory(string directory, string root, Dictionary<long, List<FileRecord>> bySize,
            HashSet<string> seen, ScanResult result)
        {
            Stack<string> pending = new Stack<string>();
            pending.Push(directory);

            while (pending.Count > 0)
            {
                _token.ThrowIfCancellationRequested();
                string current = pending.Pop();

                DirectoryInfo info;
                try
                {
                    info = new DirectoryInfo(current);
                    if (!info.Exists) continue;
                }
                catch (Exception ex)
                {
                    AddIssue(current, ex.Message, true);
                    continue;
                }

                try
                {
                    FileSystemInfo[] entries = info.GetFileSystemInfos();
                    for (int i = 0; i < entries.Length; i++)
                    {
                        _token.ThrowIfCancellationRequested();
                        FileSystemInfo entry = entries[i];
                        Interlocked.Exchange(ref _currentPath, entry.FullName);

                        try
                        {
                            DirectoryInfo childDir = entry as DirectoryInfo;
                            if (childDir != null && _options.IgnoreReparsePoints &&
                                (entry.Attributes & FileAttributes.ReparsePoint) != 0)
                            {
                                continue;
                            }


                            if (childDir != null)
                            {
                                if (_options.SkipSystemFolders && _systemFolderNames.Contains(entry.Name))
                                    continue;
                                if (!_options.IncludeHiddenSystem &&
                                    (entry.Attributes & (FileAttributes.Hidden | FileAttributes.System)) != 0)
                                    continue;
                                pending.Push(entry.FullName);
                                continue;
                            }

                            FileInfo file = entry as FileInfo;
                            if (file == null) continue;
                            if (!_options.IncludeHiddenSystem &&
                                (file.Attributes & (FileAttributes.Hidden | FileAttributes.System)) != 0)
                                continue;
                            AddFile(file, root, bySize, seen, true);
                        }
                        catch (Exception ex)
                        {
                            AddIssue(entry.FullName, ex.Message, entry is DirectoryInfo);
                        }
                    }
                }
                catch (UnauthorizedAccessException ex)
                {
                    AddIssue(current, "Access denied. Try running DupScan Pro as administrator. " + ex.Message, true);
                }
                catch (Exception ex)
                {
                    AddIssue(current, ex.Message, true);
                }

                if ((_clock.ElapsedMilliseconds - _lastReportMs) > 120)
                {
                    Report(ScanPhase.Enumerating,
                        "Finding files... " + FormatUtil.FormatCount(_filesFound) + " files found",
                        _filesFound, 0, true, current, false);
                }
            }
        }

        private void AddFile(FileInfo file, string root, Dictionary<long, List<FileRecord>> bySize,
            HashSet<string> seen, bool checkOptions)
        {
            try
            {
                long size = file.Length;
                if (checkOptions)
                {
                    if (size == 0)
                    {
                        if (!_options.IncludeEmptyFiles) return;
                    }
                    else if (size < _options.MinFileSize)
                    {
                        return;
                    }
                }

                if (!seen.Add(file.FullName)) return;

                FileRecord record = new FileRecord();
                record.Path = file.FullName;
                record.Root = root;
                record.Size = size;
                record.ModifiedUtc = file.LastWriteTimeUtc;
                record.CreatedUtc = file.CreationTimeUtc;
                record.Attributes = file.Attributes;

                List<FileRecord> list;
                if (!bySize.TryGetValue(size, out list))
                {
                    list = new List<FileRecord>();
                    bySize.Add(size, list);
                }
                list.Add(record);

                Interlocked.Increment(ref _filesFound);
                Interlocked.Add(ref _bytesFound, size);
            }
            catch (Exception ex)
            {
                AddIssue(file.FullName, ex.Message, false);
            }
        }

        private List<FileRecord> RemoveHardLinks(List<FileRecord> files, ScanResult result)
        {
            List<FileRecord> usable = new List<FileRecord>(files.Count);
            HashSet<string> identities = new HashSet<string>(StringComparer.Ordinal);

            for (int i = 0; i < files.Count; i++)
            {
                FileRecord file = files[i];
                string identity;
                uint links;
                if (NativeMethods.TryGetFileIdentity(file.Path, out identity, out links))
                {
                    file.Identity = identity;
                    file.HardLinkCount = links;
                    if (links > 1)
                    {
                        file.IsHardLink = true;
                        result.SkippedHardLinks++;
                        continue;
                    }
                    if (!identities.Add(identity))
                    {
                        file.IsHardLink = true;
                        result.SkippedHardLinks++;
                        continue;
                    }
                }
                usable.Add(file);
            }

            return usable;
        }

        private List<string> NormalizeRoots(List<string> roots, ScanResult result)
        {
            List<string> unique = new List<string>();
            HashSet<string> seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (roots != null)
            {
                for (int i = 0; i < roots.Count; i++)
                {
                    string normalized = PathUtil.Normalize(roots[i]);
                    if (string.IsNullOrEmpty(normalized)) continue;
                    if (!Directory.Exists(normalized) && !File.Exists(normalized)) continue;
                    if (seen.Add(normalized)) unique.Add(normalized);
                }
            }

            unique.Sort(delegate(string a, string b) { return a.Length.CompareTo(b.Length); });
            List<string> kept = new List<string>();
            for (int i = 0; i < unique.Count; i++)
            {
                string candidate = unique[i];
                if (File.Exists(candidate))
                {
                    if (!kept.Any(delegate(string p) { return PathUtil.IsSamePath(p, candidate); }))
                        kept.Add(candidate);
                    continue;
                }

                bool covered = false;
                for (int j = 0; j < kept.Count; j++)
                {
                    if (File.Exists(kept[j])) continue;
                    if (PathUtil.IsSubPathOf(candidate, kept[j]) || PathUtil.IsSamePath(candidate, kept[j]))
                    {
                        covered = true;
                        break;
                    }
                }
                if (!covered) kept.Add(candidate);
            }

            kept.Sort(StringComparer.OrdinalIgnoreCase);
            result.Roots = kept;
            return kept;
        }

        private void AddIssue(string path, string message, bool isDirectory)
        {
            lock (_issueLock)
            {
                _issueCount++;
                if (_issues.Count < 1000)
                {
                    _issues.Add(new ScanIssue(path, message, isDirectory));
                }
            }
        }

        private void Report(ScanPhase phase, string message, long current, long total, bool indeterminate,
            string currentPath, bool force)
        {
            long now = _clock.ElapsedMilliseconds;
            lock (_progressLock)
            {
                if (!force && (now - _lastReportMs) < 120) return;
                _lastReportMs = now;

                if (_progress == null) return;
                ScanProgress progress = new ScanProgress();
                progress.Phase = phase;
                progress.Message = message;
                progress.Current = current;
                progress.Total = total;
                progress.IsIndeterminate = indeterminate;
                progress.FilesFound = _filesFound;
                progress.BytesFound = _bytesFound;
                progress.CurrentPath = currentPath;
                _progress.Report(progress);
            }
        }

        private void Finish(ScanResult result, bool noCandidates)
        {
            result.Groups.Sort(delegate(DuplicateGroup a, DuplicateGroup b)
            {
                return b.ReclaimableBytes.CompareTo(a.ReclaimableBytes);
            });
            for (int i = 0; i < result.Groups.Count; i++) result.Groups[i].Id = i + 1;

            result.Recalculate();
            result.CompletedAt = DateTime.Now;
            result.Duration = _clock.Elapsed;
            result.IssueCount = _issueCount;
            result.Issues = new List<ScanIssue>(_issues);

            string message = noCandidates
                ? "Scan complete. No duplicate files found."
                : "Scan complete. " + FormatUtil.FormatCount(result.Groups.Count) + " duplicate " +
                  FormatUtil.Plural(result.Groups.Count, "group", "groups") + " found.";

            ScanProgress final = new ScanProgress();
            final.Phase = ScanPhase.Completed;
            final.Message = message;
            final.Current = 1;
            final.Total = 1;
            final.IsIndeterminate = false;
            final.FilesFound = _filesFound;
            final.BytesFound = _bytesFound;
            final.DuplicateFiles = result.TotalDuplicateFiles;
            final.CurrentPath = string.Empty;
            if (_progress != null) _progress.Report(final);
        }
    }
}
