using System;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace DupScan
{
    internal static class NativeMethods
    {
        public const uint FILE_READ_ATTRIBUTES = 0x0080;
        public const uint FILE_SHARE_READ = 0x0001;
        public const uint FILE_SHARE_WRITE = 0x0002;
        public const uint FILE_SHARE_DELETE = 0x0004;
        public const uint OPEN_EXISTING = 3;
        public const uint FILE_FLAG_BACKUP_SEMANTICS = 0x02000000;

        public const uint FOF_SILENT = 0x0004;
        public const uint FOF_NOCONFIRMATION = 0x0010;
        public const uint FOF_ALLOWUNDO = 0x0040;
        public const uint FOF_NOERRORUI = 0x0400;
        public const uint FO_DELETE = 0x0003;

        [StructLayout(LayoutKind.Sequential)]
        public struct FILETIME
        {
            public uint dwLowDateTime;
            public uint dwHighDateTime;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct BY_HANDLE_FILE_INFORMATION
        {
            public uint FileAttributes;
            public FILETIME CreationTime;
            public FILETIME LastAccessTime;
            public FILETIME LastWriteTime;
            public uint VolumeSerialNumber;
            public uint FileSizeHigh;
            public uint FileSizeLow;
            public uint NumberOfLinks;
            public uint FileIndexHigh;
            public uint FileIndexLow;
        }

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        public struct SHFILEOPSTRUCT
        {
            public IntPtr hwnd;
            public uint wFunc;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string pFrom;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string pTo;
            public ushort fFlags;
            [MarshalAs(UnmanagedType.Bool)]
            public bool fAnyOperationsAborted;
            public IntPtr hNameMappings;
            [MarshalAs(UnmanagedType.LPWStr)]
            public string lpszProgressTitle;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern SafeFileHandle CreateFile(
            string lpFileName,
            uint dwDesiredAccess,
            uint dwShareMode,
            IntPtr lpSecurityAttributes,
            uint dwCreationDisposition,
            uint dwFlagsAndAttributes,
            IntPtr hTemplateFile);

        [DllImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool GetFileInformationByHandle(
            SafeFileHandle hFile,
            out BY_HANDLE_FILE_INFORMATION lpFileInformation);

        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        public static extern int SHFileOperation(ref SHFILEOPSTRUCT lpFileOp);

        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        public static extern IntPtr SendMessage(IntPtr hWnd, int Msg, IntPtr wParam, string lParam);

        public const int EM_SETCUEBANNER = 0x1501;

        public static bool TryGetFileIdentity(string path, out string identity, out uint linkCount)
        {
            identity = null;
            linkCount = 0;

            try
            {
                using (SafeFileHandle handle = CreateFile(
                    PathUtil.ToExtendedPath(path),
                    0,
                    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                    IntPtr.Zero,
                    OPEN_EXISTING,
                    FILE_FLAG_BACKUP_SEMANTICS,
                    IntPtr.Zero))
                {
                    if (handle.IsInvalid) return false;

                    BY_HANDLE_FILE_INFORMATION info;
                    if (!GetFileInformationByHandle(handle, out info)) return false;

                    long index = ((long)info.FileIndexHigh << 32) | (long)info.FileIndexLow;
                    identity = info.VolumeSerialNumber.ToString("X8") + ":" + index.ToString("X16");
                    linkCount = info.NumberOfLinks;
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public static int MoveToRecycleBin(string path)
        {
            SHFILEOPSTRUCT op = new SHFILEOPSTRUCT();
            op.hwnd = IntPtr.Zero;
            op.wFunc = FO_DELETE;
            op.pFrom = path + "\0\0";
            op.pTo = null;
            op.fFlags = (ushort)(FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI);
            op.fAnyOperationsAborted = false;
            op.hNameMappings = IntPtr.Zero;
            op.lpszProgressTitle = null;

            return SHFileOperation(ref op);
        }
    }
}
