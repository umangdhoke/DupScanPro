# DupScan Pro 1.1

**DupScan Pro** is a native Windows duplicate-file finder. It scans a folder or an entire drive, walks every subfolder, and finds files whose **contents are identical** — not merely files with the same name.

The finished product is **`DupScanPro-Setup-1.1.0.exe`**, a one-click native installer. It includes the complete offline **Microsoft .NET Framework 4.8** installer and only runs it if the target PC does not already have it. Windows 10/11 normally already includes 4.8.

The installed app is a single **`DupScan.exe`** (147 KB). The same exe is also portable if you prefer not to install.

---

## Quick start

1. Double-click **`DupScanPro-Setup-1.1.0.exe`**.
2. Follow the setup wizard. It installs to `C:\Program Files\DupScan Pro`, creates Start Menu and optional Desktop shortcuts, and registers an uninstaller.
3. Launch DupScan Pro from the final wizard page or the shortcut.
4. Add a folder with **Add folder**, or a whole drive with **Add drive**. You can also drag folders onto the window.
5. Leave the defaults, or adjust:
   - Skip Windows / Program Files (recommended)
   - Include hidden and system files
   - Include empty (0-byte) files
   - Minimum file size (default 1 KB)
6. Click **Start scan**.
7. Review the groups. Each row is one physical copy:
   - Green **KEEP** = this copy stays.
   - Red **DELETE** = this copy will be removed.
8. Select copies in one of these ways:
   - Click the checkbox at the start of a row.
   - Click **Auto-select** to keep the newest copy in every group and mark the rest.
   - Use **Keep rules** to keep the oldest, shortest path, or first alphabetical copy.
   - Right-click a row → **Keep this copy, remove the others**.
9. Click **Remove N files**, confirm the method, and review the result.
10. Optionally click **Export report** to save an HTML or CSV report before cleaning.

Every group always keeps at least one copy. The app blocks a deletion that would remove every copy in a group.

---

## What it does

- Recursive scan through **all levels** of subfolders.
- Multi-root scanning: add several folders/drives at once; overlapping roots are de-duplicated.
- Duplicate detection by:
  1. file size,
  2. quick fingerprint (first/last 64 KB + size),
  3. full **SHA-256** content hash.
- Skips inaccessible folders/files and reports them instead of stopping.
- Detects NTFS **hard links** and excludes them from reclaimable space.
- Skips junction/reparse-point folder loops.
- Long-path aware; handles paths beyond the classic 260-character limit where Windows supports it.
- Live progress with file counts, current path, and cancel.
- Sortable report view with group, file name, size, modified date, location, and action.
- Search/filter by file name, folder, or group.
- HTML and CSV report export.
- Detailed skipped-item viewer with copy-to-clipboard.
- After a completed cleanup, a support screen with the developer's UPI QR code and UPI ID, shown twice unless the user clicks "I donated".
- Saves scan locations and options between runs.
- One-click **Auto-select** and per-group **Keep this copy**.
- Safe deletion:
  - **Move to Recycle Bin** by default.
  - **Delete permanently** available with an extra confirmation checkbox.
  - Re-checks size, timestamp, identity, and full content immediately before deleting.
  - Refuses to delete files that changed since the scan.
  - Blocks protected Windows/Program Files/ProgramData paths.
  - Writes every deletion attempt to a CSV log.
- Detects Ctrl/Alt shortcuts and has an in-app **How it works** page.

---

## Safety model

- A duplicate group must always keep at least one copy.
- Clicking a row checkbox only changes the plan; nothing is deleted until you press **Remove**.
- The confirmation dialog disables its destructive button for a moment so a double-click cannot bypass it.
- Recycle Bin is the default. Permanent deletion requires checking **“I understand permanent deletion cannot be undone.”**
- Before deletion, DupScan verifies:
  - the file still exists,
  - the size and modification time are unchanged,
  - the file identity is unchanged (no replacement),
  - it is not now a multiple-hard-link file,
  - and, with verification enabled, the SHA-256 content still matches.
- Files under `%WINDIR%`, `%ProgramFiles%`, `%ProgramFiles(x86)%`, and `%ProgramData%` are refused.
- Windows/Program Files/ProgramData and recycle-bin folders are skipped by default during scans.

**Limits to know**

- Access-denied files/folders are skipped. Run DupScan **as administrator** if you deliberately want to include protected areas; do not do this casually.
- Cloud-only OneDrive files may need to be downloaded for hashing; reading them can hydrate them.
- Recycle Bin is only available for local fixed drives. Removable/network drives require permanent delete.
- A file that changes while a scan is running may be skipped at delete time.
- Very large drives can take a long time on the first scan. Use a smaller folder or a higher minimum size to start.

---

## Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `F5` | Start scan |
| `Ctrl+O` | Add folder |
| `Ctrl+E` | Export report |
| `Ctrl+F` | Focus search |
| `Esc` | Cancel scan / clear search |
| `Space` | Toggle the current row in the grid |
| `Delete` | Remove selected (when the grid has focus) |
| `Enter` | Open the current file |

---

## Local data

DupScan writes only to:

- `%LOCALAPPDATA%\DupScan\settings.ini` — saved locations and options.
- `%LOCALAPPDATA%\DupScan\Logs\deletions-YYYY-MM-DD.csv` — deletion audit log.
- `%LOCALAPPDATA%\DupScan\Logs\crash.log` — only if something goes wrong.

There is no telemetry, no network access, and no account.

---

## Build from source (optional)

Requirements: Windows 10/11 with .NET Framework 4.8. No NuGet packages.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build-installer.ps1
```

The compiler is the built-in `%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe`. The installer is built with Inno Setup 6 (the compiler is kept locally under `installer\tools\`). The setup bundles `installer\deps\NDP48-x86-x64-AllOS-ENU.exe`, the official Microsoft .NET Framework 4.8 offline installer, so installing does not require internet.

Run the engine test suite:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\build-tests.ps1
```

Test coverage includes nested duplicates, same-size/different-content, minimum size, empty files, hidden files, hard links, overlapping roots, keeps-one-copy enforcement, changed-file protection, Recycle Bin, cancellation, and report export.

---

## Project layout

```
DupScan/
  src/
    Program.cs              entry point, crash handling
    MainForm*.cs            UI, scan workflow, results, actions
    DuplicateScanner.cs     recursive scanner + hashing pipeline
    FileHasher.cs           quick/full SHA-256 helpers
    DuplicateDeleter.cs     safety validation and deletion
    NativeMethods.cs        Win32 hard links + Recycle Bin
    Dialogs.cs              drive picker, issues, confirm, progress, result
    Controls.cs             custom buttons, cards, search, grid
    Theme.cs                colors, fonts, rounded drawing
    ReportExporter.cs       HTML + CSV
    SettingsStore.cs        local settings
  tests/                    engine tests
  tools/MakeIcon.ps1        builds app.ico and app-256.png
  assets/                   generated icon assets
  installer/                Inno Setup script, wizard art, bundled .NET
  dist/                     DupScanPro-Setup-1.1.0.exe after build
  build/                    DupScan.exe after build
```

---

## Version

1.1.0 Pro — branded installer, bundled .NET 4.8 bootstrap, Desktop/Start Menu shortcuts, uninstaller.

If Windows SmartScreen shows a warning because the executable is new and unsigned, choose **More info → Run anyway**. The app is locally built and does not need administrator rights for normal folder scans.
