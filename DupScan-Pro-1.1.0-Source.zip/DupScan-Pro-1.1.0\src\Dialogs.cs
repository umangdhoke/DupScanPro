using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DupScan
{
    public class ThemedDialog : Form
    {
        protected Panel Content;
        protected Panel ButtonPanel;
        protected FlowLayoutPanel ButtonStrip;
        private readonly Label _titleLabel;
        private readonly Label _subtitleLabel;

        public ThemedDialog(string title, string subtitle, Size size)
        {
            Text = title;
            ClientSize = size;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            BackColor = Theme.Background;
            Font = Theme.BaseFont;
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;

            GradientHeader header = new GradientHeader();
            header.Dock = DockStyle.Top;
            header.Height = 84;
            Controls.Add(header);

            LogoMark logo = new LogoMark();
            logo.SetBounds(18, 16, 44, 44);
            header.Controls.Add(logo);

            _titleLabel = Theme.MakeLabel(title, new Font("Segoe UI", 16f, FontStyle.Bold), Color.White);
            _titleLabel.SetBounds(78, 15, size.Width - 110, 30);
            _titleLabel.AutoEllipsis = true;
            header.Controls.Add(_titleLabel);

            _subtitleLabel = Theme.MakeLabel(subtitle, new Font("Segoe UI", 9f), Color.FromArgb(199, 210, 254));
            _subtitleLabel.SetBounds(80, 45, size.Width - 112, 22);
            _subtitleLabel.AutoEllipsis = true;
            header.Controls.Add(_subtitleLabel);

            ButtonPanel = new Panel();
            ButtonPanel.Dock = DockStyle.Bottom;
            ButtonPanel.Height = 68;
            ButtonPanel.BackColor = Theme.Surface;
            ButtonPanel.Paint += delegate(object sender, PaintEventArgs e)
            {
                using (Pen pen = new Pen(Theme.Border, 1f))
                {
                    e.Graphics.DrawLine(pen, 0, 0, ButtonPanel.Width, 0);
                }
            };
            Controls.Add(ButtonPanel);

            ButtonStrip = new FlowLayoutPanel();
            ButtonStrip.AutoSize = true;
            ButtonStrip.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ButtonStrip.FlowDirection = FlowDirection.RightToLeft;
            ButtonStrip.WrapContents = false;
            ButtonStrip.BackColor = Color.Transparent;
            ButtonStrip.Location = new Point(size.Width - 20, 14);
            ButtonPanel.Controls.Add(ButtonStrip);
            ButtonPanel.Resize += delegate { PositionButtons(); };
            ButtonStrip.SizeChanged += delegate { PositionButtons(); };

            Content = new Panel();
            Content.Dock = DockStyle.Fill;
            Content.Padding = new Padding(22);
            Content.BackColor = Theme.Background;
            Content.AutoScroll = true;

            // Fill first, then the bottom and top docks: docking is applied from
            // front to back, so this keeps the header and footer visible.
            Controls.Add(Content);
            Controls.Add(ButtonPanel);
            Controls.Add(header);
        }

        private void PositionButtons()
        {
            ButtonStrip.Location = new Point(ButtonPanel.Width - ButtonStrip.Width - 20, 14);
        }

        protected void AddDialogButton(FlatButton button)
        {
            button.Margin = new Padding(8, 0, 0, 0);
            ButtonStrip.Controls.Add(button);
        }

        protected Label AddContentLabel(string text, Font font, Color color, int x, int y, int width, int height)
        {
            Label label = new Label();
            label.Text = text;
            label.Font = font;
            label.ForeColor = color;
            label.BackColor = Color.Transparent;
            label.SetBounds(x, y, width, height);
            label.AutoEllipsis = true;
            Content.Controls.Add(label);
            return label;
        }
    }

    public sealed class DrivePickerDialog : ThemedDialog
    {
        private readonly ListView _list;
        private readonly Label _error;
        private readonly List<DriveInfo> _drives = new List<DriveInfo>();

        public List<string> SelectedDrives = new List<string>();

        public DrivePickerDialog()
            : base("Add a drive", "Pick one or more local, removable, or network drives.", new Size(580, 520))
        {
            Label intro = AddContentLabel("Available drives", Theme.H3Font, Theme.Text, 0, 0, 500, 22);

            _list = new ListView();
            _list.View = View.Details;
            _list.CheckBoxes = true;
            _list.FullRowSelect = true;
            _list.HeaderStyle = ColumnHeaderStyle.Nonclickable;
            _list.BorderStyle = BorderStyle.FixedSingle;
            _list.BackColor = Theme.Surface;
            _list.ForeColor = Theme.Text;
            _list.Font = Theme.BaseFont;
            _list.SetBounds(0, 28, 532, 270);
            _list.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _list.Columns.Add("Drive", 90);
            _list.Columns.Add("Type", 95);
            _list.Columns.Add("Free space", 120);
            _list.Columns.Add("Total size", 120);
            _list.DoubleClick += delegate { AcceptSelection(); };
            Content.Controls.Add(_list);

            _error = AddContentLabel(string.Empty, Theme.SmallFont, Theme.Danger, 0, 304, 532, 20);
            _error.Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;

            List<DriveInfo> drives = DriveUtil.GetReadyDrives();
            for (int i = 0; i < drives.Count; i++)
            {
                DriveInfo drive = drives[i];
                _drives.Add(drive);
                string type = drive.DriveType.ToString();
                string free = "—";
                string total = "—";
                string label = string.Empty;
                try
                {
                    if (drive.IsReady)
                    {
                        free = FormatUtil.FormatBytes(drive.AvailableFreeSpace);
                        total = FormatUtil.FormatBytes(drive.TotalSize);
                        label = drive.VolumeLabel;
                    }
                }
                catch { }

                ListViewItem item = new ListViewItem(string.IsNullOrEmpty(label)
                    ? drive.Name
                    : drive.Name + "  " + label);
                item.SubItems.Add(type);
                item.SubItems.Add(free);
                item.SubItems.Add(total);
                item.Tag = drive;
                _list.Items.Add(item);
            }

            if (_list.Items.Count > 0) _list.Items[0].Checked = true;
            if (_list.Items.Count == 0) _error.Text = "No ready drives were found.";

            FlatButton cancel = new FlatButton();
            cancel.Text = "Cancel";
            cancel.Width = 100;
            cancel.Style = FlatButtonStyle.Secondary;
            cancel.DialogResult = DialogResult.Cancel;

            FlatButton add = new FlatButton();
            add.Text = "Add selected drives";
            add.Width = 170;
            add.Style = FlatButtonStyle.Primary;
            add.Click += delegate { AcceptSelection(); };

            AddDialogButton(add);
            AddDialogButton(cancel);
            CancelButton = cancel;
        }

        private void AcceptSelection()
        {
            SelectedDrives.Clear();
            for (int i = 0; i < _list.Items.Count; i++)
            {
                if (_list.Items[i].Checked)
                {
                    DriveInfo drive = _list.Items[i].Tag as DriveInfo;
                    if (drive != null) SelectedDrives.Add(drive.Name);
                }
            }

            if (SelectedDrives.Count == 0)
            {
                _error.Text = "Check at least one drive, or cancel.";
                return;
            }

            DialogResult = DialogResult.OK;
            Close();
        }
    }

    public sealed class IssuesDialog : ThemedDialog
    {
        public IssuesDialog(List<ScanIssue> issues, int totalIssues)
            : base("Skipped items", "Files or folders that could not be read during the scan.", new Size(880, 580))
        {
            string note = totalIssues > issues.Count
                ? "Showing the first " + issues.Count + " of " + totalIssues + " skipped items."
                : totalIssues + " " + FormatUtil.Plural(totalIssues, "item was", "items were") + " skipped.";
            AddContentLabel(note, Theme.SmallFont, Theme.Muted, 0, 0, 812, 20);

            ListView list = new ListView();
            list.View = View.Details;
            list.FullRowSelect = true;
            list.GridLines = false;
            list.BorderStyle = BorderStyle.FixedSingle;
            list.BackColor = Theme.Surface;
            list.ForeColor = Theme.Text;
            list.Font = Theme.SmallFont;
            list.SetBounds(0, 28, 812, 360);
            list.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom;
            list.Columns.Add("Path", 430);
            list.Columns.Add("Reason", 350);
            for (int i = 0; i < issues.Count; i++)
            {
                ListViewItem item = new ListViewItem(issues[i].Path);
                item.SubItems.Add(issues[i].Message);
                item.ToolTipText = issues[i].Path + Environment.NewLine + issues[i].Message;
                list.Items.Add(item);
            }
            list.ShowItemToolTips = true;
            Content.Controls.Add(list);

            FlatButton close = new FlatButton();
            close.Text = "Close";
            close.Width = 100;
            close.Style = FlatButtonStyle.Primary;
            close.DialogResult = DialogResult.OK;

            FlatButton copy = new FlatButton();
            copy.Text = "Copy list";
            copy.Width = 110;
            copy.Style = FlatButtonStyle.Secondary;
            copy.Click += delegate
            {
                try
                {
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    for (int i = 0; i < issues.Count; i++)
                    {
                        sb.AppendLine(issues[i].Path + "\t" + issues[i].Message);
                    }
                    Clipboard.SetText(sb.ToString());
                    copy.Text = "Copied";
                }
                catch { }
            };

            AddDialogButton(close);
            AddDialogButton(copy);
            AcceptButton = close;
        }
    }

    public sealed class AboutDialog : ThemedDialog
    {
        public AboutDialog()
            : base("About DupScan Pro", "Exact-content duplicate finder for Windows", new Size(660, 620))
        {
            LogoMark logo = new LogoMark();
            logo.SetBounds(0, 0, 68, 68);
            Content.Controls.Add(logo);

            AddContentLabel("DupScan Pro 1.1", new Font("Segoe UI", 18f, FontStyle.Bold), Theme.Text, 84, 2, 480, 34);
            AddContentLabel("Native Windows app · Pro edition", Theme.SmallFont, Theme.Muted, 86, 38, 480, 20);

            Label body = new Label();
            body.Text =
                "DupScan Pro finds duplicate files by exact content, not by file name.\r\n\r\n" +
                "How it works\r\n" +
                "  1.  Recursively walks every folder and subfolder you choose.\r\n" +
                "  2.  Groups files by size, then checks a quick fingerprint.\r\n" +
                "  3.  Confirms matches with a full SHA-256 content hash.\r\n" +
                "  4.  Shows every copy so you decide what to keep.\r\n\r\n" +
                "Safety built in\r\n" +
                "  •  Recycle Bin is the default delete method.\r\n" +
                "  •  At least one copy in each group is always kept.\r\n" +
                "  •  Files are re-checked before deletion; changed files are skipped.\r\n" +
                "  •  Protected Windows and Program Files paths are blocked.\r\n" +
                "  •  Hard links are detected and excluded from reclaimable space.\r\n" +
                "  •  Every deletion is written to a local CSV log.\r\n\r\n" +
                "Tip: run DupScan Pro as administrator if you want it to scan protected system folders. " +
                "The entire drive scan can take a while on large disks; the first pass is the slowest.";
            body.Font = Theme.BaseFont;
            body.ForeColor = Theme.Text;
            body.BackColor = Color.Transparent;
            body.SetBounds(0, 86, 590, 330);
            body.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            Content.Controls.Add(body);

            LinkLabel logs = new LinkLabel();
            logs.Text = "Open log folder";
            logs.Font = Theme.SmallFont;
            logs.LinkColor = Theme.Accent;
            logs.ActiveLinkColor = Theme.AccentHover;
            logs.BackColor = Color.Transparent;
            logs.SetBounds(0, 424, 130, 20);
            logs.LinkClicked += delegate { ShellUtil.OpenFolder(AppPaths.LogFolder); };
            Content.Controls.Add(logs);

            FlatButton close = new FlatButton();
            close.Text = "Close";
            close.Width = 100;
            close.Style = FlatButtonStyle.Primary;
            close.DialogResult = DialogResult.OK;
            AddDialogButton(close);
            AcceptButton = close;
        }
    }

    public sealed class DeleteConfirmDialog : ThemedDialog
    {
        private readonly RadioButton _recycle;
        private readonly RadioButton _permanent;
        private readonly CheckBox _verify;
        private readonly CheckBox _understand;
        private readonly Label _error;
        private readonly FlatButton _continue;

        public DeleteMode Mode;
        public bool Verify;

        public DeleteConfirmDialog(List<DuplicateFile> files, int groupCount, bool verifyDefault)
            : base("Remove duplicate files", "Review the cleanup before anything is touched.", new Size(700, 640))
        {
            long totalBytes = 0;
            for (int i = 0; i < files.Count; i++) totalBytes += files[i].File.Size;

            CardPanel summary = new CardPanel();
            summary.SetBounds(0, 0, 656, 100);
            summary.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            summary.Padding = new Padding(0);
            Content.Controls.Add(summary);

            Label count = Theme.MakeLabel(files.Count.ToString("N0", CultureInfo.CurrentCulture) + " " +
                FormatUtil.Plural(files.Count, "file", "files") + " selected", Theme.ValueFont, Theme.Text);
            count.AutoSize = false;
            count.TextAlign = ContentAlignment.MiddleLeft;
            count.SetBounds(18, 10, 600, 38);
            summary.Controls.Add(count);

            Label size = Theme.MakeLabel(FormatUtil.FormatBytes(totalBytes) + " across " + groupCount +
                " duplicate " + FormatUtil.Plural(groupCount, "group", "groups") + " · at least one copy per group is kept",
                Theme.SmallFont, Theme.Muted);
            size.AutoSize = false;
            size.AutoEllipsis = true;
            size.TextAlign = ContentAlignment.MiddleLeft;
            size.SetBounds(20, 52, 600, 26);
            summary.Controls.Add(size);

            AddContentLabel("Choose how to remove the selected copies", Theme.H3Font, Theme.Text, 0, 108, 620, 24);

            _recycle = new RadioButton();
            _recycle.Text = "Move to Recycle Bin   (recommended)";
            _recycle.Font = Theme.BoldFont;
            _recycle.ForeColor = Theme.Text;
            _recycle.BackColor = Color.Transparent;
            _recycle.Checked = true;
            _recycle.SetBounds(2, 138, 620, 24);
            Content.Controls.Add(_recycle);

            AddContentLabel("Safest option. Disk space is reclaimed after you empty the Recycle Bin.",
                Theme.SmallFont, Theme.Muted, 22, 162, 620, 20);

            _permanent = new RadioButton();
            _permanent.Text = "Delete permanently";
            _permanent.Font = Theme.BoldFont;
            _permanent.ForeColor = Theme.Danger;
            _permanent.BackColor = Color.Transparent;
            _permanent.SetBounds(2, 190, 620, 24);
            Content.Controls.Add(_permanent);

            _recycle.CheckedChanged += delegate { UpdateMode(); };
            _permanent.CheckedChanged += delegate { UpdateMode(); };

            AddContentLabel("Cannot be undone. Disk space is freed immediately.",
                Theme.SmallFont, Theme.Danger, 22, 214, 620, 20);

            AddContentLabel("Files to remove", Theme.H3Font, Theme.Text, 0, 246, 620, 22);

            ListBox preview = new ListBox();
            preview.BorderStyle = BorderStyle.FixedSingle;
            preview.BackColor = Theme.SurfaceAlt;
            preview.ForeColor = Theme.Text;
            preview.Font = Theme.SmallFont;
            preview.HorizontalScrollbar = true;
            preview.SelectionMode = SelectionMode.None;
            preview.SetBounds(0, 270, 656, 104);
            preview.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            int previewCount = Math.Min(files.Count, 8);
            for (int i = 0; i < previewCount; i++) preview.Items.Add(files[i].File.Path);
            if (files.Count > previewCount) preview.Items.Add("... and " + (files.Count - previewCount) + " more");
            preview.Items.Add("Kept copy: " + groupCount + " " + FormatUtil.Plural(groupCount, "file", "files") +
                " (one per duplicate group)");
            Content.Controls.Add(preview);

            _verify = new CheckBox();
            _verify.Text = "Verify file content again before deleting (safer, a little slower)";
            _verify.Font = Theme.SmallFont;
            _verify.ForeColor = Theme.Text;
            _verify.BackColor = Color.Transparent;
            _verify.Checked = verifyDefault;
            _verify.SetBounds(2, 386, 620, 22);
            Content.Controls.Add(_verify);

            _understand = new CheckBox();
            _understand.Text = "I understand permanent deletion cannot be undone.";
            _understand.Font = Theme.SmallFont;
            _understand.ForeColor = Theme.Danger;
            _understand.BackColor = Color.Transparent;
            _understand.SetBounds(22, 412, 620, 22);
            _understand.Visible = false;
            _understand.CheckedChanged += delegate { _error.Text = string.Empty; };
            Content.Controls.Add(_understand);

            _error = AddContentLabel(string.Empty, Theme.SmallFont, Theme.Danger, 0, 442, 620, 34);

            FlatButton cancel = new FlatButton();
            cancel.Text = "Cancel";
            cancel.Width = 100;
            cancel.Style = FlatButtonStyle.Secondary;
            cancel.DialogResult = DialogResult.Cancel;

            _continue = new FlatButton();
            _continue.Text = "Move to Recycle Bin";
            _continue.Width = 190;
            _continue.Style = FlatButtonStyle.Primary;
            _continue.Click += delegate { ContinueClicked(); };

            AddDialogButton(_continue);
            AddDialogButton(cancel);
            CancelButton = cancel;
            UpdateMode();

            // A click that opened this dialog must never fall through and
            // activate the destructive action. Give the user a moment.
            Shown += delegate
            {
                _continue.Enabled = false;
                System.Windows.Forms.Timer gate = new System.Windows.Forms.Timer();
                gate.Interval = 450;
                gate.Tick += delegate
                {
                    gate.Stop();
                    gate.Dispose();
                    if (!IsDisposed) _continue.Enabled = true;
                };
                gate.Start();
            };
        }

        private void UpdateMode()
        {
            if (_permanent.Checked)
            {
                _continue.Text = "Delete permanently";
                _continue.Style = FlatButtonStyle.Danger;
                _understand.Visible = true;
                _error.Text = string.Empty;
            }
            else
            {
                _continue.Text = "Move to Recycle Bin";
                _continue.Style = FlatButtonStyle.Primary;
                _understand.Visible = false;
                _understand.Checked = false;
                _error.Text = string.Empty;
            }
        }

        private void ContinueClicked()
        {
            if (_permanent.Checked && !_understand.Checked)
            {
                _error.Text = "Check the confirmation box before permanent deletion.";
                return;
            }

            Mode = _permanent.Checked ? DeleteMode.Permanent : DeleteMode.RecycleBin;
            Verify = _verify.Checked;
            DialogResult = DialogResult.OK;
            Close();
        }
    }

    public sealed class DeletionProgressDialog : ThemedDialog
    {
        private readonly ScanResult _result;
        private readonly DeleteMode _mode;
        private readonly bool _verify;
        private readonly ProgressTrack _track;
        private readonly Label _status;
        private readonly Label _percent;
        private readonly Label _counts;
        private readonly Label _path;
        private readonly FlatButton _cancel;
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private bool _completed;
        private bool _running;

        public DeleteOutcome Outcome;
        public Exception Error;

        public DeletionProgressDialog(ScanResult result, DeleteMode mode, bool verify)
            : base("Removing duplicates", mode == DeleteMode.RecycleBin
                ? "Moving selected files to the Recycle Bin."
                : "Permanently deleting selected files.", new Size(620, 360))
        {
            _result = result;
            _mode = mode;
            _verify = verify;

            _status = AddContentLabel(mode == DeleteMode.RecycleBin ? "Preparing Recycle Bin..." : "Preparing permanent delete...",
                Theme.H2Font, Theme.Text, 0, 0, 576, 28);
            _status.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            _track = new ProgressTrack();
            _track.SetBounds(0, 44, 576, 10);
            _track.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            _track.Marquee = true;
            Content.Controls.Add(_track);

            _percent = AddContentLabel("0%", Theme.BoldFont, Theme.Accent, 0, 62, 100, 22);
            _counts = AddContentLabel("0 files processed", Theme.SmallFont, Theme.Muted, 100, 62, 476, 22);
            _counts.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            _path = AddContentLabel(string.Empty, Theme.SmallFont, Theme.Faint, 0, 92, 576, 34);
            _path.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;

            _cancel = new FlatButton();
            _cancel.Text = "Cancel";
            _cancel.Width = 100;
            _cancel.Style = FlatButtonStyle.Secondary;
            _cancel.Click += delegate { CancelWork(); };
            AddDialogButton(_cancel);

            Shown += delegate { StartWork(); };
            FormClosing += delegate(object sender, FormClosingEventArgs e)
            {
                if (_running && !_completed)
                {
                    e.Cancel = true;
                    CancelWork();
                }
            };
        }

        private async void StartWork()
        {
            _running = true;
            Progress<DeleteProgress> progress = new Progress<DeleteProgress>(UpdateProgress);
            try
            {
                Outcome = await Task.Run(delegate
                {
                    return DuplicateDeleter.DeleteSelected(_result, _mode, _verify, progress, _cts.Token);
                });

                if (Outcome != null && Outcome.WasCancelled)
                {
                    _status.Text = "Cleanup stopped";
                }
                else
                {
                    _status.Text = _mode == DeleteMode.RecycleBin ? "Moved to Recycle Bin" : "Permanently deleted";
                }
                _track.Marquee = false;
                _track.Value = 100;
                _percent.Text = "100%";
            }
            catch (OperationCanceledException)
            {
                _status.Text = "Cleanup cancelled";
            }
            catch (Exception ex)
            {
                Error = ex;
                AppLog.Crash(ex, "Deletion failed");
            }
            finally
            {
                _running = false;
                _completed = true;
                DialogResult = DialogResult.OK;
                Close();
            }
        }

        private void UpdateProgress(DeleteProgress progress)
        {
            if (IsDisposed) return;
            if (progress == null) return;

            _status.Text = progress.Message;
            _track.Marquee = false;
            _track.Value = progress.Percent;
            _percent.Text = progress.Percent.ToString(CultureInfo.InvariantCulture) + "%";
            _counts.Text = progress.Current + " of " + progress.Total + " files processed";
            _path.Text = FormatUtil.ShortenPath(progress.CurrentPath, 96);
        }

        private void CancelWork()
        {
            if (!_running && !_completed) return;
            _cts.Cancel();
            _cancel.Enabled = false;
            _cancel.Text = "Cancelling...";
            _status.Text = "Stopping after the current file...";
        }
    }

    public sealed class DeleteResultDialog : ThemedDialog
    {
        public DeleteResultDialog(DeleteOutcome outcome)
            : base(outcome.Failed.Count == 0 ? "Cleanup complete" : "Cleanup finished with issues",
                outcome.Failed.Count == 0 ? "Your selected duplicates were removed." : "Some files could not be removed.",
                new Size(720, 600))
        {
            string headline;
            string detail;

            if (outcome.BytesRecycled > 0 && outcome.BytesFreed > 0)
            {
                headline = outcome.Succeeded.Count + " " + FormatUtil.Plural(outcome.Succeeded.Count, "file", "files") + " removed";
                detail = FormatUtil.FormatBytes(outcome.BytesRecycled) + " moved to the Recycle Bin and " +
                         FormatUtil.FormatBytes(outcome.BytesFreed) + " permanently deleted.";
            }
            else if (outcome.BytesRecycled > 0)
            {
                headline = outcome.Succeeded.Count + " " + FormatUtil.Plural(outcome.Succeeded.Count, "file", "files") +
                           " moved to the Recycle Bin";
                detail = FormatUtil.FormatBytes(outcome.BytesRecycled) + " will be reclaimed after you empty the Recycle Bin. " +
                         "The originals are still recoverable from the bin.";
            }
            else
            {
                headline = outcome.Succeeded.Count + " " + FormatUtil.Plural(outcome.Succeeded.Count, "file", "files") +
                           " permanently deleted";
                detail = FormatUtil.FormatBytes(outcome.BytesFreed) + " of disk space was freed.";
            }

            AddContentLabel(headline, new Font("Segoe UI", 17f, FontStyle.Bold), Theme.Text, 0, 0, 676, 34);
            AddContentLabel(detail, Theme.BaseFont, Theme.Muted, 0, 42, 676, 44);

            if (outcome.WasCancelled)
            {
                AddContentLabel("Cancelled before all selected files were processed.", Theme.SmallFont,
                    Theme.Warning, 0, 86, 676, 20);
            }

            if (outcome.Failed.Count > 0)
            {
                AddContentLabel(outcome.Failed.Count + " " + FormatUtil.Plural(outcome.Failed.Count, "file was", "files were") +
                    " skipped", Theme.H3Font, Theme.Danger, 0, 92, 676, 22);

                ListView list = new ListView();
                list.View = View.Details;
                list.FullRowSelect = true;
                list.BorderStyle = BorderStyle.FixedSingle;
                list.BackColor = Theme.Surface;
                list.Font = Theme.SmallFont;
                list.SetBounds(0, 118, 676, 180);
                list.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
                list.Columns.Add("File", 240);
                list.Columns.Add("Reason", 420);
                for (int i = 0; i < outcome.Failed.Count; i++)
                {
                    ListViewItem item = new ListViewItem(outcome.Failed[i].File.Path);
                    item.SubItems.Add(outcome.Failed[i].Reason);
                    item.ToolTipText = outcome.Failed[i].File.Path + Environment.NewLine + outcome.Failed[i].Reason;
                    list.Items.Add(item);
                }
                list.ShowItemToolTips = true;
                Content.Controls.Add(list);
            }

            string log = "Deletion log: " + outcome.LogPath;
            AddContentLabel(log, Theme.SmallFont, Theme.Faint, 0, 310, 676, 20);

            FlatButton done = new FlatButton();
            done.Text = "Done";
            done.Width = 100;
            done.Style = FlatButtonStyle.Primary;
            done.DialogResult = DialogResult.OK;

            FlatButton logs = new FlatButton();
            logs.Text = "Open log folder";
            logs.Width = 120;
            logs.Style = FlatButtonStyle.Secondary;
            logs.Click += delegate { ShellUtil.OpenFolder(AppPaths.LogFolder); };

            AddDialogButton(done);
            AddDialogButton(logs);

            if (outcome.BytesRecycled > 0)
            {
                FlatButton bin = new FlatButton();
                bin.Text = "Open Recycle Bin";
                bin.Width = 140;
                bin.Style = FlatButtonStyle.Secondary;
                bin.Click += delegate { ShellUtil.OpenRecycleBin(); };
                AddDialogButton(bin);
            }

            AcceptButton = done;
        }
    }
}
