using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DupScan Pro - Duplicate File Finder")]
[assembly: AssemblyDescription("Finds duplicate files by exact content and removes selected copies safely.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DupScan Pro")]
[assembly: AssemblyProduct("DupScan Pro")]
[assembly: AssemblyCopyright("Copyright © 2026")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4cf249c8-6a4b-4c1f-9f2d-9c3b7a5e8d11")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: AssemblyInformationalVersion("1.1.0 Pro")]
