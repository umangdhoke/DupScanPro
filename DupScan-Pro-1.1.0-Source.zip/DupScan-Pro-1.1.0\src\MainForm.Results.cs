using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace DupScan
{
    public sealed partial class MainForm
    {
        private enum KeepRule
        {
            Newest,
            Oldest,
            ShortestPath,
            FirstAlphabetical
        }

        private void PopulateResults(ScanResult result)
        {
            _result = result;
            _rowByFile.Clear();
            _grid.SuspendLayout();
            _grid.Rows.Clear();

            if (result.Groups.Count == 0)
            {
                _grid.ResumeLayout();
                _grid.Visible = false;
                _emptyState.Visible = true;
                _emptyState.TitleText = "No duplicates found";
                _emptyState.SubtitleText = "Scanned " + FormatUtil.FormatCount(result.FilesScanned) + " files across " +
                    result.Roots.Count + " " + FormatUtil.Plural(result.Roots.Count, "location", "locations") +
                    " and found no two files with the same content.";
                _emptyState.FootnoteText = result.IssueCount > 0
                    ? result.IssueCount + " items were skipped. Lower the minimum size or add more folders to widen the search."
                    : "Try lowering the minimum file size or adding more folders.";
                _resultsBaseSubtitle = "No duplicate files found";
                _resultsSubtitle.Text = _resultsBaseSubtitle;
                _autoSelectButton.Enabled = false;
                _exportButton.Enabled = false;
                _selectDuplicatesButton.Enabled = false;
                _deleteButton.Enabled = false;
                _clearSelectionButton.Enabled = false;
                _selectionLabel.Text = "Nothing to remove";
                _selectionLabel.ForeColor = Theme.Muted;
                UpdateSummaryCards(result);
                UpdateIssuesLink(result);
                return;
            }

            for (int g = 0; g < result.Groups.Count; g++)
            {
                DuplicateGroup group = result.Groups[g];
                for (int f = 0; f < group.Files.Count; f++)
                {
                    DuplicateFile duplicate = group.Files[f];
                    object[] values = new object[]
                    {
                        "☐",
                        "G" + group.Id,
                        duplicate.File.Name,
                        duplicate.File.SizeText,
                        duplicate.File.ModifiedText,
                        duplicate.File.Folder,
                        "KEEP"
                    };

                    int index = _grid.Rows.Add(values);
                    DataGridViewRow row = _grid.Rows[index];
                    row.Tag = duplicate;
                    _rowByFile[duplicate.File] = row;

                    row.Cells[0].Style.Font = Theme.SymbolFont;
                    row.Cells[0].Style.ForeColor = Theme.Faint;
                    row.Cells[0].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    row.Cells[1].Style.ForeColor = Theme.Faint;
                    row.Cells[1].Style.Font = Theme.SmallFont;

                    row.Cells[3].Style.ForeColor = Theme.Muted;
                    row.Cells[4].Style.ForeColor = Theme.Muted;
                    row.Cells[4].Style.Font = Theme.SmallFont;
                    row.Cells[5].Style.ForeColor = Theme.Muted;
                    row.Cells[5].Style.Font = Theme.SmallFont;

                    row.Cells[6].Style.ForeColor = Theme.Success;
                    row.Cells[6].Style.Font = Theme.BoldFont;
                    row.Cells[6].Style.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    if (group.Id % 2 == 0)
                    {
                        row.DefaultCellStyle.BackColor = Theme.RowAlt;
                    }

                    row.Cells[2].ToolTipText = duplicate.File.Path;
                    row.Cells[5].ToolTipText = duplicate.File.Path;
                    row.Cells[6].ToolTipText = "SHA-256: " + duplicate.File.FullHash + Environment.NewLine +
                        "Full path: " + duplicate.File.Path;
                    row.Cells[0].ToolTipText = "Click to mark this copy for removal. A copy in every group is always kept.";
                }
            }

            _grid.ResumeLayout();
            _grid.Visible = true;
            _emptyState.Visible = false;
            _grid.ClearSelection();

            _resultsBaseSubtitle = result.Groups.Count.ToString("N0") + " " +
                FormatUtil.Plural(result.Groups.Count, "group", "groups") + "  ·  " +
                result.TotalDuplicateFiles.ToString("N0") + " redundant " +
                FormatUtil.Plural(result.TotalDuplicateFiles, "copy", "copies") + "  ·  " +
                FormatUtil.FormatBytes(result.ReclaimableBytes) + " reclaimable";
            _resultsSubtitle.Text = _resultsBaseSubtitle;

            _autoSelectButton.Enabled = true;
            _exportButton.Enabled = true;
            _selectDuplicatesButton.Enabled = true;
            _selectionLabel.Text = "Select duplicates to remove";
            _selectionLabel.ForeColor = Theme.Muted;
            _deleteButton.Enabled = false;
            _clearSelectionButton.Enabled = false;
            _deleteButton.Text = "Remove selected";

            UpdateSummaryCards(result);
            UpdateIssuesLink(result);
            UpdateSelectionSummary();
        }

        private void UpdateSummaryCards(ScanResult result)
        {
            _cardGroups.Value = FormatUtil.FormatCount(result.Groups.Count);
            _cardGroups.Hint = "sets of identical files";

            _cardFiles.Value = FormatUtil.FormatCount(result.TotalDuplicateFiles);
            _cardFiles.Hint = "extra copies";

            _cardReclaim.Value = FormatUtil.FormatBytes(result.ReclaimableBytes);
            _cardReclaim.Hint = "if duplicates are removed";

            _cardScanned.Value = FormatUtil.FormatCount(result.FilesScanned);
            _cardScanned.Hint = FormatUtil.FormatBytes(result.TotalBytesScanned) + " examined";
        }

        private void UpdateIssuesLink(ScanResult result)
        {
            if (result.IssueCount > 0)
            {
                _issuesLink.Text = result.IssueCount + " skipped " + FormatUtil.Plural(result.IssueCount, "item", "items");
                _issuesLink.Visible = true;
            }
            else
            {
                _issuesLink.Visible = false;
            }
        }

        private void UpdateSelectionSummary()
        {
            if (_result == null)
            {
                _deleteButton.Enabled = false;
                _clearSelectionButton.Enabled = false;
                return;
            }

            int selected = 0;
            int allSelectedGroups = 0;
            long selectedBytes = 0;

            for (int g = 0; g < _result.Groups.Count; g++)
            {
                DuplicateGroup group = _result.Groups[g];
                int groupSelected = 0;
                for (int f = 0; f < group.Files.Count; f++)
                {
                    if (group.Files[f].SelectedForDeletion)
                    {
                        groupSelected++;
                        selected++;
                        selectedBytes += group.Files[f].File.Size;
                    }
                }
                if (groupSelected > 0 && groupSelected == group.Files.Count)
                    allSelectedGroups++;
            }

            if (selected == 0)
            {
                _selectionLabel.Text = "Select duplicates to remove";
                _selectionLabel.ForeColor = Theme.Muted;
            }
            else if (allSelectedGroups > 0)
            {
                _selectionLabel.Text = "Keep at least one copy in " + allSelectedGroups + " " +
                    FormatUtil.Plural(allSelectedGroups, "group", "groups") + ".";
                _selectionLabel.ForeColor = Theme.Danger;
            }
            else
            {
                _selectionLabel.Text = selected.ToString("N0") + " " +
                    FormatUtil.Plural(selected, "file", "files") + " selected  ·  " +
                    FormatUtil.FormatBytes(selectedBytes);
                _selectionLabel.ForeColor = Theme.Text;
            }

            _deleteButton.Enabled = selected > 0 && allSelectedGroups == 0 && !_isScanning;
            _clearSelectionButton.Enabled = selected > 0 && !_isScanning;
            _deleteButton.Text = selected > 0
                ? "Remove " + selected.ToString("N0") + (selected == 1 ? " file" : " files")
                : "Remove selected";
        }

        private void SetDeletionState(DataGridViewRow row, DuplicateFile duplicate, bool selected, bool updateSummary)
        {
            if (row == null || duplicate == null) return;

            duplicate.SelectedForDeletion = selected;
            row.Cells[0].Value = selected ? "☑" : "☐";
            row.Cells[0].Style.ForeColor = selected ? Theme.Danger : Theme.Faint;
            row.Cells[6].Value = selected ? "DELETE" : "KEEP";
            row.Cells[6].Style.ForeColor = selected ? Theme.Danger : Theme.Success;
            row.Cells[6].Style.SelectionForeColor = selected ? Theme.Danger : Theme.Success;
            _grid.InvalidateRow(row.Index);

            if (updateSummary) UpdateSelectionSummary();
        }

        private void ToggleRow(int rowIndex)
        {
            if (rowIndex < 0 || rowIndex >= _grid.Rows.Count) return;
            DataGridViewRow row = _grid.Rows[rowIndex];
            DuplicateFile duplicate = row.Tag as DuplicateFile;
            if (duplicate == null) return;
            SetDeletionState(row, duplicate, !duplicate.SelectedForDeletion, true);
        }

        private void ClearSelection()
        {
            if (_result == null) return;
            _grid.SuspendLayout();
            for (int g = 0; g < _result.Groups.Count; g++)
            {
                DuplicateGroup group = _result.Groups[g];
                for (int f = 0; f < group.Files.Count; f++)
                {
                    DuplicateFile duplicate = group.Files[f];
                    DataGridViewRow row;
                    if (_rowByFile.TryGetValue(duplicate.File, out row))
                    {
                        SetDeletionState(row, duplicate, false, false);
                    }
                }
            }
            _grid.ResumeLayout();
            UpdateSelectionSummary();
            SetStatus("Selection cleared.");
        }

        private void ApplyKeepRule(KeepRule rule)
        {
            if (_result == null || _result.Groups.Count == 0) return;

            _grid.SuspendLayout();
            for (int g = 0; g < _result.Groups.Count; g++)
            {
                DuplicateGroup group = _result.Groups[g];
                if (group.Files.Count == 0) continue;

                int keepIndex = 0;
                for (int i = 1; i < group.Files.Count; i++)
                {
                    KeepRuleCompare(rule, group.Files, i, ref keepIndex);
                }

                for (int i = 0; i < group.Files.Count; i++)
                {
                    DuplicateFile duplicate = group.Files[i];
                    DataGridViewRow row;
                    if (_rowByFile.TryGetValue(duplicate.File, out row))
                    {
                        SetDeletionState(row, duplicate, i != keepIndex, false);
                    }
                }
            }
            _grid.ResumeLayout();
            UpdateSelectionSummary();

            string label;
            if (rule == KeepRule.Newest) label = "Kept the newest copy in every group.";
            else if (rule == KeepRule.Oldest) label = "Kept the oldest copy in every group.";
            else if (rule == KeepRule.ShortestPath) label = "Kept the shortest path in every group.";
            else label = "Kept the first path alphabetically in every group.";
            SetStatus(label + " Review the DELETE rows, then remove.");
        }

        private static void KeepRuleCompare(KeepRule rule, List<DuplicateFile> files, int candidate, ref int best)
        {
            DuplicateFile a = files[candidate];
            DuplicateFile b = files[best];

            if (rule == KeepRule.Newest)
            {
                int cmp = a.File.ModifiedUtc.CompareTo(b.File.ModifiedUtc);
                if (cmp > 0 || (cmp == 0 && a.File.Path.Length < b.File.Path.Length)) best = candidate;
            }
            else if (rule == KeepRule.Oldest)
            {
                int cmp = a.File.ModifiedUtc.CompareTo(b.File.ModifiedUtc);
                if (cmp < 0 || (cmp == 0 && a.File.Path.Length < b.File.Path.Length)) best = candidate;
            }
            else if (rule == KeepRule.ShortestPath)
            {
                int cmp = a.File.Path.Length.CompareTo(b.File.Path.Length);
                if (cmp < 0 || (cmp == 0 && string.Compare(a.File.Path, b.File.Path, StringComparison.OrdinalIgnoreCase) < 0))
                    best = candidate;
            }
            else
            {
                if (string.Compare(a.File.Path, b.File.Path, StringComparison.OrdinalIgnoreCase) < 0)
                    best = candidate;
            }
        }

        private void ApplyFilter()
        {
            if (_grid == null || _grid.IsDisposed) return;
            if (_grid.Rows.Count == 0)
            {
                _resultsSubtitle.Text = _resultsBaseSubtitle;
                return;
            }

            string query = _search.Input.Text.Trim();
            int visible = 0;
            _grid.SuspendLayout();
            for (int i = 0; i < _grid.Rows.Count; i++)
            {
                DataGridViewRow row = _grid.Rows[i];
                bool match;
                if (query.Length == 0)
                {
                    match = true;
                }
                else
                {
                    string name = Convert.ToString(row.Cells[2].Value);
                    string folder = Convert.ToString(row.Cells[5].Value);
                    string group = Convert.ToString(row.Cells[1].Value);
                    match = name.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                            folder.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0 ||
                            group.IndexOf(query, StringComparison.OrdinalIgnoreCase) >= 0;
                }
                row.Visible = match;
                if (match) visible++;
            }
            _grid.ResumeLayout();

            if (query.Length == 0)
            {
                _resultsSubtitle.Text = _resultsBaseSubtitle;
            }
            else
            {
                _resultsSubtitle.Text = "Showing " + visible.ToString("N0") + " of " +
                    _grid.Rows.Count.ToString("N0") + " files  ·  " + _resultsBaseSubtitle;
            }
        }

        private void OnGridCellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 0) return;
            ToggleRow(e.RowIndex);
        }

        private void OnGridCellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex == 0) return;
            DataGridViewRow row = _grid.Rows[e.RowIndex];
            DuplicateFile duplicate = row.Tag as DuplicateFile;
            if (duplicate == null) return;
            if (System.IO.File.Exists(duplicate.File.Path))
                ShellUtil.OpenFile(duplicate.File.Path);
            else
                MessageBox.Show(this, "That file no longer exists:\r\n\r\n" + duplicate.File.Path,
                    "File not found", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void OnGridCellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button != MouseButtons.Right || e.RowIndex < 0) return;
            _grid.CurrentCell = _grid.Rows[e.RowIndex].Cells[Math.Max(0, e.ColumnIndex)];
            _contextRow = _grid.Rows[e.RowIndex];
            _contextFile = _contextRow.Tag as DuplicateFile;
        }

        private void OnGridKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Space && _grid.CurrentRow != null)
            {
                ToggleRow(_grid.CurrentRow.Index);
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.Enter && _grid.CurrentRow != null)
            {
                DuplicateFile duplicate = _grid.CurrentRow.Tag as DuplicateFile;
                if (duplicate != null && System.IO.File.Exists(duplicate.File.Path))
                    ShellUtil.OpenFile(duplicate.File.Path);
                e.Handled = true;
            }
        }

        private void OnGridToolTip(object sender, DataGridViewCellToolTipTextNeededEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;
            DataGridViewRow row = _grid.Rows[e.RowIndex];
            DuplicateFile duplicate = row.Tag as DuplicateFile;
            if (duplicate == null) return;

            if (e.ColumnIndex == 0)
            {
                e.ToolTipText = "Click to mark this copy for removal. A copy in every group is always kept.";
            }
            else if (e.ColumnIndex == 5 || e.ColumnIndex == 2)
            {
                e.ToolTipText = duplicate.File.Path;
            }
            else if (e.ColumnIndex == 6)
            {
                e.ToolTipText = "SHA-256: " + duplicate.File.FullHash + Environment.NewLine +
                    "Full path: " + duplicate.File.Path;
            }
        }
    }
}
