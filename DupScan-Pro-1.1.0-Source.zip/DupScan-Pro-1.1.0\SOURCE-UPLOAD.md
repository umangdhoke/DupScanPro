# DupScan Pro 1.1.0 — source upload package

This folder is the source-only project for DupScan Pro. It builds the Windows
application and the native installer.

## Included

- `src/` — all C# 5 source for the app, scanner, hashing, safety checks,
  deletion, reports, settings, UI, Pro branding, and donation screen
- `tests/` — engine test suite (33 tests)
- `tools/MakeIcon.ps1` — builds the multi-size icon
- `assets/` — app icon, PNG logo, donation QR
- `installer/` — Inno Setup script, What's New page, wizard artwork
- `build.ps1` — compiles the app with the built-in .NET Framework compiler
- `build-installer.ps1` — compiles the setup with Inno Setup
- `README.md`, `UserGuide.txt` — documentation

## Not included (to keep the source small)

- `dist/DupScanPro-Setup-1.1.0.exe` — 117 MB setup
- `installer/deps/NDP48-x86-x64-AllOS-ENU.exe` — 121 MB Microsoft runtime
- `installer/tools/` — local Inno Setup compiler
- `build/` — compiled app
- `testdata/` — sample files

## Build the app

Requirements: Windows 10/11 with .NET Framework 4.8. No NuGet packages.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build.ps1
```

Output: `build\DupScan.exe` (about 260 KB including the embedded QR image).

Run tests:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tests\build-tests.ps1
```

## Build the Windows installer

The installer is optional. To rebuild the exact 117 MB setup:

1. Download the official Microsoft .NET Framework 4.8 offline installer:
   `https://go.microsoft.com/fwlink/?LinkId=2088631`
   Save it as:
   `installer\deps\NDP48-x86-x64-AllOS-ENU.exe`
2. Install Inno Setup 6 (or extract it locally). The build script expects:
   `installer\tools\InnoSetup6\app\ISCC.exe`
   You can instead edit the `$iscc` path at the top of `build-installer.ps1`.
3. Run:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\build-installer.ps1
```

The setup bundles the .NET offline installer and installs it only when the
target PC does not already have .NET Framework 4.8.

## Privacy warning — important before a public upload

The following files contain the personal UPI ID and payment QR:

- `assets/donate-qr.png`
- `docs/screenshot-donation.png`
- the `_upiId` value in `src/DonationDialog.cs`

If the repository is public, anyone can read that UPI ID and QR. If you do not
want that, replace or remove those assets and the donation dialog before
publishing. Keep them in a private backup if you still want the payment screen
in your local build.

## License

No license is included. Before publishing, add the license you want (MIT,
Apache-2.0, GPL-3.0, etc.) as `LICENSE`. Without a license, default copyright
applies and others do not automatically get permission to reuse the code.

## Upload to GitHub (example)

```powershell
cd DupScan-Pro-1.1.0
git init
git add .
git commit -m "DupScan Pro 1.1.0 source"
git branch -M main
git remote add origin https://github.com/YOUR-ACCOUNT/DupScan-Pro.git
git push -u origin main
```

The included `.gitignore` keeps build outputs, downloaded SDKs, and test data
out of the repository.
