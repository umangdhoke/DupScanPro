using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace DupScan.Tests
{
    internal static class EngineTests
    {
        private static int _passed;
        private static int _failed;

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern bool CreateHardLink(string lpFileName, string lpExistingFileName, IntPtr lpSecurityAttributes);

        private static int Main()
        {
            string root = Path.Combine(Path.GetTempPath(), "DupScanTests_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(root);
            Console.WriteLine("Test root: " + root);
            Console.WriteLine();

            try
            {
                TestNestedExactDuplicates(root);
                TestSameSizeDifferentContent(root);
                TestMinimumSize(root);
                TestZeroByteFiles(root);
                TestHiddenFiles(root);
                TestHardLinks(root);
                TestDeletionKeepsOneCopy(root);
                TestRecycleBin(root);
                TestChangedFileIsNotDeleted(root);
                TestReports(root);
                TestCancellation(root);
                TestOverlappingRoots(root);
            }
            catch (Exception ex)
            {
                _failed++;
                Console.WriteLine("FATAL: " + ex);
            }
            finally
            {
                try
                {
                    ClearAttributes(root);
                    Directory.Delete(root, true);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Cleanup warning: " + ex.Message);
                }
            }

            Console.WriteLine();
            Console.WriteLine("Passed: " + _passed + "   Failed: " + _failed);
            return _failed == 0 ? 0 : 1;
        }

        private static void TestNestedExactDuplicates(string parent)
        {
            string root = Path.Combine(parent, "nested");
            WriteFile(Path.Combine(root, "a.bin"), 5000, 1);
            WriteFile(Path.Combine(root, "one", "two", "three", "b.bin"), 5000, 1);
            WriteFile(Path.Combine(root, "different.bin"), 5000, 2);
            WriteFile(Path.Combine(root, "unique.bin"), 6123, 3);

            ScanResult result = Scan(root, 1024, false, false);
            Assert("nested: one duplicate group", result.Groups.Count == 1);
            Assert("nested: two copies found", result.Groups.Count == 1 && result.Groups[0].Files.Count == 2);
            Assert("nested: reclaimable is one file", result.Groups.Count == 1 && result.Groups[0].ReclaimableBytes == 5000);
            Assert("nested: scanned 4 files", result.FilesScanned == 4);
        }

        private static void TestSameSizeDifferentContent(string parent)
        {
            string root = Path.Combine(parent, "same-size");
            WriteFile(Path.Combine(root, "x.bin"), 4096, 10);
            WriteFile(Path.Combine(root, "y.bin"), 4096, 11);
            ScanResult result = Scan(root, 1024, false, false);
            Assert("same-size: different content is not grouped", result.Groups.Count == 0);
        }

        private static void TestMinimumSize(string parent)
        {
            string root = Path.Combine(parent, "minimum");
            WriteFile(Path.Combine(root, "small-a.bin"), 512, 20);
            WriteFile(Path.Combine(root, "small-b.bin"), 512, 20);

            ScanResult filtered = Scan(root, 1024, false, false);
            Assert("minimum: small duplicates filtered out", filtered.Groups.Count == 0);

            ScanResult included = Scan(root, 0, false, false);
            Assert("minimum: 0 KB includes small duplicates", included.Groups.Count == 1);
        }

        private static void TestZeroByteFiles(string parent)
        {
            string root = Path.Combine(parent, "empty");
            WriteFile(Path.Combine(root, "empty-a.txt"), 0, 0);
            WriteFile(Path.Combine(root, "empty-b.txt"), 0, 0);

            ScanResult excluded = Scan(root, 0, false, false);
            Assert("empty: excluded by default", excluded.Groups.Count == 0);

            ScanResult included = Scan(root, 0, true, false);
            Assert("empty: included when requested", included.Groups.Count == 1);
            Assert("empty: two empty files", included.Groups.Count == 1 && included.Groups[0].Files.Count == 2);
        }

        private static void TestHiddenFiles(string parent)
        {
            string root = Path.Combine(parent, "hidden");
            string a = Path.Combine(root, "hidden-a.dat");
            string b = Path.Combine(root, "hidden-b.dat");
            WriteFile(a, 3000, 30);
            WriteFile(b, 3000, 30);
            File.SetAttributes(a, FileAttributes.Hidden);
            File.SetAttributes(b, FileAttributes.Hidden);

            ScanResult excluded = Scan(root, 1024, false, false);
            Assert("hidden: excluded by default", excluded.Groups.Count == 0);

            ScanResult included = Scan(root, 1024, false, true);
            Assert("hidden: included when requested", included.Groups.Count == 1);
        }

        private static void TestHardLinks(string parent)
        {
            string root = Path.Combine(parent, "hardlinks");
            string a = Path.Combine(root, "a.bin");
            string b = Path.Combine(root, "b-hardlink.bin");
            string c = Path.Combine(root, "c.bin");
            string d = Path.Combine(root, "d.bin");
            WriteFile(a, 7000, 40);
            Directory.CreateDirectory(root);
            bool created = CreateHardLink(b, a, IntPtr.Zero);
            WriteFile(c, 7000, 40);
            WriteFile(d, 7000, 40);

            if (!created)
            {
                Console.WriteLine("SKIP hardlink: could not create a hard link on this volume.");
                return;
            }

            ScanResult result = Scan(root, 1024, false, false);
            Assert("hardlink: two independent copies remain", result.Groups.Count == 1 && result.Groups[0].Files.Count == 2);
            Assert("hardlink: hard-linked paths are skipped", result.SkippedHardLinks >= 2);
        }

        private static void TestDeletionKeepsOneCopy(string parent)
        {
            string root = Path.Combine(parent, "delete");
            string a = Path.Combine(root, "delete-a.bin");
            string b = Path.Combine(root, "delete-b.bin");
            WriteFile(a, 6000, 50);
            WriteFile(b, 6000, 50);

            ScanResult result = Scan(root, 1024, false, false);
            Assert("delete: duplicate group found", result.Groups.Count == 1);
            if (result.Groups.Count != 1) return;

            for (int i = 0; i < result.Groups[0].Files.Count; i++)
                result.Groups[0].Files[i].SelectedForDeletion = true;

            string error;
            Assert("delete: refuses to select every copy", !DuplicateDeleter.ValidateSelection(result, out error));

            result.Groups[0].Files[0].SelectedForDeletion = false;
            Assert("delete: accepts a selection with a keeper", DuplicateDeleter.ValidateSelection(result, out error));

            string keepPath = result.Groups[0].Files[0].File.Path;
            string removePath = result.Groups[0].Files[1].File.Path;
            DeleteOutcome outcome = DuplicateDeleter.DeleteSelected(result, DeleteMode.Permanent, true, null, CancellationToken.None);
            Assert("delete: one file deleted", outcome.Succeeded.Count == 1 && outcome.Failed.Count == 0);
            Assert("delete: selected file is gone", !File.Exists(removePath));
            Assert("delete: kept file remains", File.Exists(keepPath));

            ScanResult after = Scan(root, 1024, false, false);
            Assert("delete: no duplicate group remains", after.Groups.Count == 0);
        }

        private static void TestRecycleBin(string parent)
        {
            string root = Path.Combine(parent, "recycle");
            string path = Path.Combine(root, "recycle-me.bin");
            WriteFile(path, 2048, 55);

            int code = NativeMethods.MoveToRecycleBin(path);
            Assert("recycle: shell operation succeeds", code == 0);
            Assert("recycle: file leaves its original path", !File.Exists(path));
        }

        private static void TestChangedFileIsNotDeleted(string parent)
        {
            string root = Path.Combine(parent, "changed");
            string a = Path.Combine(root, "changed-a.bin");
            string b = Path.Combine(root, "changed-b.bin");
            WriteFile(a, 5000, 60);
            WriteFile(b, 5000, 60);

            ScanResult result = Scan(root, 1024, false, false);
            Assert("changed: duplicate group found", result.Groups.Count == 1);
            if (result.Groups.Count != 1) return;

            result.Groups[0].Files[0].SelectedForDeletion = true;
            result.Groups[0].Files[1].SelectedForDeletion = false;
            string changedPath = result.Groups[0].Files[0].File.Path;
            WriteFile(changedPath, 5000, 61);

            DeleteOutcome outcome = DuplicateDeleter.DeleteSelected(result, DeleteMode.Permanent, true, null, CancellationToken.None);
            Assert("changed: changed file is skipped", outcome.Succeeded.Count == 0 && outcome.Failed.Count == 1);
            Assert("changed: file still exists", File.Exists(changedPath));
        }

        private static void TestReports(string parent)
        {
            string root = Path.Combine(parent, "reports");
            WriteFile(Path.Combine(root, "report-a.txt"), 2048, 70);
            WriteFile(Path.Combine(root, "report-b.txt"), 2048, 70);
            ScanResult result = Scan(root, 1024, false, false);
            if (result.Groups.Count == 1) result.Groups[0].Files[0].SelectedForDeletion = true;

            string csv = Path.Combine(root, "report.csv");
            string html = Path.Combine(root, "report.html");
            ReportExporter.ExportCsv(result, csv);
            ReportExporter.ExportHtml(result, html);

            string csvText = File.ReadAllText(csv);
            string htmlText = File.ReadAllText(html);
            Assert("report: CSV has rows", csvText.Contains("report-a.txt") && csvText.Contains("report-b.txt"));
            Assert("report: CSV records selection", csvText.Contains("YES") && csvText.Contains("NO"));
            Assert("report: HTML is a full document", htmlText.Contains("<!DOCTYPE html>") && htmlText.Contains("DupScan Pro report"));
            Assert("report: HTML includes the path", htmlText.Contains("report-a.txt"));
        }

        private static void TestCancellation(string parent)
        {
            string root = Path.Combine(parent, "cancel");
            WriteFile(Path.Combine(root, "cancel-a.bin"), 8000, 80);
            WriteFile(Path.Combine(root, "cancel-b.bin"), 8000, 80);

            CancellationTokenSource cts = new CancellationTokenSource();
            cts.Cancel();
            bool cancelled = false;
            try
            {
                ScanOptions options = Options(root, 1024, false, false);
                new DuplicateScanner(null).Scan(options, cts.Token);
            }
            catch (OperationCanceledException)
            {
                cancelled = true;
            }
            Assert("cancel: a cancelled token stops the scan", cancelled);
        }

        private static void TestOverlappingRoots(string parent)
        {
            string root = Path.Combine(parent, "overlap");
            string child = Path.Combine(root, "child");
            WriteFile(Path.Combine(root, "overlap-a.bin"), 3000, 90);
            WriteFile(Path.Combine(child, "overlap-b.bin"), 3000, 90);

            ScanOptions options = Options(root, 1024, false, false);
            options.Roots.Add(child);
            ScanResult result = new DuplicateScanner(null).Scan(options, CancellationToken.None);
            Assert("overlap: nested roots do not double-count a file", result.FilesScanned == 2);
            Assert("overlap: duplicate still found once", result.Groups.Count == 1);
        }

        private static ScanResult Scan(string root, long minSize, bool includeEmpty, bool includeHidden)
        {
            ScanOptions options = Options(root, minSize, includeEmpty, includeHidden);
            return new DuplicateScanner(null).Scan(options, CancellationToken.None);
        }

        private static ScanOptions Options(string root, long minSize, bool includeEmpty, bool includeHidden)
        {
            ScanOptions options = new ScanOptions();
            options.Roots.Add(root);
            options.SkipSystemFolders = false;
            options.MinFileSize = minSize;
            options.IncludeEmptyFiles = includeEmpty;
            options.IncludeHiddenSystem = includeHidden;
            options.DetectHardLinks = true;
            options.HashThreads = 4;
            return options;
        }

        private static void WriteFile(string path, int size, byte seed)
        {
            string folder = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(folder)) Directory.CreateDirectory(folder);
            byte[] data = new byte[size];
            for (int i = 0; i < size; i++)
            {
                data[i] = (byte)((seed + (i * 31)) & 0xFF);
            }
            File.WriteAllBytes(path, data);
        }

        private static void ClearAttributes(string root)
        {
            if (!Directory.Exists(root)) return;
            string[] files = Directory.GetFiles(root, "*", SearchOption.AllDirectories);
            for (int i = 0; i < files.Length; i++)
            {
                try { File.SetAttributes(files[i], FileAttributes.Normal); } catch { }
            }
        }

        private static void Assert(string name, bool condition)
        {
            if (condition)
            {
                _passed++;
                Console.WriteLine("PASS  " + name);
            }
            else
            {
                _failed++;
                Console.WriteLine("FAIL  " + name);
            }
        }
    }
}
