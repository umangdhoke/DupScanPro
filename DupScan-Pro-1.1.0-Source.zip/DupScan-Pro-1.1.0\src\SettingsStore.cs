using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace DupScan
{
    public sealed class AppSettings
    {
        public List<string> Roots = new List<string>();
        public bool SkipSystemFolders = true;
        public bool IncludeHiddenSystem = false;
        public bool IncludeEmptyFiles = false;
        public bool VerifyBeforeDelete = true;
        public long MinFileSize = 1024;
        public int WindowWidth = 1280;
        public int WindowHeight = 760;
        public bool Maximized = false;
        public string LastExportFolder = string.Empty;
    }

    public static class SettingsStore
    {
        public static AppSettings Load()
        {
            AppSettings settings = new AppSettings();
            try
            {
                if (!File.Exists(AppPaths.SettingsFile)) return settings;

                string[] lines = File.ReadAllLines(AppPaths.SettingsFile, Encoding.UTF8);
                int rootCount = 0;
                for (int i = 0; i < lines.Length; i++)
                {
                    string line = lines[i];
                    int eq = line.IndexOf('=');
                    if (eq <= 0) continue;
                    string key = line.Substring(0, eq).Trim();
                    string value = line.Substring(eq + 1).Trim();

                    if (key == "rootCount")
                    {
                        int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out rootCount);
                    }
                    else if (key.StartsWith("root", StringComparison.Ordinal))
                    {
                        if (!string.IsNullOrEmpty(value)) settings.Roots.Add(value);
                    }
                    else if (key == "skipSystem") settings.SkipSystemFolders = ParseBool(value, true);
                    else if (key == "includeHidden") settings.IncludeHiddenSystem = ParseBool(value, false);
                    else if (key == "includeEmpty") settings.IncludeEmptyFiles = ParseBool(value, false);
                    else if (key == "verifyDelete") settings.VerifyBeforeDelete = ParseBool(value, true);
                    else if (key == "minSize")
                    {
                        long parsed;
                        if (long.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed) && parsed >= 0)
                            settings.MinFileSize = parsed;
                    }
                    else if (key == "windowWidth")
                    {
                        int parsed;
                        if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed) && parsed >= 900)
                            settings.WindowWidth = parsed;
                    }
                    else if (key == "windowHeight")
                    {
                        int parsed;
                        if (int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out parsed) && parsed >= 600)
                            settings.WindowHeight = parsed;
                    }
                    else if (key == "maximized") settings.Maximized = ParseBool(value, false);
                    else if (key == "lastExportFolder") settings.LastExportFolder = value;
                }

                if (rootCount > 0 && settings.Roots.Count > rootCount)
                    settings.Roots.RemoveRange(rootCount, settings.Roots.Count - rootCount);
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "Settings load failed");
            }
            return settings;
        }

        public static void Save(AppSettings settings)
        {
            if (settings == null) return;
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(AppPaths.SettingsFile));
                StringBuilder sb = new StringBuilder();
                sb.AppendLine("roots=" + settings.Roots.Count.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("rootCount=" + settings.Roots.Count.ToString(CultureInfo.InvariantCulture));
                for (int i = 0; i < settings.Roots.Count; i++)
                {
                    sb.AppendLine("root" + i.ToString(CultureInfo.InvariantCulture) + "=" + settings.Roots[i]);
                }
                sb.AppendLine("skipSystem=" + settings.SkipSystemFolders.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("includeHidden=" + settings.IncludeHiddenSystem.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("includeEmpty=" + settings.IncludeEmptyFiles.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("verifyDelete=" + settings.VerifyBeforeDelete.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("minSize=" + settings.MinFileSize.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("windowWidth=" + settings.WindowWidth.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("windowHeight=" + settings.WindowHeight.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("maximized=" + settings.Maximized.ToString(CultureInfo.InvariantCulture));
                sb.AppendLine("lastExportFolder=" + settings.LastExportFolder);

                string temp = AppPaths.SettingsFile + ".tmp";
                File.WriteAllText(temp, sb.ToString(), new UTF8Encoding(true));
                if (File.Exists(AppPaths.SettingsFile)) File.Delete(AppPaths.SettingsFile);
                File.Move(temp, AppPaths.SettingsFile);
            }
            catch (Exception ex)
            {
                AppLog.Crash(ex, "Settings save failed");
            }
        }

        private static bool ParseBool(string value, bool fallback)
        {
            bool parsed;
            return bool.TryParse(value, out parsed) ? parsed : fallback;
        }
    }
}
